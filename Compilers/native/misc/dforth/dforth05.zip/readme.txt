
     DELTA Forth Alpha 0.5 README
  (C)1997-1998 Valer BOCAN <vbocan@usa.net>

  * The compiler and the interpreter are located in their respective
directories. To run the DELTA Forth system, proceed as follows:

	DELTA Forth Compiler
  Invoke the Java Interpreter, specifying the main compiler class (DeltaForth)
and the input and output files, as requested by the compiler.
  Example: java DeltaForth <input.4th> <output.code>

	DELTA Forth Interpreter
  Invoke the Java Interpreter, specifying the main interpreter class (Interpret)
and the input file, as requested by the interpreter.
  Example: java Interpret <output.code>

  NOTE: You must have either JDK or JRE installed on your system to be able to
use the DELTA Forth system.

  * The DELTA Forth documentation is located in the Reference directory. To
view it, simply point your browser to index.htm