#if !defined(AFX_STACKBAR_H__A2E14121_D099_11D1_84A4_0080C7B2ADBF__INCLUDED_)
#define AFX_STACKBAR_H__A2E14121_D099_11D1_84A4_0080C7B2ADBF__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// StackBar.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CStackBar dialog

class CStackBar : public CDialog
{
// Construction
public:
	CStackBar(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CStackBar)
	enum { IDD = IDD_DIALOGBAR1 };
	CString	m_StackList;
	CString	m_summary;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CStackBar)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CStackBar)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STACKBAR_H__A2E14121_D099_11D1_84A4_0080C7B2ADBF__INCLUDED_)
