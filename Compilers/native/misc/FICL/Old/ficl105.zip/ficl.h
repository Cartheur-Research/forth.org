/*******************************************************************
** f i c l . h
** Forth Inspired Command Language
** Author: John Sadler
** Created: 19 July 1997
** 
*******************************************************************/

#if !defined (__FICL_H__)
#define __FICL_H__
/*
** Revision History:
** 14 April 1998 (sadler) V1.04
** Ficlwin: Windows version, Skip Carter's Linux port
** 5 March 1998 (sadler) V1.03
** Bug fixes -- passes John Ryan's ANS test suite "core.fr"
**
** 24 February 1998 (sadler) V1.02
** -Fixed bugs in <# # #>
** -Changed FICL_WORD so that storage for the name characters
**  can be allocated from the dictionary as needed rather than 
**  reserving 32 bytes in each word whether needed or not - 
**  this saved 50% of the dictionary storage requirement.
** -Added words in testmain for Win32 functions system,chdir,cwd,
**  also added a word that loads and evaluates a file.
**
** December 1997 (sadler)
** -Added VM_RESTART exception handling in ficlExec -- this lets words
**  that require additional text to succeed (like :, create, variable...)
**  recover gracefully from an empty input buffer rather than emitting
**  an error message. Definitions can span multiple input blocks with
**  no restrictions.
** -Changed #include order so that <assert.h> is included in sysdep.h,
**  and sysdep is included in all other files. This lets you define
**  NDEBUG in sysdep.h to disable assertions if you want to.
** -Make PC specific system dependent code conditional on _M_IX86
**  defined so that ports can coexist in sysdep.h/sysdep.c
*/

/*
** Ficl (Forth-inspired command language) is an ANS Forth
** interpreter written in C. Unlike traditional Forths, this
** interpreter is designed to be embedded into other systems
** as a command/macro/development prototype language. 
**
** Where Forths usually view themselves as the center of the system
** and expect the rest of the system to be coded in Forth, Ficl
** acts as a component of the system. It is easy to export 
** code written in C or ASM to Ficl in the style of TCL, or to invoke
** Ficl code from a compiled module. This allows you to do incremental
** development in a way that combines the best features of threaded 
** languages (rapid development, quick code/test/debug cycle,
** reasonably fast) with the best features of C (everyone knows it,
** easier to support large blocks of code, efficient, type checking).
**
** Ficl provides facilities for interoperating
** with programs written in C: C functions can be exported to Ficl,
** and Ficl commands can be executed via a C calling interface. The
** interpreter is re-entrant, so it can be used in multiple instances
** in a multitasking system. Unlike Forth, Ficl's outer interpreter
** expects a text block as input, and returns to the caller after each
** text block, so the "data pump" is somewhere in external code. This
** is more like TCL than Forth, which usually expcets to be at the center
** of the system, requesting input at its convenience. Each Ficl virtual 
** machine can be bound to a different I/O channel, and is independent
** of all others in in the same address space except that all virtual
** machines share a common dictionary (a sort or open symbol table that
** defines all of the elements of the language).
**
** Code is written in ANSI C for portability. 
**
** Summary of Ficl features and constraints:
** - Standard: Implements the ANSI Forth CORE word-set
** - Extensible: you can export code written in Forth, C, 
**   or asm in a straightforward way. Ficl provides open
**   facilities for extending the language in an application
**   specific way. You can even add new control structures!
** - Ficl and C can interact in two ways: Ficl can encapsulate
**   C code, or C code can invoke Ficl code.
** - Thread-safe, re-entrant: The shared system dictionary 
**   uses a locking mechanism that you can either supply
**   or stub out to provide exclusive access. Each Ficl
**   virtual machine has an otherwise complete state, and
**   each can be bound to a separate I/O channel (or none at all).
** - Simple encapsulation into existing systems: a basic implementation
**   requires three function calls (see the example program in testmain.c).
** - ROMable: Ficl is designed to work in RAM-based and ROM code / RAM data
**   environments. It does require somewhat more memory than a pure
**   ROM implementation because it builds its system dictionary in 
**   RAM at startup time.
** - Written an ANSI C to be as simple as I can make it to understand,
**   support, debug, and port. Compiles without complaint at /Az /W4 
**   (require ANSI C, max warnings) under Microsoft VC++ 5.
** - Does full 32 bit math (but you need to implement
**   two mixed precision math primitives (see sysdep.c))
** - Indirect threaded interpreter is not the fastest kind of
**   Forth there is (see pForth 68K for a really fast subroutine
**   threaded interpreter), but it's the cleanest match to a C 
**   implementation.
**
** P O R T I N G   F i c l
**
** To install Ficl on your target system, you need an ANSI C compiler
** and its runtime library. Inspect the system dependent macros and
** functions in sysdep.h and sysdep.c and edit them to suit your
** system. For example, INT16 is a short on some compilers and an
** int on others. Check the default CELL alignment controlled by
** FICL_ALIGN. If necessary, add new definitions of ficlMalloc, ficlFree,
** ficlLockDictionary, and ficlTextOut to work with your operating system.
** Finally, use testmain.c as a guide to installing the Ficl system and 
** one or more virtual machines into your code. You do not need to include
** testmain.c in your build.
**
** T o   D o   L i s t
**
** 1. Unimplemented system dependent CORE word: key
**
** F o r   M o r e   I n f o r m a t i o n
**
** Check this website for Forth literature
**   http://www.taygeta.com/forthlit.html
** and here for software and more links
**   http://www.taygeta.com/forth.html
**
*/

#ifdef __cplusplus
extern "C" {
#endif

#include "sysdep.h"

#define FICL_VER "1.05"

/*
** ANS Forth requires false to be zero, and true to be the ones
** complement of false... that unifies logical and bitwise operations
** nicely.
*/
#define FICL_TRUE  (0xffffffffL)
#define FICL_FALSE (0)
#define FICL_BOOL(x) ((x) ? FICL_TRUE : FICL_FALSE)


/*
** A CELL is the main storage type. It must be large enough
** to contain a pointer or a scalar. Let's be picky and make
** a 32 bit cell explicitly...
** LVALUEtoCELL does a little pointer trickery to cast any 32 bit
** lvalue (informal definition: an expression whose result has an
** address) to CELL. Remember that constants and casts are NOT
** themselves lvalues!
*/
typedef union _cell
{
	INT32 i;
    UNS32 u;
	void *p;
} CELL;

#define LVALUEtoCELL(v) (*(CELL *)&v)
/*
** PTRtoCELL is a cast through void * intended to satisfy the
** most outrageously pedantic compiler... (I won't mention 
** its name)
*/
#define PTRtoCELL (CELL *)(void *)
#define PTRtoSTRING (FICL_STRING *)(void *)

/*
** Strings in FICL are stored in Pascal style - with a count
** preceding the text. We'll also NULL-terminate them so that 
** they work with the usual C lib string functions. (Belt &
** suspenders? You decide.)
** STRINGINFO hides the implementation with a couple of
** macros for use in internal routines.
*/

typedef UNS8 FICL_COUNT;
typedef struct _ficl_string
{
    FICL_COUNT count;
    char text[2];
} FICL_STRING;

typedef struct 
{
    FICL_COUNT count;
    char *cp;
} STRINGINFO;

#define SI_COUNT(si) (si.count)
#define SI_PTR(si)   (si.cp)
#define SI_SETLEN(si, len) (si.count = (FICL_COUNT)(len))
#define SI_SETPTR(si, ptr) (si.cp = (char *)(ptr))

typedef struct
{
    INT32 index;
    char *cp;
} TIB;


/*
** Stacks get heavy use in Ficl and Forth...
** Each virtual machine implements two of them:
** one holds parameters (data), and the other holds return
** addresses and control flow information for the virtual
** machine. (Note: C's automatic stack is implicitly used,
** but not modeled because it doesn't need to be...)
** Here's an abstract type for a stack
*/
typedef struct _ficlStack
{
    UNS32 nCells;       /* size of the stack */
    CELL *sp;           /* stack pointer */
    CELL base[1];       /* Bottom of the stack */
} FICL_STACK;

/*
** Stack methods... many map closely to required Forth words.
*/
FICL_STACK *stackCreate(unsigned nCells);
void        stackDelete(FICL_STACK *pStack);
int         stackDepth (FICL_STACK *pStack);
void        stackDrop  (FICL_STACK *pStack, int n);
CELL        stackFetch (FICL_STACK *pStack, int n);
CELL        stackGetTop(FICL_STACK *pStack);
void        stackPick  (FICL_STACK *pStack, int n);
CELL        stackPop   (FICL_STACK *pStack);
void       *stackPopPtr   (FICL_STACK *pStack);
UNS32       stackPopUNS32 (FICL_STACK *pStack);
INT32       stackPopINT32 (FICL_STACK *pStack);
void        stackPush  (FICL_STACK *pStack, CELL c);
void        stackPushPtr  (FICL_STACK *pStack, void *ptr);
void        stackPushUNS32(FICL_STACK *pStack, UNS32 u);
void        stackPushINT32(FICL_STACK *pStack, INT32 i);
void        stackReset (FICL_STACK *pStack);
void        stackRoll  (FICL_STACK *pStack, int n);
void        stackSetTop(FICL_STACK *pStack, CELL c);
void        stackStore(FICL_STACK *pStack, int n, CELL c);


/* 
** The virtual machine (VM) contains the state for one interpreter.
** Defined operations include:
** Create & initialize
** Delete
** Execute a block
** Build a C interface word
** Push a value on the param stack
** Pop a value from the stack
*/

struct ficl_word;
typedef struct ficl_word ** IPTYPE; /* the VM's instruction pointer */

/*
** Each VM has a placeholder for an output function -
** this makes it possible to have each VM do I/O
** through a different device. If you specify no
** OUTFUNC, it defaults to ficlTextOut.
*/
struct _vm;
typedef void (*OUTFUNC)(struct _vm *pVM, char *text, int fNewline);

/*
** Each VM operates in one of two non-error states: interpreting
** or compiling. When interpreting, words are simply executed.
** When compiling, most words in the input stream have their
** addresses inserted into the word under construction. Some words
** (known as IMMEDIATE) are executed in the compile state, too.
*/
/* values of STATE */
#define INTERPRET 0
#define COMPILE   1

/*
** The pad is a small scratch area for text manipulation. ANS Forth
** requires it to hold at least 84 characters.
*/
#if !defined nPAD
#define nPAD 256
#endif

/* 
** ANS Forth requires that a word's name contain {1..31} characters.
*/
#if !defined nFICLNAME
#define nFICLNAME		31
#endif

/*
** OK - now we can really define the VM...
*/
typedef struct _vm
{
    struct _vm     *link;       /* Ficl keeps a VM list for simple teardown */
    jmp_buf        *pState;     /* crude exception mechanism...     */
    OUTFUNC         textOut;    /* Output callback - see sysdep.c   */
    void *          pExtend;    /* vm extension pointer             */
    short           fRestart;   /* Set TRUE to restart runningWord  */
    IPTYPE          ip;         /* instruction pointer              */
    struct ficl_word 
                   *runningWord;/* address of currently running word (often just *(ip-1) ) */
    UNS32           state;      /* compiling or interpreting        */
    UNS32           base;       /* number conversion base           */
    FICL_STACK     *pStack;     /* param stack                      */
    FICL_STACK     *rStack;     /* return stack                     */
    INT32           sourceID;   /* -1 if string, 0 if normal input  */
    TIB             tib;        /* address of incoming text string  */
    char            pad[nPAD];  /* the scratch area (see above)     */
} FICL_VM;

/*
** A FICL_CODE points to a function that gets called to help execute
** a word in the dictionary. It always gets passed a pointer to the
** running virtual machine, and from there it can get the address
** of the parameter area of the word it's supposed to operate on.
** For precompiled words, the code is all there is. For user defined
** words, the code assumes that the word's parameter area is a list
** of pointers to the code fields of other words to execute, and
** may also contain inline data. The first parameter is always
** a pointer to a code field.
*/
typedef void (*FICL_CODE)(FICL_VM *pVm);

/* 
** The language models memory as a contiguous space divided into
** words in a linked list called the dictionary.
** A FICL_WORD starts each entry in the list.
** Version 1.02: space for the name characters is allotted from
** the dictionary ahead of the word struct - this saves about half 
** the storage on average with very little runtime cost.
*/
typedef struct ficl_word
{
    struct ficl_word *link;     /* Previous word in the dictionary      */
    UNS16 hash;
    UNS8 flags;                 /* Immediate, Smudge, Compile-only      */
    FICL_COUNT nName;           /* Number of chars in word name         */
    char *name;                 /* First nFICLNAME chars of word name   */
    FICL_CODE code;             /* Native code to execute the word      */
    CELL param[1];              /* First data cell of the word          */
} FICL_WORD;

#define CELLS_PER_WORD  ( (sizeof (FICL_WORD) + sizeof (CELL) - 1) \
                          / (sizeof (CELL)) )

int wordIsImmediate(FICL_WORD *pFW);
int wordIsCompileOnly(FICL_WORD *pFW);

/* flag values for word header */
#define FW_IMMEDIATE    1
#define FW_COMPILE      2
#define FW_SMUDGE       4

#define FW_COMPIMMED    (FW_IMMEDIATE | FW_COMPILE)
#define FW_DEFAULT      0


/*
** Exit codes for vmThrow
*/
#define VM_OUTOFTEXT    1   /* hungry - normal exit */
#define VM_RESTART      2   /* word needs more text to suxcceed - re-run it */
#define VM_USEREXIT     3   /* user wants to quit */
#define VM_ERREXIT      4   /* interp found an error */
#define VM_QUIT         5   /* like errexit, but leave pStack & base alone */


void        vmBranchRelative(FICL_VM *pVM, int offset);
FICL_VM *   vmCreate (FICL_VM *pVM, unsigned nPStack, unsigned nRStack);
void        vmDelete (FICL_VM *pVM);
void        vmExecute(FICL_VM *pVM, FICL_WORD *pWord);
char *      vmGetString(FICL_VM *pVM, FICL_STRING *sp, char delimiter);
STRINGINFO  vmGetWord(FICL_VM *pVM);
int         vmGetWordToPad(FICL_VM *pVM);
void        vmPopIP  (FICL_VM *pVM);
void        vmPushIP (FICL_VM *pVM, IPTYPE newIP);
void        vmQuit   (FICL_VM *pVM);
void        vmReset  (FICL_VM *pVM);
void        vmSetTextOut(FICL_VM *pVM, OUTFUNC textOut);
void        vmTextOut(FICL_VM *pVM, char *text, int fNewline);
void        vmThrow  (FICL_VM *pVM, int except);

void        stackCheck(FICL_STACK *pStack, FICL_VM *pVM, int nCells);

/*
** TIB access routines...
** ANS forth seems to require the input buffer to be represented 
** as a pointer to the start of the buffer, and an index to the
** next character to read.
** PushTib points the VM to a new input string and optionally
**  returns a copy of the current state
** PopTib restores the TIB state given a saved TIB from PushTib
** GetInBuf returns a pointer to the next unused char of the TIB
*/
void        vmPushTib(FICL_VM *pVM, char *text, TIB *pSaveTib);
void        vmPopTib(FICL_VM *pVM, TIB *pTib);
#define     vmGetInBuf(pVM) ((pVM)->tib.cp + (pVM)->tib.index)
#define     vmSetTibIndex(pVM, i) (pVM)->tib.index = i
#define     vmUpdateTib(pVM, str) (pVM)->tib.index = (str) - (pVM)->tib.cp

/*
** Generally useful string manipulators omitted by ANSI C...
** ltoa complements strtol
*/
#if defined(_WIN32) && !FICL_MAIN
/* Why do Microsoft Meatballs insist on contaminating
** my namespace with their string functions???
*/
#pragma warning(disable: 4273)
#endif

char *ltoa( INT32 value, char *string, int radix );
char *ultoa(UNS32 value, char *string, int radix );
char digit_to_char(int value);
char *strrev( char *string );
char *skipSpace(char *cp);
char *caseFold(char *cp);
int   strincmp(char *cp1, char *cp2, FICL_COUNT count);

#if defined(_WIN32) && !FICL_MAIN
#pragma warning(default: 4273)
#endif

/*
** Simple fixed size hashtable for indexing words in the
** main dictionary (vocabularies are still searched sequentially
** for now)
*/
typedef struct ficlHash
{
    unsigned size;
    FICL_WORD *hashTbl[1];
} FICL_HASH;

#if !defined HASHSIZE
#define HASHSIZE 127 /* best: use a prime number! */
#endif

/*
** A Dictionary is a linked list of FICL_WORDs. It is Ficl's
** memory model. 
*/
typedef struct ficl_dict
{
    CELL *here;         /* Next free CELL in dict         */
    FICL_WORD *smudge;  /* Word being defined: suppresses */
                        /* inadvertent recursion          */
    FICL_WORD *hashTbl[HASHSIZE];
    unsigned size;      /* Number of cells in dict (total)*/
    CELL dict[1];       /* Base of dictionary memory      */
} FICL_DICT;

void       *alignPtr(void *ptr);
void        dictAbortDefinition(FICL_DICT *pDict);
void        dictAlign(FICL_DICT *pDict);
int         dictAllot(FICL_DICT *pDict, int n);
int         dictAllotCells(FICL_DICT *pDict, int nCells);
void        dictAppendCell(FICL_DICT *pDict, CELL c);
void        dictAppendChar(FICL_DICT *pDict, char c);
FICL_WORD  *dictAppendWord(FICL_DICT *pDict, 
                           char *name, 
                           FICL_CODE pCode, 
                           UNS8 flags);
FICL_WORD  *dictAppendWord2(FICL_DICT *pDict, 
                           STRINGINFO si, 
                           FICL_CODE pCode, 
                           UNS8 flags);
void        dictAppendUNS32(FICL_DICT *pDict, UNS32 u);
int         dictCellsAvail(FICL_DICT *pDict);
int         dictCellsUsed (FICL_DICT *pDict);
void        dictCheck(FICL_DICT *pDict, FICL_VM *pVM, int nCells);
FICL_DICT  *dictCreate(unsigned nCELLS);
void        dictDelete(FICL_DICT *pDict);
UNS16       dictHash(char *name, FICL_COUNT count);
void        dictHashSummary(FICL_VM *pVM);
FICL_WORD  *dictLookup(FICL_DICT *pDict, char *name, FICL_COUNT count);
void        dictReset(FICL_DICT *pDict);
void        dictSetImmediate(FICL_DICT *pDict);
void        dictUnsmudge(FICL_DICT *pDict);
CELL       *dictWhere(FICL_DICT *pDict);


typedef struct 
{
    FICL_DICT *pDict;
    unsigned index;
    FICL_WORD *next;
} DICT_ITERATOR;

FICL_WORD  *dictFirst(FICL_DICT *pDict, DICT_ITERATOR *pDI);
FICL_WORD  *dictNext(DICT_ITERATOR *pDI);


/*
** External interface to FICL...
*/
/* 
** f i c l I n i t S y s t e m
** Binds a global dictionary to the interpreter system and initializes
** the dict to contain the ANSI CORE wordset. 
** You specify the address and size of the allocated area.
** After that, ficl manages it.
** First step is to set up the static pointers to the area.
** Then write the "precompiled" portion of the dictionary in.
** The dictionary needs to be at least large enough to hold the
** precompiled part. Try 1K cells minimum. Use "words" to find
** out how much of the dictionary is used at any time.
*/
void       ficlInitSystem(int nDictCells);

/*
** f i c l T e r m S y s t e m
** Deletes the system dictionary and all virtual machines that
** were created with ficlNewVM (see below). Call this function to
** reclaim all memory used by the dictionary and VMs.
*/
void       ficlTermSystem(void);

/*
** f i c l E x e c
** Evaluates a block of input text in the context of the
** specified interpreter. Emits any requested output to the
** interpreter's output function
** Execution returns when the text block has been executed,
** or an error occurs.
** Returns one of the VM_XXXX codes defined in ficl.h:
** VM_OUTOFTEXT is the normal exit condition
** VM_ERREXIT means that the interp encountered a syntax error
**      and the vm has been reset to recover (some or all
**      of the text block got ignored
** VM_USEREXIT means that the user executed the "bye" command
**      to shut down the interpreter. This would be a good
**      time to delete the vm, etc -- or you can ignore this
**      signal.
** Preconditions: successful execution of ficlInitSystem,
**      Successful creation and init of the VM by ficlNewVM (or equiv)
*/
int        ficlExec(FICL_VM *pVM, char *pText);

/*
** Create a new VM from the heap, and link it into the system VM list.
** Initializes the VM and binds default sized stacks to it. Returns the
** address of the VM, or NULL if an error occurs.
** Precondition: successful execution of ficlInitSystem
*/
FICL_VM   *ficlNewVM(void);

/*
** Returns the address of the most recently defined word in the system
** dictionary with the given name, or NULL if no match.
** Precondition: successful execution of ficlInitSystem
*/
FICL_WORD *ficlLookup(char *name);

/*
** f i c l G e t D i c t
** Utility function - returns the address of the system dictionary.
** Precondition: successful execution of ficlInitSystem
*/
FICL_DICT *ficlGetDict(void);
FICL_DICT *ficlGetEnv(void);
void       ficlSetEnv(char *name, UNS32 value);
void       ficlSetEnvD(char *name, UNS32 hi, UNS32 lo);

/* 
** f i c l B u i l d
** Builds a word into the system default dictionary in a thread-safe way.
** Preconditions: system must be initialized, and there must
** be enough space for the new word's header! Operation is
** controlled by ficlLockDictionary, so any initialization
** required by your version of the function (if you "overrode"
** it) must be complete at this point.
** Parameters:
** name  -- the name of the word to be built
** code  -- code to execute when the word is invoked - must take a single param
**          pointer to a FICL_VM
** flags -- 0 or more of FW_IMMEDIATE, FW_COMPILE, use bitwise OR! 
**          Most words can use FW_DEFAULT.
** nAllot - number of extra cells to allocate in the parameter area (usually zero)
*/
int        ficlBuild(char *name, FICL_CODE code, char flags);

/* 
** f i c l C o m p i l e C o r e
** Builds the ANS CORE wordset into the dictionary - called by
** ficlInitSystem - no need to waste dict space by doing it again.
*/
void       ficlCompileCore(FICL_DICT *dp);
void       ficlCompileSoftCore(FICL_VM *pVM);

/*
** from words.c...
*/
void       constantParen(FICL_VM *pVM);
void       twoConstParen(FICL_VM *pVM);

#ifdef __cplusplus
}
#endif

#endif /* __FICL_H__ */
