/*******************************************************************
                    s t a c k . c
** Forth Inspired Command Language
** Author: John Sadler
** Created: 16 Oct 1997
** 
*******************************************************************/
#include <stdlib.h>
#include <assert.h>

#include "ficl.h"

#define STKDEPTH(s) ((s)->sp - (s)->base)



/*******************************************************************
                    s t a c k C h e c k
** Check the specified stack for underflow or overflow.
** nCells controls the type of check: if nCells is zero,
** the function checks the stack state for underflow and overflow.
** If nCells > 0, checks to see that the stack has room to push
** that many cells. If less than zero, checks to see that the
** stack has room to pop that many cells. If any test fails,
** the function throws (via vmThrow) a VM_ERREXIT exception.
*******************************************************************/
void stackCheck(FICL_STACK *pStack, FICL_VM *pVM, int nCells)
{
    if (nCells >= 0)
    {
        int nRemain = pStack->base + pStack->nCells - pStack->sp;
        if (nRemain < nCells)
        {
            vmTextOut(pVM, "Error: stack overflow", 1);
            vmThrow(pVM, VM_ERREXIT);
        }
    }

    if (nCells <= 0)
    {
        if (-nCells > STKDEPTH(pStack))
        {
            vmTextOut(pVM, "Error: stack underflow", 1);
            vmThrow(pVM, VM_ERREXIT);
        }
    }

    return;
}

/*******************************************************************
                    s t a c k C r e a t e
** 
*******************************************************************/

FICL_STACK *stackCreate(unsigned nCells)
{
    size_t size = sizeof (FICL_STACK) + nCells * sizeof (CELL);
    FICL_STACK *pStack = ficlMalloc(size);

#if FICL_ROBUST
    assert (nCells != 0);
    assert (pStack != NULL);
#endif

    pStack->nCells = nCells;;
    pStack->sp = pStack->base;
    return pStack;
}


/*******************************************************************
                    s t a c k D e l e t e
** 
*******************************************************************/

void stackDelete(FICL_STACK *pStack)
{
    if (pStack)
        ficlFree(pStack);
    return;
}


/*******************************************************************
                    s t a c k D e p t h 
** 
*******************************************************************/

int stackDepth(FICL_STACK *pStack)
{
    return STKDEPTH(pStack);
}

/*******************************************************************
                    s t a c k D r o p
** 
*******************************************************************/

void stackDrop(FICL_STACK *pStack, int n)
{
#if FICL_ROBUST
    assert(n > 0);
#endif
    pStack->sp -= n;
    return;
}


/*******************************************************************
                    s t a c k F e t c h
** 
*******************************************************************/

CELL stackFetch(FICL_STACK *pStack, int n)
{
    return pStack->sp[-n-1];
}

void stackStore(FICL_STACK *pStack, int n, CELL c)
{
    pStack->sp[-n-1] = c;
    return;
}


/*******************************************************************
                    s t a c k G e t T o p
** 
*******************************************************************/

CELL stackGetTop(FICL_STACK *pStack)
{
    return pStack->sp[-1];
}


/*******************************************************************
                    s t a c k P i c k
** 
*******************************************************************/

void stackPick(FICL_STACK *pStack, int n)
{
    stackPush(pStack, stackFetch(pStack, n));
    return;
}


/*******************************************************************
                    s t a c k P o p
** 
*******************************************************************/

CELL stackPop(FICL_STACK *pStack)
{
    return *--pStack->sp;
}

void *stackPopPtr(FICL_STACK *pStack)
{
    return (*--pStack->sp).p;
}

UNS32 stackPopUNS32(FICL_STACK *pStack)
{
    return (*--pStack->sp).u;
}

INT32 stackPopINT32(FICL_STACK *pStack)
{
    return (*--pStack->sp).i;
}


/*******************************************************************
                    s t a c k P u s h
** 
*******************************************************************/

void stackPush(FICL_STACK *pStack, CELL c)
{
    *pStack->sp++ = c;
}

void stackPushPtr(FICL_STACK *pStack, void *ptr)
{
    *pStack->sp++ = LVALUEtoCELL(ptr);
}

void stackPushUNS32(FICL_STACK *pStack, UNS32 u)
{
    *pStack->sp++ = LVALUEtoCELL(u);
}

void stackPushINT32(FICL_STACK *pStack, INT32 i)
{
    *pStack->sp++ = LVALUEtoCELL(i);
}

/*******************************************************************
                    s t a c k R e s e t
** 
*******************************************************************/

void stackReset(FICL_STACK *pStack)
{
    pStack->sp = pStack->base;
    return;
}


/*******************************************************************
                    s t a c k R o l l 
** 
*******************************************************************/

void stackRoll(FICL_STACK *pStack, int n)
{
    CELL c;
    CELL *pCell;

#if FICL_ROBUST
    assert(n >= 0);
#endif

    if (n==0)
        return;

    pCell = pStack->sp - n - 1;
    c = *pCell;

    for (;n > 0; --n, pCell++)
    {
        *pCell = pCell[1];
    }

    *pCell = c;
    return;
}


/*******************************************************************
                    s t a c k S e t T o p
** 
*******************************************************************/

void stackSetTop(FICL_STACK *pStack, CELL c)
{
    pStack->sp[-1] = c;
    return;
}


