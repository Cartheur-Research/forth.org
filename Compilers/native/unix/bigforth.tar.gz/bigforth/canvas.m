\ automatic generated code
\ do not edit
windows also forth

window class canvas1
public:
  early open
  early modal-open
  | canvas ptr (canvas-00)
how:
  : open       screen self new >o map o> ;
  : modal-open screen self new >o map stop o> ;
class;

canvas1 implements
  : init  super init ^ { ^^ | ( [dumpstart] )
        CV[ 12 12 steps  1 11 home!  clear 2 linewidth  path   0 0 to  0 10 to 10 0 to 0 -10 to -10 0 to 2dup fill stroke  0 linewidth ]CV $50 $A *hfill $50 $A *vfill ^ canvas new dup ^^ with bind (canvas-00) endwith 
      1 ^ vabox new panel 2 borderbox
    ( [dumpend] ) } 1 0 ^ modal new 0 hskips 0 vskips s" Canvas-Test" assign ;
class;

script? [IF]
  canvas1 modal-open
bye [TNEN]
