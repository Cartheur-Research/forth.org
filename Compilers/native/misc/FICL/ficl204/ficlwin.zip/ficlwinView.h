// ficlwinView.h : interface of the CFiclwinView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_FICLWINVIEW_H__5634666D_C818_11D1_84A4_0080C7B2ADBF__INCLUDED_)
#define AFX_FICLWINVIEW_H__5634666D_C818_11D1_84A4_0080C7B2ADBF__INCLUDED_

extern "C" {
#include "ficl.h"
}

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class CFiclwinView : public CEditView
{
protected: // create from serialization only
	CFiclwinView();
	DECLARE_DYNCREATE(CFiclwinView)

// Attributes
public:
	CFiclwinDoc* GetDocument();
    CFont    m_Font;
    int      m_bNewline;
    CWinThread *m_pThread;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFiclwinView)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual void OnInitialUpdate();
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnActivateView(BOOL bActivate, CView* pActivateView, CView* pDeactiveView);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CFiclwinView();

    void OnAppendText(WPARAM ignore, LPARAM pChar);
    void OnSetStatus (WPARAM ignore, LPARAM pChar);
    void OnSetLed    (WPARAM ignore, LPARAM pChar);
    void OnSetDac    (WPARAM ignore, LPARAM pChar);
    void OnGetIreg   (WPARAM ignore, LPARAM pChar);
    void OnGetAdc    (WPARAM ignore, LPARAM pChar);
    void OnUpdateStack(WPARAM depth, LPARAM pStr);
    void OnFiclBye   (WPARAM wUnused, LPARAM lUnused);
    void SendFiclMsg (CString *pStr);

#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CFiclwinView)
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnEditPaste();
	afx_msg void OnFileNew();
	afx_msg void OnFileOpen();
	afx_msg void OnFileSave();
	afx_msg void OnFileSaveAs();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in ficlwinView.cpp
inline CFiclwinDoc* CFiclwinView::GetDocument()
   { return (CFiclwinDoc*)m_pDocument; }
#endif


// Build extra Ficlwin interface words (once at app startup)
void FiclwinBuild(void);

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FICLWINVIEW_H__5634666D_C818_11D1_84A4_0080C7B2ADBF__INCLUDED_)
