.( test.fs 1 ) CR

struct 
  cell% field list->next
  cell% field list->x 
end-struct list%

.( test.fs 2 ) CR

VARIABLE xxx
\ xxx root-address 

0 xxx !

.( test.fs 3 ) CR

: new-xxx ( x -- )
  ." n-x 1 " .S
  list% %size allocate THROW \ x addr 
  ." n-x 2 " .S
  xxx @ OVER \ x addr xxx addr
  ." n-x 3 " .S
  list->next ! \ x addr
  ." n-x 4 " .S
  TUCK list->x ! \ addr
  ." n-x 5 " .S
  xxx ! 
  ." n-x 6 " .S
  ;

.( test.fs 4 ) CR

: mklist ( -- )
  10 0 DO
    I new-xxx
  LOOP ;

.( test.fs 5 ) CR

: chklist ( -- )
  ." list: " CR 
  xxx @ 
  BEGIN \ list
    DUP
  WHILE \ list
    DUP list->x @ . CR
    list->next @
  REPEAT DROP CR ;

.( test.fs 6 ) CR

.( mklist ) .S 
mklist 
.( chklist ) .S
chklist
.( c-g ) .S
collect-garbage
.( chklist 2 ) .S
chklist
.( done ) .S
  

  
