INTRODUCTION
------------
HolonForth is a new generation of integrated interactive cross-
platform development systems based on Forth. HOLON4TH is a fully 
functional freeware version, which demonstrates the unusual 
properties of Holon. HOLON4TH can be used for real development work. 

Copyright � 1996 Wolf Wejgaard. All rights reserved.


INSTALLATION
------------
Copy HOLON4TH.ZIP to a new directory on your disk and uncompress it.


FILES
-----
HOLON4TH.EXE    The development system (host).
HOLON4TH.STR    The structure of the target program.
HOLON4TH.TEX    The text of the target program.
HOLON4TH.COD    The code of the target program.

HOLONHLP.STR    The structure of the on-line manual.
HOLONHLP.TEX    The text of the on-line manual.

WIN-MON.EXE     Target monitor for a DOS window.
COM-MON.EXE     Target monitor for a separate PC, serial port COM1:.

TETRIS.MOD      Program module, contains the Tetris game.
HOLON4TH.TXT    Short description of HOLON4TH
README.TXT      This file


TARGET PLATFORMS
----------------
HOLON4TH builds DOS target programs. You have a choice of three 
locations during development:

1. The target program runs on a second PC (recommended).

2. The target program runs in a separate DOS window under MS Windows 
(TM) or OS/2 (TM) (recommended).

3. The target program runs as a coroutine, sharing the DOS memory 
with the host (special cases).

The target is built upon a monitor, which communicates with the 
host. The monitor has the ability to accept and send code, and to 
execute code in the target. 

The monitor runs as a task in parallel with the target program. If 
the target program yields control to the monitor periodically (task 
switching), you are is able to change and test the running program.

HOLON4TH is preset for the target running in a DOS window. For other 
cases change the target platform in the system setup = Ctl+Sft+F3.


STARTING
--------

1. Separate PC's
----------------
Run HOLON4TH.EXE on the workstation (DOS or DOS window). Load and 
run COM-MON.EXE on the separate PC under DOS (not in a DOS window). 
Connect both PCs with a serial communication line. 

Change the setting for the target platform in the system setup. The 
monitor COM-MON.EXE uses port COM1. On the host you can choose among 
the ports COM1..COM4.

2. DOS Windows
--------------
Start HOLON4TH.EXE and WIN-MON.EXE in two separate DOS windows. 
Setup the windows for cooperative multitasking in foreground and 
background: 

- Windows 3.1 (in 386 enhanced mode):  Select the window menu (click 
at upper left box of window), choose settings: Exclusive=no, 
Background=yes, Priority: 100 for foreground and background.

- Windows 95:  Select the window menu (click at the upper left icon 
of the windows), select Properties / Misc: Always_suspend=no, 
Idle_sensitivity=low

3. Coroutine
------------
Start HOLON4TH.EXE under DOS or in a DOS window. Select 'Coroutine' 
in the system setup.


Host-Target Communication
-------------------------
HOLON4TH establishes communication, if host and target are correctly 
connected. Difficulties are announced by the message "off-line" in 
the lower right corner. A blinking dot indicates communication with 
the target.


INFORMATION
-----------
HOLON4TH contains an interactive introduction to Holon, which will 
answer most of your questions. The online manual describes the 
operation and application of HOLON4TH.


CHANGES IN HOLON4TH V4.0
------------------------
- The object type mechanism has been reworked. You can freely define 
a message for every method in an object type. Holon checks the 
validity of the messages that are applied to an object.

- Data space building words added for clarity:  BYTE, ( = C, ) 
INTEGER, ( = , ) DOUBLE, BYTES, 0BYTES, .

- Alias definer added, syntax:  ALIAS: <new> <old> .

- INT is replaced by INTEGER, LONG by DOUBLE. We decided to speak 
Forth. -- If you prefer other names redefine the objects, or create 
an alias, e.g.   ALIAS: INT INTEGER  .

- Array objects added, syntax:  ARRAY( i j )

- The cross-compiler semantics of Holon has been unified. Compiling 
words are defined with the syntax
      COMPILER: name
          INTP: <interpreter-action>  ;
          COMP: <compiler-action>  ;
          CODE: <runcode>

- ;m is replaced by ; .

- POSTPONE , IMMEDIATE and TARGET added to meta code.

- Import/Export of modules as text files, extension = .MTX.

- The first LoadAll in a session also performs InitCode.

- Target space is indicated in the browser: [COR] [WIN] [2PC].

- Alt+M shows the list of meta words.

- Alt+A shows the list of assembler words.

- The About screen displays the number of items in the program.

- The host transfers the code image to the target at startup.


For additional information about HolonForth contact

Wolf Wejgaard
Forth Engineering                    Tel. +41-41-377-3774
Neuhoflirain 10                      Fax. +41-41-377-4774
6045 Meggen, Switzerland             wejgaard@access.ch

