/*
** stub main for testing FICL under Win32
** 
*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#ifdef WIN32
#include <direct.h>
#endif
#include <sys/types.h>
#include <sys/stat.h>
#ifdef linux
#include <unistd.h>
#endif

#include "ficl.h"

/*
** Ficl interface to _getcwd (Win32)
** Prints the current working directory using the VM's 
** textOut method...
*/
static void ficlGetCWD(FICL_VM *pVM)
{
    char *cp;

#ifdef WIN32   
    cp = _getcwd(NULL, 80);
#else
   cp = getcwd(NULL, 80);
#endif
    vmTextOut(pVM, cp, 1);
    free(cp);
    return;
}

/*
** Ficl interface to _chdir (Win32)
** Gets a newline (or NULL) delimited string from the input
** and feeds it to the Win32 chdir function...
** Example:
**    cd c:\tmp
*/
static void ficlChDir(FICL_VM *pVM)
{
    FICL_STRING *pFS = (FICL_STRING *)pVM->pad;
    vmGetString(pVM, pFS, '\n');
    if (pFS->count > 0)
    {
#ifdef WIN32
       int err = _chdir(pFS->text);
#else
       int err = chdir(pFS->text);
#endif
       if (err)
        {
            vmTextOut(pVM, "Error: path not found", 1);
            vmThrow(pVM, VM_QUIT);
        }
    }
    else
    {
        vmTextOut(pVM, "Warning: nothing happened", 1);
    }
    return;
}

/*
** Ficl interface to system (ANSI)
** Gets a newline (or NULL) delimited string from the input
** and feeds it to the Win32 system function...
** Example:
**    system del *.*
**    \ ouch!
*/
static void ficlSystem(FICL_VM *pVM)
{
    FICL_STRING *pFS = (FICL_STRING *)pVM->pad;

    vmGetString(pVM, pFS, '\n');
    if (pFS->count > 0)
    {
        int err = system(pFS->text);
        if (err)
        {
            sprintf(pVM->pad, "System call returned %d", err);
            vmTextOut(pVM, pVM->pad, 1);
            vmThrow(pVM, VM_QUIT);
        }
    }
    else
    {
        vmTextOut(pVM, "Warning: nothing happened", 1);
    }
    return;
}

/*
** Ficl add-in to load a text file and execute it...
** Cheesy, but illustrative.
** Line oriented... filename is newline (or NULL) delimited.
** Example:
**    load test.ficl
*/
#define nLINEBUF 256
static void ficlLoad(FICL_VM *pVM)
{
    FICL_STRING *pFilename = (FICL_STRING *)pVM->pad;

    vmGetString(pVM, pFilename, '\n');

    if (pFilename->count > 0)
    {
       /* get the file's size and make sure it exists */
#ifdef WIN32       
        struct _stat buf;
        int result = _stat( pFilename->text, &buf );
#else
        struct stat buf;
        int result = stat( pFilename->text, &buf );
#endif
        if (result == 0)
        {
            FILE *fp = fopen(pFilename->text, "r");
            if (fp)
            {
                char cp[nLINEBUF];
                UNS32 id = pVM->sourceID;
                pVM->sourceID = -1;

                /* feed each line to ficlExec */
                while (fgets(cp, nLINEBUF, fp))
                {
                    int len = strlen(cp) - 1;
                    if (len > 0)
                    {
                        if (cp[len] == '\n')
                            cp[len] = '\0';

                        if (VM_ERREXIT <= ficlExec(pVM, cp))
                            break; 
                    }
                }

                pVM->sourceID = id;
                fclose(fp);
            }
            else
            {
                vmTextOut(pVM, "Unable to open file ", 0);
                vmTextOut(pVM, pFilename->text, 1);
                vmThrow(pVM, VM_QUIT);
            }
        }
        else
        {
            vmTextOut(pVM, "Unable to stat file ", 0);
            vmTextOut(pVM, pFilename->text, 1);
            vmThrow(pVM, VM_QUIT);
        }
    }
    else
    {
        vmTextOut(pVM, "Warning: nothing happened", 1);
    }
    return;
}

/*
** Dump a tab delimited file that summarizes the contents of the
** dictionary hash table by hashcode...
*/
static void spewHash(FICL_VM *pVM)
{
    FICL_WORD **pHash = ficlGetDict()->hashTbl;
    FICL_WORD *pFW;
    FILE *pOut;
    int i;

    if (!vmGetWordToPad(pVM))
        vmThrow(pVM, VM_OUTOFTEXT);

    pOut = fopen(pVM->pad, "w");
    if (!pOut)
    {
        vmTextOut(pVM, "unable to open file", 1);
        return;
    }

    for (i=0; i<HASHSIZE; i++)
    {
        int n = 0;

        pFW = pHash[i];
        while (pFW)
        {
            n++;
            pFW = pFW->link;
        }

        fprintf(pOut, "%d\t%d", i, n);

        pFW = pHash[i];
        while (pFW)
        {
            fprintf(pOut, "\t%s", pFW->name);
            pFW = pFW->link;
        }

        fprintf(pOut, "\n");
    }

    fclose(pOut);
    return;
}

static void ficlBreak(FICL_VM *pVM)
{
    vmThrow(pVM, VM_ERREXIT);
    return;
}

void buildTestInterface(void)
{
    ficlBuild("break",    ficlBreak,    FW_DEFAULT);
    ficlBuild("cd",       ficlChDir,    FW_DEFAULT);
    ficlBuild("load",     ficlLoad,     FW_DEFAULT);
    ficlBuild("pwd",      ficlGetCWD,   FW_DEFAULT);
    ficlBuild("system",   ficlSystem,   FW_DEFAULT);
    ficlBuild("spewhash", spewHash,     FW_DEFAULT);

    return;
}


#if !defined (_WINDOWS)

int main(int argc, char **argv)
{
    char in[256];
    FICL_VM *pVM;

    ficlInitSystem(10000);
    pVM = ficlNewVM();

    buildTestInterface();
    ficlExec(pVM, ".ver .( " __DATE__ " ) cr quit");

    /*
    ** load file from cmd line...
    */
    if (argc  > 1)
    {
        sprintf(in, ".( loading %s ) cr load %s\n cr", argv[1], argv[1]);
        ficlExec(pVM, in);
    }

    for (;;)
    {
        int ret;
        gets(in);
        ret = ficlExec(pVM, in);
        if (ret == VM_USEREXIT)
        {
            ficlTermSystem();
            break;
        }
    }

    return 0;
}

#endif

