// StackBar.cpp : implementation file
//

#include "stdafx.h"
#include "ficlwin.h"
#include "StackBar.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CStackBar dialog


CStackBar::CStackBar(CWnd* pParent /*=NULL*/)
	: CDialog(CStackBar::IDD, pParent)
{
	//{{AFX_DATA_INIT(CStackBar)
	m_StackList = _T("");
	m_summary = _T("");
	//}}AFX_DATA_INIT
}


void CStackBar::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CStackBar)
	DDX_LBString(pDX, IDC_LIST1, m_StackList);
	DDX_Text(pDX, IDC_STACK, m_summary);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CStackBar, CDialog)
	//{{AFX_MSG_MAP(CStackBar)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CStackBar message handlers
