/*
 * config.h --	Some definitions informing pfe about the environment.
 *		EMX version.
 */

#ifndef __CONFIG_H
#define __CONFIG_H

#define EMX 1
#define HOST_SYSTEM "EMX"
#define CELL_TYPE int
#define HALF_CELL_TYPE short
#define HIGHBYTE_FIRST 0
#define CELL_ALIGN 4
#define SFLOAT_ALIGN 4
#define DFLOAT_ALIGN 4
#define HAVE_MEMMOVE 1
#define HAVE_STRDUP 1
#define HAVE_ATEXIT 1
#define HAVE_RAISE 1
#define HAVE_REMOVE 1
#define HAVE_RENAME 1
#define PATH_MAX 256

double acosh (double);
double asinh (double);
double atanh (double);

#endif
