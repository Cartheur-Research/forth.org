/*******************************************************************
** s o f t c o r e . c
** Forth Inspired Command Language - 
** Words from CORE set written in FICL
** Author: John Sadler
** Created: 27 December 1997
** 
*******************************************************************/
/*
**
*/


#include "ficl.h"

static char softWords[] = 
    "0 constant false "
    "-1 constant true "
    ": abs  dup 0< if negate endif ; "
    "decimal 32 constant bl "
    ": space  bl emit ; "
    ": spaces  0 do space loop ; "
    ": abort\"  postpone if postpone .\" postpone abort postpone endif ; "
    "immediate "
    ": <> = invert ; "
    "quit ";

void ficlCompileSoftCore(FICL_VM *pVM)
{
    ficlExec(pVM, softWords);
}

