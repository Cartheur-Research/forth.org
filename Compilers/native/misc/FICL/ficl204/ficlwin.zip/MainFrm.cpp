  // MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "ficlwin.h"

#include "MainFrm.h"
#include "StackBar.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_COMMAND(ID_VIEW_HARDWARE, OnViewHardware)
	ON_UPDATE_COMMAND_UI(ID_VIEW_HARDWARE, OnUpdateViewHardware)
	ON_COMMAND(ID_VIEW_STACK, OnViewStack)
	ON_UPDATE_COMMAND_UI(ID_VIEW_STACK, OnUpdateViewStack)
	ON_WM_CLOSE()
	//}}AFX_MSG_MAP
	ON_UPDATE_COMMAND_UI(ID_INDICATOR_BASE, OnUpdateIndicatorBase)
	ON_UPDATE_COMMAND_UI(ID_INDICATOR_DEPTH, OnUpdateIndicatorDepth)
	ON_CONTROL_RANGE(BN_CLICKED, IDC_CHECK1, IDC_CHECK8, OnSimSwitches)
	// Global help commands
	ON_COMMAND(ID_HELP, CFrameWnd::OnHelp)
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_BASE,
    ID_INDICATOR_DEPTH,
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	// TODO: add member initialization code here
	m_simSwitches = 0;
    m_simLeds = 0;
    m_simDAC = 0;
    m_simADC = 0;
    m_base = 10;
    m_depth = 0;
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
    CWinApp *pApp = AfxGetApp();

	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_wndToolBar.Create(this) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	// TODO: Remove this if you don't want tool tips or a resizeable toolbar
	m_wndToolBar.SetBarStyle(m_wndToolBar.GetBarStyle() |
		CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC);

	// TODO: Delete these three lines if you don't want the toolbar to
	//  be dockable
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndToolBar);

    /////////////////////////////////////////////////////////////////
    // Create and initialize the simulated hardware dialog bar...
    //
	if ( !m_hardwareBar.Create(this, IDD_DIALOGBAR, CBRS_BOTTOM, IDD_DIALOGBAR) )
	{
		TRACE0("Failed to create hardware bar\n");
		return -1;      // fail to create
	}

    m_hardwareShow = TRUE;
	m_hardwareBar.SetBarStyle(m_hardwareBar.GetBarStyle() |
		CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC );

	m_hardwareBar.EnableDocking(CBRS_ALIGN_TOP | CBRS_ALIGN_BOTTOM);
	DockControlBar(&m_hardwareBar, AFX_IDW_DOCKBAR_BOTTOM);

    m_hLedOff = pApp->LoadIcon(IDI_OFFLED);
    m_hLedRed = pApp->LoadIcon(IDI_REDLED);
    SyncLeds();

    CProgressCtrl *pProg = (CProgressCtrl *)m_hardwareBar.GetDlgItem(IDC_PROGRESS1);
    pProg->SetRange(0,255);
    pProg->SetPos(m_simDAC);

    CSliderCtrl *pSlider = (CSliderCtrl *)m_hardwareBar.GetDlgItem(IDC_SLIDER1);
    pSlider->SetRange(0,255);
    pSlider->SetPos(m_simADC);

    /////////////////////////////////////////////////////////////////
    // Create and initialize the stack display bar...
    //
	if ( !m_stackBar.Create(this, IDD_DIALOGBAR1, CBRS_RIGHT, IDD_DIALOGBAR) )
	{
		TRACE0("Failed to create stack viewer\n");
		return -1;      // fail to create
	}

    m_stackShow = TRUE;
	m_stackBar.EnableDocking(CBRS_ALIGN_LEFT | CBRS_ALIGN_RIGHT);
	DockControlBar(&m_stackBar, AFX_IDW_DOCKBAR_RIGHT );
    
    WINDOWPLACEMENT wpl;
    BOOL SavedPlacementExists = ((CFiclwinApp *)AfxGetApp())->RegToBytes(
                                "Settings", 
                                "Placement", 
                                (void *)&wpl, 
                                sizeof (wpl));

    if (SavedPlacementExists)
    {
        SetWindowPlacement(&wpl);
        AfxGetApp()->m_nCmdShow = wpl.showCmd;
    }

    return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
    BOOL bPreCreate = CFrameWnd::PreCreateWindow(cs);
    return bPreCreate;
}

void CMainFrame::SetStatus(char *msg)
{
    if (msg == NULL)
        msg = "";

    m_wndStatusBar.SetWindowText((LPCTSTR)msg);
}

void CMainFrame::SetStack(int base, int depth, CString *pStr)
{
    CString s = (LPCSTR)"Stack empty";
    int p;

    m_base = base;
    m_depth = depth;

    if (depth > 0)
        s.Format("Stack depth: %d", depth);

    m_stackBar.SetDlgItemText(IDC_STACK, s);

    CListBox *pList = (CListBox *)m_stackBar.GetDlgItem(IDC_LIST1);
    pList->ResetContent();
    // pStr contains stack entries, each followed by a space
    while ((p = pStr->Find(' ')) > 0)
    {
        s = pStr->Left(p+1);
        *pStr = pStr->Mid(p+1);
        pList->AddString(s);
    }

    delete pStr;
    return;
}

void CMainFrame::SyncLeds(int value)
{
    int n;
    int changedBits = value ^ m_simLeds;
    if (value == 0)
        changedBits = -1;

    for (n = 0; n < 8; n++)
    {
        int nID = n + IDC_CHECK1;
        int mask = 1 << n;

        if (changedBits & mask)
        {
            CButton *pButton = (CButton *)m_hardwareBar.GetDlgItem(nID);
            pButton->SetIcon((value & mask) ? m_hLedRed : m_hLedOff);
        }
    }

    m_simLeds = value;
    return;
}


void CMainFrame::SyncDAC(int value)
{
    if ((value == 0) || (value != m_simDAC)) 
    {
        CProgressCtrl *pProg = 
            (CProgressCtrl *)m_hardwareBar.GetDlgItem(IDC_PROGRESS1);
        pProg->SetPos(value);
    }

    m_simDAC = value;
    return;
}


void CMainFrame::SetLeds(int value)
{
    SyncLeds(value);
}

void CMainFrame::SetDAC(int value)
{
    SyncDAC(value);
}

int CMainFrame::GetSwitch(void)
{
    return m_simSwitches;
}


int CMainFrame::GetADC(void)
{
    CSliderCtrl *pSlider = (CSliderCtrl *)m_hardwareBar.GetDlgItem(IDC_SLIDER1);
    m_simADC = pSlider->GetPos();
    return m_simADC;
}


/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers

void CMainFrame::OnSimSwitches(UINT nID)
{
    int bitNumber = nID - IDC_CHECK1;
    int mask = 1 << bitNumber;

    m_simSwitches ^= mask;
    return;
}

BOOL CMainFrame::OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext) 
{
    &lpcs;
    int bSplitter = AfxGetApp()->GetProfileInt( "Settings", "Splitter", -1 );

    if (bSplitter < 0)
    {
        bSplitter = 0;
        AfxGetApp()->WriteProfileInt("Settings", "Splitter", bSplitter);
    }

    if (bSplitter)
    {
	    return m_Splitter.Create(this,
            2, 1,
            CSize(10, 10),
            pContext );
    }

    return CFrameWnd::OnCreateClient(lpcs, pContext);
}

void CMainFrame::OnViewHardware() 
{
	m_hardwareShow = !m_hardwareShow;
    m_hardwareBar.ShowWindow(m_hardwareShow ? SW_SHOW : SW_HIDE);
    RecalcLayout();
}

void CMainFrame::OnUpdateViewHardware(CCmdUI* pCmdUI) 
{
    pCmdUI->SetCheck(m_hardwareShow);
}

void CMainFrame::OnViewStack() 
{
	m_stackShow = !m_stackShow;
    m_stackBar.ShowWindow(m_stackShow ? SW_SHOW : SW_HIDE);
    RecalcLayout();
	
}

void CMainFrame::OnUpdateViewStack(CCmdUI* pCmdUI) 
{
    pCmdUI->SetCheck(m_stackShow);
}

void CMainFrame::OnUpdateIndicatorBase(CCmdUI *pCmdUI)
{
    CString str = "";
    pCmdUI->Enable(); 

    switch (m_base)
    {
    case 2:
        str = "BIN";
        break;
    case 8:
        str = "OCT";
        break;
    case 10:
        str = "DEC";
        break;
    case 16:
        str = "HEX";
        break;
    default:
        str.Format("%3d", m_base);
    }

    pCmdUI->SetText(str); 
}

void CMainFrame::OnUpdateIndicatorDepth(CCmdUI *pCmdUI)
{
    CString strDepth;
    pCmdUI->Enable(); 

    if (m_depth > 0)
        strDepth.Format("%3d", m_depth);
    else
        strDepth = "Empty";

    pCmdUI->SetText(strDepth); 
}

void CMainFrame::OnClose() 
{
	WINDOWPLACEMENT wpl;
    if (GetWindowPlacement(&wpl))
    {
        wpl.showCmd = SW_NORMAL;

        ((CFiclwinApp *)AfxGetApp())->BytesToReg(
                "Settings", 
                "Placement", 
                (void *)&wpl, 
                sizeof (wpl));
    }

	CFrameWnd::OnClose();
}
