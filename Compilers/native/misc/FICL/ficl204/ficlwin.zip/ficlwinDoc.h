// ficlwinDoc.h : interface of the CFiclwinDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_FICLWINDOC_H__5634666B_C818_11D1_84A4_0080C7B2ADBF__INCLUDED_)
#define AFX_FICLWINDOC_H__5634666B_C818_11D1_84A4_0080C7B2ADBF__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000


class CFiclwinDoc : public CDocument
{
protected: // create from serialization only
	CFiclwinDoc();
	DECLARE_DYNCREATE(CFiclwinDoc)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFiclwinDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	virtual BOOL OnOpenDocument(LPCTSTR lpszPathName);
	protected:
	virtual BOOL SaveModified();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CFiclwinDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CFiclwinDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FICLWINDOC_H__5634666B_C818_11D1_84A4_0080C7B2ADBF__INCLUDED_)
