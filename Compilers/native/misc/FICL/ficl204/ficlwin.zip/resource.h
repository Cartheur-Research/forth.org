//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ficlwin.rc
//
#define IDD_ABOUTBOX                    100
#define ID_INDICATOR_BASE               101
#define IDD_DIALOGBAR                   103
#define IDD_DIALOGBAR1                  104
#define ID_INDICATOR_DEPTH              104
#define IDR_MAINFRAME                   128
#define IDR_FICLWITYPE                  129
#define IDI_REDLED                      133
#define IDI_GREENLED                    134
#define IDI_OFFLED                      135
#define IDC_SLIDER1                     1000
#define IDC_PROGRESS1                   1001
#define IDC_CHECK1                      1002
#define IDC_CHECK2                      1003
#define IDC_CHECK3                      1004
#define IDC_LIST1                       1004
#define IDC_CHECK4                      1005
#define IDC_STACK                       1005
#define IDC_CHECK5                      1006
#define IDC_CHECK6                      1007
#define IDC_CHECK7                      1008
#define IDC_CHECK8                      1009
#define ID_VIEW_HARDWARE                32771
#define ID_VIEW_STACK                   32772

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        142
#define _APS_NEXT_COMMAND_VALUE         32773
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           105
#endif
#endif
