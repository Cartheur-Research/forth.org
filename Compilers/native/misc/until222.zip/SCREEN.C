/*
|	SCREEN.C
|	dummy routines to for functions not available from VAX C
|
|	DATE		COMMENT
|	13-Sep-94	rcs
|	01/16/95	Made cleanup changes suggested by Akira Kida,
|			akida@isd.hin.konica.co.jp. [nes]
*/

#include "compiler.h"

#include <stdio.h>

#ifndef BCC
void gotoxy()  {}
void wherey()  {}
#endif

/***********************+-----+
|                       | cls |
|                       +-----+
*/
void cls()
{
	int i;

#ifdef BCC 
	clrscr();
#else
	for(i=0;i<25;i++){
		printf("\n");
	}
#endif
}
