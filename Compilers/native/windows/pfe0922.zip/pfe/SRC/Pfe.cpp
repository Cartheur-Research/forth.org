//---------------------------------------------------------------------------
#include <vcl\vcl.h>
#pragma hdrstop
//---------------------------------------------------------------------------
USERES("Pfe.res");
USEUNIT("4ED.C");
USEUNIT("BLOCK.C");
USEUNIT("CORE.C");
USEUNIT("DBLSUB.C");
USEUNIT("DEBUG.C");
USEUNIT("DICTNRY.C");
USEUNIT("DOUBLE.C");
USEUNIT("FACILITY.C");
USEUNIT("FILE.C");
USEUNIT("FILESUB.C");
USEUNIT("FLOATING.C");
USEUNIT("FORTH-83.C");
USEUNIT("LINED.C");
USEUNIT("LOCALS.C");
USEUNIT("LPF83.C");
USEUNIT("MAIN.C");
USEUNIT("MEMORY.C");
USEUNIT("MISC.C");
USEUNIT("SEARCH.C");
USEUNIT("SHELL.C");
USEUNIT("SHOWHELP.C");
USEUNIT("SIGNALS.C");
USEUNIT("STRING.C");
USEUNIT("SUPPORT.C");
USEUNIT("SYSDEP.C");
USEUNIT("TERM-WAT.C");
USEUNIT("TERM.C");
USEUNIT("TOOLKIT.C");
USEUNIT("UNIX.C");
USEUNIT("VERSION.C");
USEUNIT("VOCS.C");
USEUNIT("XCEPTION.C");
USEUNIT("YOURS.C");
USEFORM("pfeform.cpp", PFEMainForm);
USELIB("\Programme\Borland\CBuilder\LIB\Inet.lib");
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
	try
	{
		Application->Initialize();
		Application->Title = "PFE Win32";
		Application->CreateForm(__classid(TPFEMainForm), &PFEMainForm);
		Application->Run();
	}
	catch (Exception &exception)
	{
		Application->ShowException(&exception);
	}
	return 0;
}
//---------------------------------------------------------------------------
