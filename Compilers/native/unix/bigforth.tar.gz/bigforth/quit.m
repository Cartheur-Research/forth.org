\ automatic generated code
\ do not edit
windows also forth

window class quit
public:
  early open
  early modal-open
  | text-label ptr (text-label-00)
  | glue ptr (glue-01)
  | button ptr (button-02)
  | button ptr (button-03)
  | glue ptr (glue-04)
how:
  : open       screen self new >o map o> ;
  : modal-open screen self new >o map stop o> ;
class;

quit implements
  : init  super init ^ { ^^ | ( [dumpstart] )
        s" Do you really want to leave?" ^ text-label new dup ^^ with bind (text-label-00) endwith 
          $10 $1 *hfill $10 $1 *vfil ^ glue new dup ^^ with bind (glue-01) endwith 
          ^^ S[ ." Yes" cr close ]S s" Yes" ^ button new dup ^^ with bind (button-02) endwith 
          ^^ S[ ." No" cr close ]S s" No" ^ button new dup ^^ with bind (button-03) endwith 
          $10 $1 *hfill $10 $1 *vfil ^ glue new dup ^^ with bind (glue-04) endwith 
        4 ^ hatbox new 2 hskips
      2 ^ vabox new panel
    ( [dumpend] ) } 1 0 ^ modal new 0 hskips 0 vskips s" Quit?" assign ;
class;

script? [IF]
  quit modal-open
bye [TNEN]
