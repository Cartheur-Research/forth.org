// ficlwin.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "ficlwin.h"
#include "ficl.h"

#include "MainFrm.h"
#include "ficlwinDoc.h"
#include "ficlwinView.h"
#include "FiclThread.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// From testmain.c...
extern "C" 
{
    void buildTestInterface(void);
}

static long WINAPI ficlExceptionFilter(struct _EXCEPTION_POINTERS *ExceptionInfo)
{
	&ExceptionInfo;
	return EXCEPTION_CONTINUE_SEARCH;
}


/////////////////////////////////////////////////////////////////////////////
// CFiclwinApp

BEGIN_MESSAGE_MAP(CFiclwinApp, CWinApp)
	//{{AFX_MSG_MAP(CFiclwinApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
	//}}AFX_MSG_MAP
	// Standard file based document commands
	ON_COMMAND(ID_FILE_NEW, CWinApp::OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)
	// Standard print setup command
	ON_COMMAND(ID_FILE_PRINT_SETUP, CWinApp::OnFilePrintSetup)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFiclwinApp construction

CFiclwinApp::CFiclwinApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
	SetErrorMode(SEM_NOGPFAULTERRORBOX);
	SetUnhandledExceptionFilter(ficlExceptionFilter);
}


/////////////////////////////////////////////////////////////////////////////
// The one and only CFiclwinApp object

CFiclwinApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CFiclwinApp initialization

BOOL CFiclwinApp::InitInstance()
{
    int nDictCells;
    int nStackCells;

	AfxEnableControlContainer();

	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	// Change the registry key under which our settings are stored.
	// You should modify this string to be something appropriate
	// such as the name of your company or organization.
	SetRegistryKey(_T("CodeLab"));

	LoadStdProfileSettings();  // Load standard INI file options (including MRU)

    // Create ficl's system structures
    nDictCells = GetProfileInt( "Settings", "nDictCells", FICL_DEFAULT_DICT );
    nDictCells = (nDictCells < FICL_DEFAULT_DICT) ? FICL_DEFAULT_DICT : nDictCells;
    WriteProfileInt( "Settings", "nDictCells", nDictCells );

    nStackCells = GetProfileInt( "Settings", "nStackCells", FICL_DEFAULT_STACK );
    WriteProfileInt( "Settings", "nStackCells", ficlSetStackSize(nStackCells));

    ficlInitSystem(nDictCells);
    buildTestInterface();
    FiclwinBuild();

	// Register the application's document templates.  Document templates
	//  serve as the connection between documents, frame windows and views.

	CSingleDocTemplate* pDocTemplate;
	pDocTemplate = new CSingleDocTemplate(
		IDR_MAINFRAME,
		RUNTIME_CLASS(CFiclwinDoc),
		RUNTIME_CLASS(CMainFrame),       // main SDI frame window
		RUNTIME_CLASS(CFiclwinView));
	AddDocTemplate(pDocTemplate);

	// Parse command line for standard shell commands, DDE, file open
	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);

	// Dispatch commands specified on the command line
	if (!ProcessShellCommand(cmdInfo))
		return FALSE;

	// The one and only window has been initialized, so show and update it.
    m_nCmdShow = (m_nCmdShow < 0) ? SW_RESTORE : m_nCmdShow;
    m_pMainWnd->ShowWindow(m_nCmdShow);
	m_pMainWnd->UpdateWindow();

	return TRUE;
}


/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
		// No message handlers
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

// App command to run the dialog
void CFiclwinApp::OnAppAbout()
{
	CAboutDlg aboutDlg;
	aboutDlg.DoModal();
}

/////////////////////////////////////////////////////////////////////////////
// CFiclwinApp commands

int CFiclwinApp::ExitInstance() 
{
    ficlTermSystem();	
	return CWinApp::ExitInstance();
}


// Called to open a file from the Most Recently Used list
// (only, as far as I can tell)
CDocument* CFiclwinApp::OpenDocumentFile(LPCTSTR lpszFileName) 
{
    POSITION p = GetFirstDocTemplatePosition();
    CDocTemplate *pDT = GetNextDocTemplate(p);
    return pDT->OpenDocumentFile(lpszFileName);
}


int CFiclwinApp::BytesToReg(LPCTSTR section, LPCTSTR entry, void *p, int size)
{
    CString s = "";
    char *cp = (char *)p;
    int i;
    int ch, n;

    for (i = 0; i < size; i++)
    {
        ch = *cp++;
        n =  (ch & 0xf0) >> 4;  // MSNibble to string
        n += (n < 9) ? '0' : 'a' - 10;
        s += (char)n;
        n =  (ch & 0x0f);       // LSNibble to string
        n += (n < 9) ? '0' : 'a' - 10;
        s += (char)n;
    }

    return WriteProfileString(section, entry, s);
}


int CFiclwinApp::RegToBytes(LPCTSTR section, LPCTSTR entry, void *p, int size)
{
    CString s = GetProfileString(section, entry, "");
    char *cp = (char *)p;
    int i;
    int ch, n;

    if (s.GetLength() != 2*size)
        return FALSE;

    for (i = 0; i < size; i++)
    {
        n =  s[2*i];
        n -= (n < '9') ? '0' : 'a' - 10;
        ch = n << 4;
        n =  s[2*i + 1];
        n -= (n < '9') ? '0' : 'a' - 10;
        ch |= n;
        *cp++ = (char)ch;
    }

    return true;
}
