                     4THICE (pronounced 'forthish') Rev .23

Files included:

    Readme.txt   This file you are reading.
    MlBase.txt   Background context for this project.
    g.bat        Generic batch file to assemble, 'g' (no params) for help.
    debugr.com   DOS real mode 386 capable debugger.
    4thice.ico   You DO want to run this under Windows, don't you?
    4thice.asm   A monolithic Forth MASM assembler source.
    4thice.com   A monolithic Forth binary.
    ice.asm      THE minimal kernel MASM assembler source.
    ice.com      THE minimal kernel binary.
    iboot.p      The EXTENDED source including dumb text edtior.
    idbg.p       Nesting _colon_ def disassembler/debugger for 4.com
    4idbg.p      Nesting _colon_ def disassembler/debugger for 4thIce.
    4ide.p       4thIce source for dumb text editor.
    4.com        THE minimal kernel binary+extended source.
    gpl.txt      Gnu Public License.

Quick start:

Enter the apostrophe or quote command strings without the apostrophes or quotes. 
Terminate all command strings with the <Enter> key.

None of the forthish .com files accept DOS command line parameters.


Minimal kernel:

To see the minimal kernel load and exit, run 'ice.com'. Kernel exits without
any source.


Extended kernel:

To run the extended kernel, type '4'. This loads and builds the extensions. 
Type 'bye' at the 4 command line to exit. Command line _is_ case sensitive, 
which simplified the interpreter. 4.com (and Ice.com) was written to use 
lower case. Feel free to change it.

All hex numbers must be in lower case, and all numbers _must_ be prefixed 
with either hexn or decn, e.g. 'hexn 5 hexn 6 + u.'. See iboot.p for working 
examples.

Type 'hexn 4000 dump' to get a formatted hex data display starting at address 
4000h. <Enter> key exits, any other advances by sixteen addresses.

Type 'words' to see the dictionary, name field addresses and code field address. 
<Enter> key to exit words, any other key to advance by one.

Type " ' go dis" to see the high level definition of the word go. 
<Enter> to exit dis, any other key to advance by one.

To test/load idbg.p from 4.com, type 'fload 4idbg.p' from the 4.com command
line. Type ' dbg dbg for a working example. See code for help.  Disassembles 
from an address TOS.

To assemble the source requires MASM 6.xx. Use the g.bat to assemble.

To construct 4.com from ice.com and iboot.p type 
'copy /B ice.com+iboot.p 4.com' 
without the apostrophes, at the DOS command line. Includes dumb text editor.
Type 'de' at the 4 command line to execute the editor on the extended source. 
<Esc> key to exit the editor. Improved display speed and includes text search.

Forth style kernel:

To run the Forth style kernel, type '4thice'. Standard forth type syntax, case
insensitive and no numeric prefixes required unless iboot.p has been loaded.

To test/load iboot.p from 4thIce, type 'fload iboot.p' from the 4thIce command
line. 

Type 'fload 4ide.p' from the 4thIce command line to load the text editor.
Type 'de' at the 4thIce command line to execute the editor on itself. 
<Esc> key to exit the editor. Read the source for help.

Type e.g.: '4000 dump' to get a formatted hex data display starting at 
address 4000h. <Enter> key exits, any other advances by sixteen addresses.

Type 'words' to see the dictionary, name field addresses and code field address. 
<Enter> key to exit words, any other key to advance by one.

Type " ' query dis" to see the high level definition of the word query. 
<Enter> to exit dis, any other key to advance by one.


Generating binaries:

To generate ice.com from ice.asm, have the MASM environment and path set up, 
and type at the DOS command line: 'g ice' for binary only, 'g ice l' for 
binary and assembler source listing.

To generate 4thIce.com from $thIce.asm, have the MASM environment and path 
set up, and type at the DOS command line: 'g 4thIce' for binary only, 
'g 4thIce l' for binary and assembler source listing.


4idbg.p

This is a prototype minimal interface written in high level regular Forth. I 
used it for debugging code in 4thIce before porting said code to Ice. iBoot.p 
is too bloated without adding even more code. Has 5 commands and a response 
to all other keys:
  e  := Enter into disassembly of current displayed word.
  b  := Backup to previous level (if there is one)
  p  := Proceed to execute current displayed word.
  ^e := backup 1 cell in current definition.
  cr := exit dbg
  all other keys advance by 1 cell.
Use " ' empty dbg" as an example. Disassembles from an address TOS.

Debugr.com:

Debugr.com recognizes a limited extended subset of debug.com commands. Decodes
386+ opcodes, recognizes 386 mneumonics. From debugr.com command line type 
'?' for a help screen. Useful for writing low level I/O.

Jan, 19,2001

Terry Loveall, loveall@qwest.net

Feedback welcome.
