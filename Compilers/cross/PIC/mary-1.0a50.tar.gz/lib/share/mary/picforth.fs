( FORTH MID-RANGE PIC FORTH COMPILER, PART OF THE GLAZZ PROJECT. )
( WRITTEN BY FRANCISCO RODRIGO ESCOBEDO ROBLES ON 1999DEC28.     )
( LAST REVISED ON 2000FEB21. VERSION 1.0a50 CODENAMED MARY       )
( MORE INFO AT http://www.pepix.net/proyectos/glazz/mary/        )
( CONTACT frer@pepix.net FOR SUGGESTIONS                         )



( "THIS IS A CODE GENERATOR-LESS COMPILER FOR A SYNTAX-LESS LANGUAGE )
( IN WHICH VARIABLES ARE CONSTANTS" - FRER                           )

( THIS IS A NATIVE CODE FORTH COMPILER WITH CONSTANTS AND DEAD CODE  )
( OPTIMIZATIONS BUILT-IN. THE CODE GENERATED IS OPTIMIZED FOR SPEED, )
( THE OPTIMIZATIONS ALSO MAKE IT AS SMALL AS POSSIBLE IN THIS MODEL. )
( THERE ARE SOME OPTIMIZATIONS IN ORDER TO USE AS FEW AS POSSIBLE    )
( RETURN STACK WORDS, AS WELL AS AVOIDING TO USE THE DATA STACK WHEN )
( PRACTICAL.                                                         )



( REQUIRED ANSI LABELLING:                           )

( THIS IS AN ANS FORTH PROGRAM                       )
( REQUIRING DEFINITIONS FROM THE SEARCH     WORD SET )
( REQUIRING FORTH, ALSO FROM THE SEARCH EXT WORD SET )
( REQUIRING                  THE PICASM     WORD SET )


( GENERAL HOUSEKEEPING )

PICFORTH DEFINITIONS HEX
PICFORTH ALSO
PICASM   ALSO
FORTH    ALSO


( DEFINING WORDS )

: CONSTANT ( N -- ) ( CREATES A NAMED CONSTANT )
    CREATE ,
    DOES>
        @ CONST,
;


: VARIABLE ( -- ) ( CREATES A NAMED GLOBAL VARIABLE )
    1 BVARIABLE
;



( TABLE ACCESSES ONLY IN SUBROUTINE FORM )
( OPTIMIZED FOR CONSTANT INDEX           )
( TABLE BEGINS AT ELEMENT INDEX 0        )

( E.G.:                                  )
(     TABLE 7PRIMES                      )
(       1 , 2 , 3 , 5 , 7 , 11 , 13 ,    )


: TABLE ( -- ; N1 -- N2 ) ( CREATES A HEADER FOR INDEXED TABLE ACCESSES )
    CREATE $ @ ,
        PCL         MOVWF
    DOES>
        CONST?
        IF                ( CONSTANT OPTIMIZATION POSSIBLE?    )
            SWAP @ 1 + +  ( CALCULATES REAL ADDRESS OF ELEMENT )
            PICROM@ DUP   ( GETS ELEMENT                       )
            0FF00 AND
            3400 =        ( IS IT A RETLW?                     )
            IF
                    MOVLW ( TABLE ELEMENT                      )
            ELSE
                DROP
                PICERROR ABORT" ATTEMPT TO ACCESS TABLE BEYOND LIMIT"
            THEN
        ELSE
            @
            DUP LOW  ADDLW
            TMP1     MOVWF
            DUP HIGH MOVLW
            STATUS C BTFSC
            1        ADDLW
            PCLATH   MOVWF
            TMP1 ,W  MOVF
                     CALL
        THEN
;


( USE , _ONLY_ FOR TABLES )

: , ( N -- ) ( COMPILES VALUE IN CURRENT COMPILING ADDRESS) 
        ( N )       RETLW
;



( STACK OPERATORS )

( ?DUP IS MISSING, I AM MOVING TO MINIMALISM. )
( SEE THE AIF DEFINITION FOR AN EXPLANATION   )

( TUCK IS MISSING TOO. IT WAS HERE, BUT FELT  )
( BAD AND HAD TO LEAVE                        )


( ONE CAN IMAGINE A FULL SUITE OF SILLY CODE  )
( THAT CAN PRECEDE DROP AND BE OPTIMIZED BY   )
( SUPPRESING BOTH, E.G: DUP DROP, 5 DROP, ETC )

( FOR FUNNY REASONS, 5 DROP-LIKE CODE WILL BE )

: DROP ( N -- ) ( DROPS THE TOP OF STACK )
    CONST?
    IF                    ( CONSTANT OPTIMIZATION POSSIBLE? )
        KILLCONST         ( SUPPRESS CONSTANT STACKING      )
        DROP              ( DROP THE CONSTANT               )
    ELSE
        POP
    THEN
;


: DUP ( N -- N N ) ( COPIES TOS IN A NEW TOS )
    PUSH
;


: NIP ( N1 N2 -- N2 ) ( EQUIVALENT TO: SWAP DROP )
        FSR    ,F   INCF
;


: OVER ( N1 N2 -- N1 N2 N1 ) ( COPIES SECOND ON STACK TO NEW TOS )
    PUSH
        FSR    ,F   INCF
        INDF   ,W   MOVF
        FSR    ,F   DECF
;


: SWAP ( N1 N2 -- N2 N1 ) ( EXCHANGES THE TWO TOPMOST ELEMENTS ON STACK )
    SAVETOS
        INDF   ,W   MOVF
        TMP2        MOVWF
    RESTORETOS
        INDF        MOVWF
        TMP2   ,W   MOVF
;



( ARITHMETIC WORDS )

: S>D ( U -- UD ) ( CONVERTS TO DOUBLE PRECISION )
    0 CONST,
;


: D>S ( UD -- U ) ( CONVERTS TO SINGLE PRECISION )
    POP
;


: - ( N1 N2 -- N1-N2 ) ( SUBSTRACTS N2 FROM N1 )
    CONST?
    IF                    ( CONSTANT OPTIMIZATION POSSIBLE? )
        KILLCONST         ( SUPPRESS CONSTANT STACKING      )
        CONST?            ( IS THERE A PREVIOUS CONSTANT?   )
        IF
            KILLCONST
            -             ( CALCULATE OPERATION RESULT      )
            CONST,
        ELSE
                    SUBLW ( VALUE IN TOS                    )
        THEN
    ELSE
        INDF   ,W   SUBWF
        FSR    ,F   INCF
    THEN
;


: + ( N1 N2 -- N1+N2 ) ( ADDS N1 TO N2 )
    CONST?
    IF                    ( CONSTANT OPTIMIZATION POSSIBLE? )
        KILLCONST         ( SUPPRESS CONSTANT STACKING      )
        CONST?            ( IS THERE A PREVIOUS CONSTANT?   )
        IF
            KILLCONST
            +             ( CALCULATE OPERATION RESULT      )
            CONST,
        ELSE
                    ADDLW ( VALUE IN TOS                    )
        THEN
    ELSE
        INDF   ,W   ADDWF
        FSR    ,F   INCF
    THEN
;


: 2* ( U -- U*2 ) ( MULTIPLIES TOS BY 2 )
    CONST?
    IF                    ( CONSTANT OPTIMIZATION POSSIBLE? )
        2*          MOVLW ( VALUE IN TOS                    )
    ELSE
        STATUS C    BCF
        TMP1        MOVWF
        TMP1   ,W   RLF
    THEN
;


: 2/ ( U -- U/2 ) ( DIVIDES TOS BY 2 )
    CONST?
    IF                    ( CONSTANT OPTIMIZATION POSSIBLE? )
        2/          MOVLW ( VALUE IN TOS                    )
    ELSE
        STATUS C    BCF
        TMP1        MOVWF
        TMP1   ,W   RRF
    THEN
;


: ABS ( N -- U ) ( CALCULATES ABSOLUTE VALUE OF TOS )
    CONST?
    IF                    ( CONSTANT OPTIMIZATION POSSIBLE? )
        DUP
        ABS8        MOVLW ( VALUE IN TOS                    )
    ELSE
        SAVETOS
        TMP1   7    BTFSS
        3 $+        GOTO  ( JUMPS AFTER THE INCF            )
        TMP1   ,F   COMF
        TMP1   ,W   INCF
    THEN
;


: NEGATE ( N -- -N ) ( CALCULATES NEGATIVE OF TOS )
    CONST?
    IF                    ( CONSTANT OPTIMIZATION POSSIBLE? )
        NEGATE
                    MOVLW ( VALUE IN TOS                    )
    ELSE
        0           SUBLW
    THEN
;



( BIT OPERATORS )

: AND ( N1 N2 -- N3 ) ( BITWISE AND )
    CONST?
    IF                    ( CONSTANT OPTIMIZATION POSSIBLE? )
        KILLCONST         ( SUPPRESS CONSTANT STACKING      )
        CONST?            ( IS THERE A PREVIOUS CONSTANT?   )
        IF
            KILLCONST
            AND           ( CALCULATE OPERATION RESULT      )
            CONST,
        ELSE
                    ANDLW ( VALUE IN TOS                    )
        THEN
    ELSE
        INDF   ,W   ANDWF
        FSR    ,F   INCF
    THEN
;


: INVERT ( N1 -- !N1 ) ( BITWISE NOT )
    CONST?
    IF                    ( CONSTANT OPTIMIZATION POSSIBLE? )
        KILLCONST         ( SUPPRESS CONSTANT STACKING      )
        INVERT            ( CALCULATE OPERATION RESULT      )
                    MOVLW
    ELSE
        0FF         XORLW
    THEN
;


: OR ( N1 N2 -- N3 ) ( BITWISE OR )
    CONST?
    IF                    ( CONSTANT OPTIMIZATION POSSIBLE? )
        KILLCONST         ( SUPPRESS CONSTANT STACKING      )
        CONST?            ( IS THERE A PREVIOUS CONSTANT?   )
        IF
            KILLCONST
            OR            ( CALCULATE OPERATION RESULT      )
            CONST,
        ELSE
                    IORLW ( VALUE IN TOS                    )
        THEN
    ELSE
        INDF   ,W   IORWF
        FSR    ,F   INCF
    THEN
;


: XOR ( N1 N2 -- N3 ) ( BITWISE XOR )
    CONST?
    IF                    ( CONSTANT OPTIMIZATION POSSIBLE? )
        KILLCONST         ( SUPPRESS CONSTANT STACKING      )
        CONST?            ( IS THERE A PREVIOUS CONSTANT?   )
        IF
            KILLCONST
            OR            ( CALCULATE OPERATION RESULT      )
            CONST,
        ELSE
                    XORLW ( VALUE IN TOS                    )
        THEN
    ELSE
        INDF   ,W   XORWF
        FSR    ,F   INCF
    THEN
;


( LOGICAL WORDS )


: < ( U1 U2 -- F ) ( LEAVES A TRUE FLAG IF U1 < U2 )
    CONST?
    IF                    ( CONSTANT OPTIMIZATION POSSIBLE? )
        KILLCONST         ( SUPPRESS CONSTANT STACKING      )
        CONST?            ( IS THERE A PREVIOUS CONSTANT?   )
        IF
            KILLCONST
            SWAP <        ( OPERANDS WERE IN REVERSE ORDER  )
            CONST,
            EXIT
        ELSE
                    SUBLW
        THEN
    ELSE
        INDF   ,F   SUBWF
    THEN

        0FF         MOVLW ( TRUE        )
        STATUS Z    BTFSS ( IS IT ZERO? )
        STATUS C    BTFSC ( IS IS LESS? )
        CLRW              ( FALSE       )
        FSR    ,F   INCF
;


: <> ( N1 N2 -- F ) ( LEAVES A TRUE FLAG IF N1 IS NOT EQUAL TO N2 )
    CONST?
    IF                    ( CONSTANT OPTIMIZATION POSSIBLE? )
        KILLCONST         ( SUPPRESS CONSTANT STACKING      )
        CONST?            ( IS THERE A PREVIOUS CONSTANT?   )
        IF
            KILLCONST
            <>            ( CALCULATE OPERATION RESULT      )
            CONST,
            EXIT
        ELSE
                    XORLW
        THEN
    ELSE
        INDF   ,F   XORWF
    THEN
                          ( OMIT THE 2 NEXT INSTRUCTIONS IF )
                          ( WE DON'T CARE FOR VALUE OF TRUE )
(        STATUS Z    BTFSC
(        0FF         MOVLW ( 0FF IF TRUE )

        FSR    ,F   INCF
;


: = ( N1 N2 -- F ) ( LEAVES A TRUE FLAG IF N1 = N2 )
    CONST?
    IF                    ( CONSTANT OPTIMIZATION POSSIBLE? )
        KILLCONST         ( SUPPRESS CONSTANT STACKING      )
        CONST?            ( IS THERE A PREVIOUS CONSTANT?   )
        IF
            KILLCONST
            =             ( CALCULATE OPERATION RESULT      )
            CONST,
            EXIT
        ELSE
                    SUBLW
        THEN
    ELSE
        INDF   ,F   SUBWF
    THEN
                          ( OMIT THE 3 NEXT INSTRUCTIONS IF )
                          ( WE DON'T CARE FOR VALUE OF TRUE )
(        0FF         MOVLW ( 0FF IF TRUE  )
(        STATUS Z    BTFSS
(        0           MOVLW (  00 IF FALSE )

        FSR    ,F   INCF
;


: > ( U1 U2 -- F ) ( LEAVES A TRUE FLAG IF U1 > U2 )
    CONST?
    IF                    ( CONSTANT OPTIMIZATION POSSIBLE? )
        KILLCONST         ( SUPPRESS CONSTANT STACKING      )
        CONST?            ( IS THERE A PREVIOUS CONSTANT?   )
        IF
            KILLCONST
            SWAP >        ( OPERANDS WERE IN REVERSE ORDER  )
            CONST,
            EXIT
        ELSE
                    SUBLW
        THEN
    ELSE
        INDF   ,F   SUBWF
    THEN

        0FF         MOVLW ( TRUE        )
        STATUS Z    BTFSS ( IS IT ZERO? )
        STATUS C    BTFSS ( IS IS LESS? )
        CLRW              ( FALSE       )
        FSR    ,F   INCF
;


: 0= ( N -- F ) ( LOGICAL INVERT )
    CONST?
    IF                    ( CONSTANT OPTIMIZATION POSSIBLE?      )
        0= IF
            0FF     MOVLW
        ELSE
            0       MOVLW
        THEN
    ELSE
        0           IORLW
        0           MOVLW
        STATUS Z    BTFSC
        0FF         XORLW ( AVOID GENERATING A MOVLW, SEE CONST? )
    THEN
;



( FLOW CONTROL WORDS )

( THERE IS NO EXIT, USE ; INSTEAD )

FORTH

( IF ... ELSE ... THEN CONSTRUCT: FLAG IS 2 )

( THERE IS A GOOD DEAL OF OPTIMIZATIONS IN IF, BECAUSE )
( IT CAN BE PRECEDED BY SEVERAL LOGICAL OPERATORS      )

: IF ( -- ADDR CF ; F -- ) ( CONDITION FOR IF ... ELSE ... THEN )
    CONST?
    IF                    ( CONSTANT OPTIMIZATION POSSIBLE?   )
        KILLCONST         ( SUPPRESS CONSTANT STACKING        )
        IF                ( ALWAYS TRUE:                      )
            DONTPATCH     ( EXECUTE FOLLOWING CODE            )
        ELSE              ( ALWAYS FALSE:                     )
            DEADCODE      ( DEAD CODE, TRY TO SUPPRESS IT     )
            TOPATCH GOTO  ( IF NOT, SKIP FOLLOWING CODE       )
        THEN
        2 EXIT            ( LEAVE IF FLAG AND EXIT            )
    THEN

    <?
    IF                    ( < OPTIMIZATION POSSIBLE?          )
        STATUS Z    BTFSS
        STATUS C    BTFSC
        4 $+        GOTO
        FSR    ,F   INCF
    POP
        TOPATCH     GOTO  ( TO BE ADJUSTED LATER BY ELSE/THEN )
        FSR    ,F   INCF
    POP

        2 EXIT
    THEN

    >?
    IF                    ( > OPTIMIZATION POSSIBLE?          )
        STATUS Z    BTFSS
        STATUS C    BTFSS
        4 $+        GOTO
        FSR    ,F   INCF
    POP
        TOPATCH     GOTO  ( TO BE ADJUSTED LATER BY ELSE/THEN )
        FSR    ,F   INCF
    POP

        2 EXIT
    THEN

    0=?
    IF                    ( 0= OPTIMIZATION POSSIBLE?         )
        0           IORLW
        STATUS Z    BTFSS ( INVERT THE CONDITION CHECKING     )
        4 $+        GOTO
    POP
        TOPATCH     GOTO  ( TO BE ADJUSTED LATER BY ELSE/THEN )
    POP

        2 EXIT
    THEN

                          ( NO OPTIMIZATIONS POSSIBLE         )
        0           IORLW
        STATUS Z    BTFSC
        4 $+        GOTO
    POP
        TOPATCH     GOTO  ( TO BE ADJUSTED LATER BY ELSE/THEN )
    POP
    2                     ( FLAG FOR IF/ELSE/THEN             )
;


( ALTERNATIVE IF. AIF DOESN'T ALTER THE )
( STACK, GETTING RID OF THE NEED FOR    )
( ?DUP. DON'T FORGET TO USE DROP AFTER  )
( ELSE WHEN USING AIF. DEFINE           )
( : AIF DUP [COMPILE] IF ; IN THE HOST  )
( FORTH FOR TESTING AND DEBUGGING APPS  )

: AIF ( -- ADDR CF ; F -- F ) ( ALTERNATIVE IF FOR AIF ... ELSE ... THEN )
    CONST?
    IF                    ( CONSTANT OPTIMIZATION POSSIBLE?   )
        KILLCONST         ( SUPPRESS CONSTANT STACKING        )
        IF                ( ALWAYS TRUE:                      )
            DONTPATCH     ( EXECUTE FOLLOWING CODE            )
        ELSE              ( ALWAYS FALSE:                     )
            DEADCODE      ( DEAD CODE, TRY TO SUPPRESS IT     )
            TOPATCH GOTO  ( IF NOT, SKIP FOLLOWING CODE       )
        THEN
        2 EXIT            ( LEAVE IF FLAG AND EXIT            )
    THEN

    <?
    IF                    ( < OPTIMIZATION POSSIBLE?          )
        STATUS Z    BTFSS
        STATUS C    BTFSC
        2 $+        GOTO
        FSR    ,F   INCF
        TOPATCH     GOTO  ( TO BE ADJUSTED LATER BY ELSE/THEN )
        FSR    ,F   INCF

        2 EXIT
    THEN

    >?
    IF                    ( > OPTIMIZATION POSSIBLE?          )
        STATUS Z    BTFSS
        STATUS C    BTFSS
        2 $+        GOTO
        FSR    ,F   INCF
        TOPATCH     GOTO  ( TO BE ADJUSTED LATER BY ELSE/THEN )
        FSR    ,F   INCF

        2 EXIT
    THEN

    0=?
    IF                    ( 0= OPTIMIZATION POSSIBLE?         )
        0           IORLW
        STATUS Z    BTFSS ( INVERT THE CONDITION CHECKING     )
        TOPATCH     GOTO  ( TO BE ADJUSTED LATER BY ELSE/THEN )

        2 EXIT
    THEN

                          ( NO OPTIMIZATIONS POSSIBLE         )
        0           IORLW
        STATUS Z    BTFSC
        TOPATCH     GOTO  ( TO BE ADJUSTED LATER BY ELSE/THEN )
    2                     ( FLAG FOR IF/ELSE/THEN             )
;


( DEAD CODE MARKING FAILS ONLY WHEN IF FLAG IS TRUE AND THERE IS AN ELSE )

: ELSE ( ADDR1 CF -- ADDR2 CF ; -- ) ( FALSE CONDITION BRANCH FOR IF ... ELSE ... THEN )
    2 ?PAIRS
    DEADCODE?             ( CHECK FOR DEAD CODE          )
    IF                    ( IS THERE DEAD CODE?          )
        KILLDEADCODE      ( SUPPRESS IT                  )
        DONTPATCH
    ELSE
        TOPATCH     GOTO  ( TO BE ADJUSTED LATER BY THEN )
        SWAP PATCHJUMP    ( ADJUST CONDITIONAL FLOW      )
    THEN
    2
;


: THEN ( ADDR CF -- ; -- ) ( ENDS IF ... ELSE ... THEN )
    2 ?PAIRS         ( CHECK FOR PREVIOUS IF   )
    DEADCODE?        ( CHECK FOR DEAD CODE     )
    IF               ( IS THERE DEAD CODE?     )
        KILLDEADCODE ( SUPPRESS IT             )
    ELSE
        PATCHJUMP    ( ADJUST CONDITIONAL FLOW )
        NOOPT        ( CAN'T OPTIMIZE HERE     )
    THEN
;


( BEGIN FOR BEGIN ... AGAIN, BEGIN ... UNTIL )
( AND BEGIN ... WHILE ... REPEAT LOOPS       )

: BEGIN ( -- ADDR CF ; -- ) ( STARTS BEGIN LOOP FLAG IS 1 )
    PHERE ( FOR LATER JUMPING )
    1
;


( BEGIN ... AGAIN LOOP: FLAG IS 1 )

: AGAIN ( ADDR CF -- ; -- ) ( ENDS BEGIN ... AGAIN LOOP )
    1 ?PAIRS
                    GOTO
;


( BEGIN ... UNTIL LOOP: FLAG IS 1 )

: UNTIL ( ADDR CF -- ; F -- ) ( ENDS BEGIN ... UNTIL LOOP )
    1 ?PAIRS
    CONST?
    IF                    ( CONSTANT OPTIMIZATION POSSIBLE?   )
        KILLCONST         ( SUPPRESS CONSTANT STACKING        )
        IF                ( ALWAYS TRUE:                      )
                    GOTO  ( LOOP ALWAYS                       )
        ELSE              ( ALWAYS FALSE:                     )
            DROP          ( DON'T LOOP AND DROP PATCH ADDRESS )
        THEN
    ELSE
        0           IORLW
        STATUS Z    BTFSC
        4 $+        GOTO
        POP
                    GOTO
        POP
    THEN
;


( BEGIN ... WHILE ... REPEAT LOOP: FLAGS ARE 1, 3 )

: WHILE ( ADDR1 CF -- ADDR1 ADDR2 CF ; F -- ) ( CONDITION FOR BEGIN ... WHILE ... REPEAT )
    1 ?PAIRS
    [ PICFORTH ] [COMPILE] IF [ FORTH ]
    1 +
;


: REPEAT ( ADDR CF -- ; -- ) ( ENDS BEGIN ... WHILE ... REPEAT LOOP )
    3 ?PAIRS
    DEADCODE?             ( CHECK FOR DEAD CODE          )
    IF                    ( IS THERE DEAD CODE?          )
        KILLDEADCODE      ( SUPPRESS IT                  )
        DONTPATCH
    ELSE
        SWAP        GOTO
        PATCHJUMP         ( ADJUST CONDITIONAL FLOW      )
    THEN
;



( DEFINING WORDS )


( : DOESN'T CHECK COMPILING STATE, WHICH )
( ALLOWS FOR MULTIPLE ENTRY POINT WORDS  )

: : ( -- ) ( CREATES A NAMED SUBROUTINE ENTRY POINT )
    CREATE
        $ @ ,      ( SUBROUTINE START                     )
        NOOPT      ( DON'T OPTIMIZE HERE                  )
        NODEADCODE ( AN ENTRY POINT IS NOT DEAD CODE      )
    DOES>
        @ CALL     ( PERFORMS THE CALL ON WORD INVOCATION )
;


( ; CAN BE USED MORE THAN ONCE IN A WORD )
( IN ORDER TO MAKE MULTIPLE RETURN POINT )
( WORDS                                  )

: ; ( -- ) ( CREATES A RETURN POINT )
( HAS MID-RANGE PIC SPECIFIC OPTIMIZATIONS )
    CALL?             ( PREVIOUS CALL?          )
    IF
        CALL>JUMP     ( MAKE IT A JUMP;         )
                      ( THE CALLED WILL RETURN, )
                      ( SAVING ONE STACK LEVEL  )

        OPT?          ( OPTIMIZATION POSSIBLE?  )
    ELSE
        RETURN?       ( PREVIOUS RETURN?        )
    THEN

    0= IF ( NOT OPTIMIZABLE OR NOT PREVIOUS RETURN )
        RETURN
    THEN
;

( NOTES:                                          )

(  - WHEN CALLING TO A SECOND ENTRY POINT FROM    )
(    THE SAME WORD, A ; IS NEEDED IN ORDER NOT TO )
(    DRAIN THE RETURN STACK. E.G.:                )

(    : ENTRY1                                     )
(        ...                                      )
(    : ENTRY2                                     )
(        ...                                      )
(        IF                                       )
(            ENTRY2 ;                             )
(        THEN                                     )
(        ...                                      )
(    ;                                            )

(    THIS IS NOT STRICT RECURSIVITY, BUT RATHER   )
(    SOME SORT OF LOOPING.                        )



( PIC SYSTEM START )

5 ORG ( PRESERVES FOR MAIN PROGRAM JUMP AND INTERRUPT JUMP )



( PIC FORTH SUBROUTINES )

PICFORTH

( MEMORY ACCESS )


: (!) ( N ADDR -- ) ( STORES N IN ADDR )
        TMP1        MOVWF
        INDF   ,W   MOVF
        TMP2        MOVWF
        FSR    ,W   MOVF   
        TMP3        MOVWF  
        TMP1   ,W   MOVF
        FSR         MOVWF   
        TMP2   ,W   MOVF
        INDF        MOVWF
        TMP3   ,W   INCF
        FSR         MOVWF   
        INDF   ,W   MOVF
        FSR    ,F   INCF
;


: (+!) ( N ADDR -- ) ( ADDS N TO THE CONTENTS OF ADDR )
        TMP1        MOVWF
        INDF   ,W   MOVF
        TMP2        MOVWF
        FSR    ,W   MOVF
        TMP3        MOVWF
        TMP1   ,W   MOVF
        FSR         MOVWF
        TMP2   ,W   MOVF
        INDF   ,F   ADDWF
        TMP3   ,W   INCF
        FSR         MOVWF
    POP
;


: (@) ( ADDR -- N ) ( FETCHES CONTENTS OF ADDR )
        TMP1        MOVWF   
        FSR    ,W   MOVF   
        TMP2        MOVWF 
        TMP1   ,W   MOVF
        FSR         MOVWF   
        INDF   ,W   MOVF
        TMP1        MOVWF
        TMP2   ,W   MOVF
        FSR         MOVWF
        TMP1   ,W   MOVF
;


( ARITHMETIC SUBROUTINES )

: (*) ( U1 U2 -- U1*U2 ) ( MULTIPLIES U1*U2 8*8=8 BITS )
        TMP2        MOVWF
        8           MOVLW
        TMP1        MOVWF
        INDF   ,W   MOVF
        INDF        CLRF
LABEL   STAR.1
        STATUS C    BCF
        TMP2   0    BTFSC
        INDF   ,F   ADDWF
        INDF   ,F   RRF 
        TMP2   ,F   RRF
        TMP1   ,F   DECFSZ
        STAR.1      GOTO
        FSR    ,F   INCF
        TMP2   ,W   MOVF
;


: (/MOD) ( U1 U2 -- U1\U2 U1/U2 ) ( DIVIDES U1/U2, U1\U2 IS THE REMAINDER )
        TMP3        MOVWF  ( U2 )
        INDF   ,W   MOVF
        TMP1        MOVWF  ( U1 )
        INDF        CLRF   ( REMAINDER )
        8           MOVLW  ( LOOP COUNTER )
        TMP2        MOVWF  ( TO INDEX )
LABEL   SLASHM.0
        TMP1   ,W   RLF    ( ROTATE U1 )
        INDF   ,F   RLF    ( INTO REMAINDER )
        TMP3   ,W   MOVF   ( GET U2 )
        INDF   ,F   SUBWF
        STATUS C    BTFSC
FLABEL  SLASHM.1    GOTO
        INDF   ,F   ADDWF
        STATUS C    BCF
SLASHM.1
        TMP1   ,F   RLF    ( RESULT IN TMP1 )
        TMP2   ,F   DECFSZ
        SLASHM.0    GOTO
        TMP1   ,W   MOVF   ( RESULT, REMAINDER ON TOS-1 )
        RETURN
;


: (LSHIFT) ( U1 U2 -- U3 ) ( LEFT  SHIFTS U2 TIMES U1 GIVING U3 )
        0FF         XORLW ( INVERTS U2, SO 0 WILL BE 7, ETC  )
        7           ANDLW ( MASKS U2 IN ORDER TO MAKE IT < 7 )
        TMP2        MOVWF
        FSR    ,F   INCF
        INDF   ,W   MOVF
        TMP1        MOVWF
        STATUS C    BCF
        TMP2   ,W   RLF   ( MULTIPLIES W BY 2                )
        PCL         ADDWF

        STATUS C    BCF
        TMP1   ,W   RLF
        STATUS C    BCF
        TMP1   ,W   RLF
        STATUS C    BCF
        TMP1   ,W   RLF
        STATUS C    BCF
        TMP1   ,W   RLF
        STATUS C    BCF
        TMP1   ,W   RLF
        STATUS C    BCF
        TMP1   ,W   RLF
        STATUS C    BCF
        TMP1   ,W   RLF

        FSR    ,F   INCF  ( LEAVES RESULT IN THE STACK       )
;


: (RSHIFT) ( U1 U2 -- U3 ) ( RIGHT SHIFTS U2 TIMES U1 GIVING U3 )
        0FF         XORLW ( INVERTS U2, SO 0 WILL BE 7, ETC  )
        7           ANDLW ( MASKS U2 IN ORDER TO MAKE IT < 7 )
        TMP2        MOVWF
        FSR    ,F   INCF
        INDF   ,W   MOVF
        TMP1        MOVWF
        STATUS C    BCF
        TMP2   ,W   RLF   ( MULTIPLIES W BY 2                )
        PCL         ADDWF

        STATUS C    BCF
        TMP1   ,W   RRF
        STATUS C    BCF
        TMP1   ,W   RRF
        STATUS C    BCF
        TMP1   ,W   RRF
        STATUS C    BCF
        TMP1   ,W   RRF
        STATUS C    BCF
        TMP1   ,W   RRF
        STATUS C    BCF
        TMP1   ,W   RRF
        STATUS C    BCF
        TMP1   ,W   RRF

        FSR    ,F   INCF  ( LEAVES RESULT IN THE STACK       )
;



( PIC FORTH FORTH DEFINITIONS THAT DEPEND ON THE SUBROUTINES )

FORTH

( ARITHMETIC WORDS )

: / ( U1 U2 -- U1/U2 ) ( DIVIDES U1/U2 )
    CONST?
    IF                    ( CONSTANT OPTIMIZATION POSSIBLE? )
        KILLCONST         ( SUPPRESS CONSTANT STACKING      )
        CONST?            ( IS THERE A PREVIOUS CONSTANT?   )
        IF
            KILLCONST
            SWAP /        ( CALCULATE OPERATION RESULT      )
            CONST,
        ELSE
            CONST,
            [COMPILE] (/MOD) [ PICFORTH ] [COMPILE] NIP [ FORTH ]
        THEN
    ELSE
        [COMPILE] (/MOD) [ PICFORTH ] [COMPILE] NIP [ FORTH ]
    THEN
;


: /MOD ( U1 U2 -- U1\U2 U1/U2 ) ( DIVIDES U1/U2, U1\U2 IS THE REMAINDER )
    CONST?
    IF                    ( CONSTANT OPTIMIZATION POSSIBLE? )
        KILLCONST         ( SUPPRESS CONSTANT STACKING      )
        CONST?            ( IS THERE A PREVIOUS CONSTANT?   )
        IF
            KILLCONST
            SWAP /MOD     ( CALCULATE OPERATION RESULT      )
            CONST,
        ELSE
            CONST,
            [COMPILE] (/MOD)
        THEN
    ELSE
        [COMPILE] (/MOD)
    THEN
;


: * ( N1 N2 -- N1*N2 ) ( MULTIPLIES N1 AND N2 )
    CONST?
    IF                    ( CONSTANT OPTIMIZATION POSSIBLE? )
        KILLCONST         ( SUPPRESS CONSTANT STACKING      )
        CONST?            ( IS THERE A PREVIOUS CONSTANT?   )
        IF
            KILLCONST
            *             ( CALCULATE OPERATION RESULT      )
            CONST,
        ELSE
            CONST,
            [COMPILE] (*)
        THEN
    ELSE
        [COMPILE] (*)
    THEN
;


: MOD ( U1 U2 -- U1\U2 ) ( CALCULATES THE REMAINDER OF U1/U2 )
    /MOD DROP
;


( MEMORY ACCESS WORDS )

: @ ( ADDR -- N ) ( FETCHES CONTENTS AT ADDR )
    CONST?
    IF                ( CONSTANT OPTIMIZATION POSSIBLE? )
        FETCH         ( FETCH THE VALUE                 )
    ELSE
        [COMPILE] (@)
    THEN
;


( HELPER FOR +! )

: INCDECLOOP ( ADDR N -- ) ( GENERATES CODE FOR +! INCF/DECF LOOPS )
    DUP 80 AND           ( <0?  )
    IF
        ABS8 0 DO
            DUP ,F DECF
        LOOP
    ELSE                 ( >=0  )
        0 DO
            DUP ,F INCF
        LOOP
   THEN

   DROP                  ( ADDR )
;



( THERE IS AN ADDITIONAL OPTIMIZATION FOR +! DEPENDING ON THE VALUE OF N   )
( AS THE BEST GENERAL CASE MAKES FOR 5 INSTRUCTIONS. SO IF |N| < 4, WE     )
( CAN GET 3 INCF/DECF INSTRUCTIONS. IF |N| = 4, WE OPT FOR THE GENERAL     )
( OPTIMIZATION, AS IT CAN OPTIMIZE A FOLLOWING +!                          )

( E.G.: 4 CONST, MYVAR1 +! 5 CONST, MYVAR2 +! IS BETTER OPTIMIZED THIS WAY )

( OF COURSE, ALL OF THIS CHANGES IF THE VARIABLE IS IN BANK 1, SO THE      )
( NUMBER OF GENERATED INSTRUCTIONS VARY, BUT THE PRINCIPLE IS THE SAME     )

: +! ( N ADDR -- ) ( ADDS N TO THE CONTENTS OF ADDR )
    CONST?
    IF                               ( CONSTANT VALUE OPTIMIZATION POSSIBLE? )
        KILLCONST                    ( THE VARIABLE ADDRESS                  )
        CONST?
        IF                           ( CONSTANT VALUE?                       )
            KILLCONST
            DUP 0=
            IF
                EXIT                 ( IF N = 0, THERE IS NOTHING TO DO      )
            THEN

            DUP ABS8 4 <             ( SPECIAL OPTIMIZATION CASE: INCF/DECF  )
            IF
                OVER BANK1 SWAP      ( CHANGE TO BANK 1 IF NEEDED            )
                INCDECLOOP           ( MAKE LOOPS                            )
                BANK0                ( CHANGE TO BANK 0 IF NEEDED            )
            ELSE                     ( |N| >= 5                              )
                OVER                 ( STACK IS NOW: ADDR N ADDR             )
                SAVETOS
                FETCH                ( FETCH THE VALUE                       )
                        ADDLW        ( ADD VALUE N                           )
                STORE                ( AND STORE IT                          )
                RESTORETOS
            THEN
        ELSE
            DUP
            SAVETOS
            FETCH                    ( FETCH THE VALUE                       )
            TMP1   ,W   ADDF         ( ADD SAVED TOS                         )
            STORE                    ( STORE THE VALUE IN W                  )
            POP
        THEN
    ELSE
        [COMPILE] (+!)
    THEN
;


: ! ( N ADDR -- ) ( STORES N AT ADDR )
    CONST?
    IF                           ( CONSTANT VALUE OPTIMIZATION POSSIBLE? )
        KILLCONST                ( THE CONSTANT/VARIABLE ADDRESS VALUE   )
        CONST?
        IF                       ( CONSTANT ADDRESS?                     )
            KILLCONST
            SAVETOS
                        MOVLW
            STORE                ( STORE THE VALUE IN W                  )
            RESTORETOS
        ELSE
            STORE                ( STORE THE VALUE IN W                  )
            POP
        THEN
    ELSE
        [COMPILE] (!)
    THEN
;


: LSHIFT ( U1 U2 -- U3 ) ( LEFT  SHIFTS U2 TIMES U1 GIVING U3 )
    CONST?
    IF                             ( CONSTANT OPTIMIZATION POSSIBLE? )
        KILLCONST                  ( SUPPRESS CONSTANT STACKING      )
        CONST?                     ( IS THERE A PREVIOUS CONSTANT?   )
        IF
            KILLCONST
            SWAP 07 AND LSHIFT     ( CALCULATE OPERATION RESULT      )
            CONST,
        ELSE
            CONST,                 ( U2                              )
            [COMPILE] (LSHIFT)
        THEN                       ( TWO CONSTANT OPERANDS           )
    ELSE                           ( NO CONSTANT OPERAND             )
        [COMPILE] (LSHIFT)
    THEN                           ( ANY CONSTANT OPERAND            )
;


: RSHIFT ( U1 U2 -- U3 ) ( RIGHT SHIFTS U2 TIMES U1 GIVING U3 )
    CONST?
    IF                             ( CONSTANT OPTIMIZATION POSSIBLE? )
        KILLCONST                  ( SUPPRESS CONSTANT STACKING      )
        CONST?                     ( IS THERE A PREVIOUS CONSTANT?   )
        IF
            KILLCONST
            SWAP 07 AND RSHIFT     ( CALCULATE OPERATION RESULT      )
            CONST,
        ELSE
            SWAP
            CONST,                 ( U1                              )
            CONST,                 ( U2                              )
            [COMPILE] (RSHIFT)
        THEN                       ( TWO CONSTANT OPERANDS           )
    ELSE                           ( NO CONSTANT OPERAND             )
        [COMPILE] (RSHIFT)
    THEN                           ( ANY CONSTANT OPERAND            )
;



PICFORTH
