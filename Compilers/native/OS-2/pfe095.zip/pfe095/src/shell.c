/*
 * This file is part of the portable Forth environment written in ANSI C.
 * Copyright (C) 1993  Dirk Uwe Zoller
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 * This file is version 0.9.5 of 15-May-94
 * Check for the latest version of this package via anonymous ftp at
 *	roxi.rz.fht-mannheim.de
 *	/pub/unix/languages/pfe-VERSION.tar.gz
 * Please direct any comments via internet to
 *	duz@roxi.rz.fht-mannheim.de.
 * Thank You.
 */
/*
 * shell.c ---	 os commands for pfe
 * (duz 07May94)
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <fcntl.h>
#ifdef EMX
# include <io.h>
#else
# include <unistd.h>
# include <utime.h>
#endif
#include <sys/types.h>
#include <sys/stat.h>

#include "forth.h"
#include "support.h"
#include "compiler.h"


#define strpush(X) (*--sp = (Cell)(X), *--sp = strlen (p))

#ifndef PATH_MAX
#define PATH_MAX 256
#endif


#if !EMX

Code (getpid)	{ *--sp = getpid (); }
Code (getuid)	{ *--sp = getuid (); }
Code (geteuid)	{ *--sp = geteuid (); }
Code (getgid)	{ *--sp = getgid (); }
Code (umask)	{ *sp = umask (*sp); }


Code (home)
{
  char *p = getenv ("HOME");
  strpush (p);
}

Code (user)
{
  char *p = getenv ("USER");
  strpush (p);
}

#endif /* not EMX */

Code (cwd)
{
  char *p = getcwd (PAD, PATH_MAX);
  strpush (p);
}

Code (pwd)
{
  outs (getcwd (PAD, PATH_MAX));
  space_();
}

static void
do_one (char *p, int (*syscall) (const char *))
{
  char name [PATH_MAX];
  store_asciiz (p + 1, *(Byte *)p, name, sizeof name);
  if (syscall (name))
    file_error ();
}

#define SHWORD1(X)	Code (X##_execution)			\
			{					\
			  do_one ((char *)ip, X);		\
			  SKIP_STRING;				\
			}					\
			Code (X)				\
			{					\
			  if (STATE)				\
			    compile1 (),			\
			    alloc_word (' ');			\
			  else					\
			    do_one (word (' '), X);		\
			}					\
			COMPILES (X, X##_execution,		\
				  SKIPS_STRING, DEFAULT_STYLE)

static void
do_two (char *p1, char *p2, int (*syscall) (const char *, const char *))
{
  char nm1 [PATH_MAX], nm2 [PATH_MAX];
  store_asciiz (p1 + 1, *(Byte *)p1, nm1, sizeof nm1);
  store_asciiz (p2 + 1, *(Byte *)p2, nm2, sizeof nm2);
  if (syscall (nm1, nm2))
    file_error ();
}

#define SHWORD2(X)	Code (X##_execution)			\
			{					\
			  char *p = (char *)ip;			\
			  SKIP_STRING;				\
			  do_two (p, (char *)ip, X);		\
			  SKIP_STRING;				\
			}					\
			Code (X)				\
			{					\
			  if (STATE)				\
			    compile1 (),			\
			    alloc_word (' '),			\
			    alloc_word (' ');			\
			  else					\
			    strcpy (PAD, word (' ')),		\
			    do_two (PAD, word (' '), X);	\
			}					\
			COMPILES (X, X##_execution,		\
				  SKIPS_2STRINGS, DEFAULT_STYLE)

#ifdef S_IRUSR
#define RWALL	(S_IRUSR | S_IWUSR | \
		 S_IRGRP | S_IWGRP | \
		 S_IROTH | S_IWOTH)
#define RWXALL	(RWALL | S_IXUSR | S_IXGRP | S_IXOTH)
#else
#define RWALL	0666
#define RWXALL	0777
#endif

static int
md (const char *s)
{
  return mkdir (s, RWXALL);
}

static int
touch (const char *s)
{
  int result;

#if !EMX
  if (access (s, F_OK))
    return utime (s, NULL);
#endif
  result = open (s, O_WRONLY | O_CREAT, RWALL);
  if (result < 0)
    return result;
  close (result);
  return 0;
}

static int
copy (const char *src, const char *dst)
{
  return file_copy (src, dst, LONG_MAX) == (fpos_t)-1;
}

static int
ls (const char *p)
{
  cr_();
  return systemf (LSCMD" %s", p);
}

static int
ll (const char *p)
{
  cr_();
  return systemf (LLCMD" %s", p);
}

SHWORD1(remove);
SHWORD1(touch);
SHWORD1(chdir);
SHWORD1(rmdir);
SHWORD1(md);
SHWORD1(ls);
SHWORD1(ll);
SHWORD2(file_move);
SHWORD2(copy);
#if !EMX
SHWORD2(link);
#endif

LISTWORDS (shell) =
{
  /*SC ("ARGC",		_argc),
    SC ("ARGV",		_argv),
    */
#if !EMX
  CO ("$$",		getpid),
  CO ("$UID",		getuid),
  CO ("$EUID",		geteuid),
  CO ("$GID",		getgid),
  CO ("UMASK",		umask),
  CO ("$HOME",		home),
  CO ("$USER",		user),
#endif
  CO ("$CWD",		cwd),
  CO ("PWD",		pwd),
  CS ("RM",		remove),
  CS ("TOUCH",		touch),
  CS ("CD",		chdir),
  CS ("RMDIR",		rmdir),
  CS ("MKDIR",		md),
  CS ("MV",		file_move),
  CS ("CP",		copy),
#if !EMX
  CS ("LN",		link),
#endif
  CS ("LL",		ll),
  CS ("LS",		ls),
};
COUNTWORDS (shell, "Shell words");
