/*******************************************************************
** v m . c
** Forth Inspired Command Language - virtual machine methods
** Author: John Sadler
** Created: 19 July 1997
** 
*******************************************************************/
/*
** This file implements the virtual machine of FICL. Each virtual
** machine retains the state of an interpreter. A virtual machine
** owns a pair of stacks for parameters and return addresses, as
** well as a pile of state variables and the two dedicated registers
** of the interp.
*/

#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "ficl.h"

static char digits[] = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";


/**************************************************************************
                        v m B r a n c h R e l a t i v e 
** 
**************************************************************************/
void vmBranchRelative(FICL_VM *pVM, int offset)
{
    pVM->ip += offset;
    return;
}


/**************************************************************************
                        v m C r e a t e
** 
**************************************************************************/
FICL_VM *vmCreate(FICL_VM *pVM, unsigned nPStack, unsigned nRStack)
{
    if (pVM == NULL)
    {
        pVM = (FICL_VM *)ficlMalloc(sizeof (FICL_VM));
        pVM->pStack = NULL;
        pVM->rStack = NULL;
        pVM->link   = NULL;
    }
    assert (pVM);

    if (pVM->pStack)
        stackDelete(pVM->pStack);
    pVM->pStack = stackCreate(nPStack);

    if (pVM->rStack)
        stackDelete(pVM->rStack);
    pVM->rStack = stackCreate(nRStack);

    pVM->textOut = ficlTextOut;

    vmReset(pVM);
    return pVM;
}


/**************************************************************************
                        v m D e l e t e
** 
**************************************************************************/
void vmDelete (FICL_VM *pVM)
{
    if (pVM)
    {
        ficlFree(pVM->pStack);
        ficlFree(pVM->rStack);
        ficlFree(pVM);
    }

    return;
}


/**************************************************************************
                        v m E x e c u t e
** 
**************************************************************************/
void vmExecute(FICL_VM *pVM, FICL_WORD *pWord)
{
    pVM->runningWord = pWord;
    pWord->code(pVM);
    return;
}


/**************************************************************************
                              v m G e t W o r d
** Parses a space delimited word from the tib and returns its length
** after adjusting tib to point ot the first char of the word. If there's
** nothing of interest in the tib, returns zero.
**************************************************************************/
STRINGINFO vmGetWord(FICL_VM *pVM)
{
    char *pSrc  = vmGetInBuf(pVM);
    STRINGINFO si;
    char ch;

    pSrc = skipSpace(pSrc);
    si.cp = pSrc;
    si.count = 0;

    for (ch = *pSrc; ch != '\0' && !isspace(ch); ch = *++pSrc)
    {
        si.count++;
    }

    vmUpdateTib(pVM, pSrc);
    return si;
}


/**************************************************************************
                        v m G e t W o r d T o P a d
** 
**************************************************************************/
int vmGetWordToPad(FICL_VM *pVM)
{
    char *pSrc  = vmGetInBuf(pVM);
    char *pDest = pVM->pad;
    char ch;

    pSrc = skipSpace(pSrc);

    for (ch = *pSrc; ch != '\0' && !isspace(ch); ch = *++pSrc)
    {
        *pDest++ = ch;
    }

    vmUpdateTib(pVM, pSrc);
    *pDest++ = '\0';
    return pDest - pVM->pad;
}


/**************************************************************************
                        v m P u s h I P
** 
**************************************************************************/
void vmPushIP(FICL_VM *pVM, IPTYPE newIP)
{
    stackPushPtr(pVM->rStack, (void *)pVM->ip);
    pVM->ip = newIP;
    return;
}


/**************************************************************************
                        v m P o p I P
** 
**************************************************************************/
void vmPopIP(FICL_VM *pVM)
{
    pVM->ip = (IPTYPE)(stackPopPtr(pVM->rStack));
    return;
}


/**************************************************************************
                        v m Q u i t
** 
**************************************************************************/
void vmQuit(FICL_VM *pVM)
{
    static FICL_WORD *pInterp = NULL;
    if (!pInterp)
        pInterp = ficlLookup("interpret");
    assert(pInterp);

    stackReset(pVM->rStack);
    pVM->fRestart    = 0;
    pVM->ip          = &pInterp;
    pVM->runningWord = pInterp;
    pVM->state       = INTERPRET;
    pVM->tib.cp      = NULL;
    pVM->tib.index   = 0;
    pVM->pad[0]      = '\0';
    pVM->sourceID    = 0;
    return;
}


/**************************************************************************
                        v m R e s e t 
** 
**************************************************************************/
void vmReset(FICL_VM *pVM)
{
    vmQuit(pVM);
    stackReset(pVM->pStack);
    pVM->base        = 10;
    return;
}


/**************************************************************************
                        v m S e t T e x t O u t
** Binds the specified output callback to the vm. If you pass NULL,
** binds the default output function (ficlTextOut)
**************************************************************************/
void vmSetTextOut(FICL_VM *pVM, OUTFUNC textOut)
{
    if (textOut)
        pVM->textOut = textOut;
    else
        pVM->textOut = ficlTextOut;

    return;
}


/**************************************************************************
                        v m P u s h T i b
** Binds the specified input string to the VM and clears >IN (the index)
**************************************************************************/
void vmPushTib(FICL_VM *pVM, char *text, TIB *pSaveTib)
{
    if (pSaveTib)
    {
        *pSaveTib = pVM->tib;
    }

    pVM->tib.cp = text;
    pVM->tib.index = 0;
}


void vmPopTib(FICL_VM *pVM, TIB *pTib)
{
    if (pTib)
    {
        pVM->tib = *pTib;
    }
    return;
}


/**************************************************************************
                        v m T e x t O u t
** Feeds text to the vm's output callback
**************************************************************************/
void vmTextOut(FICL_VM *pVM, char *text, int fNewline)
{
    assert(pVM);
    assert(pVM->textOut);
    (pVM->textOut)(pVM, text, fNewline);

    return;
}


/**************************************************************************
                        v m T h r o w
** 
**************************************************************************/
void vmThrow(FICL_VM *pVM, int except)
{
    longjmp(*(pVM->pState), except);
}


/**************************************************************************
                        w o r d I s I m m e d i a t e
** 
**************************************************************************/
int wordIsImmediate(FICL_WORD *pFW)
{
    return ((pFW != NULL) && (pFW->flags & FW_IMMEDIATE));
}


/**************************************************************************
                        w o r d I s C o m p i l e O n l y
** 
**************************************************************************/
int wordIsCompileOnly(FICL_WORD *pFW)
{
    return ((pFW != NULL) && (pFW->flags & FW_COMPILE));
}


/**************************************************************************
                        s t r r e v
** 
**************************************************************************/
char *strrev( char *string )    
{                               /* reverse a string in-place */
    int i = strlen(string);
    char *p1 = string;          /* first char of string */
    char *p2 = string + i - 1;  /* last non-NULL char of string */
    char c;

    if (i > 1)
    {
        while (p1 < p2)
        {
            c = *p2;
            *p2 = *p1;
            *p1 = c;
            p1++; p2--;
        }
    }
        
    return string;
}


/**************************************************************************
                        d i g i t _ t o _ c h a r
** 
**************************************************************************/
char digit_to_char(int value)
{
    return digits[value];
}


/**************************************************************************
                        l t o a
** 
**************************************************************************/
char *ltoa( INT32 value, char *string, int radix )
{                               /* convert long to string, any base */
    char *cp = string;
    int sign = ((radix == 10) && (value < 0));
    UNSQR result;
    UNS64 v;

    assert(radix > 1);
    assert(radix < 37);
    assert(string);

    if (sign)
        value = -value;

    if (value == 0)
        *cp++ = '0';
    else
    {
        v.hi = 0;
        v.lo = (UNS32)value;
        while (v.lo)
        {
            result = ficlLongDiv(v, (UNS32)radix);
            *cp++ = digits[result.rem];
            v.lo = result.quot;
        }
    }

    if (sign)
        *cp++ = '-';

    *cp++ = '\0';

    return strrev(string);
}


/**************************************************************************
                        u l t o a
** 
**************************************************************************/
char *ultoa(UNS32 value, char *string, int radix )
{                               /* convert long to string, any base */
    char *cp = string;
    UNS64 ud;
    UNSQR result;

    assert(radix > 1);
    assert(radix < 37);
    assert(string);

    if (value == 0)
        *cp++ = '0';
    else
    {
        ud.hi = 0;
        ud.lo = value;
        result.quot = value;

        while (ud.lo)
        {
            result = ficlLongDiv(ud, (UNS32)radix);
            ud.lo = result.quot;
            *cp++ = digits[result.rem];
        }
    }

    *cp++ = '\0';

    return strrev(string);
}


/**************************************************************************
                        c a s e F o l d
** Case folds a NULL terminated string in place. All characters
** get converted to lower case.
**************************************************************************/
char *caseFold(char *cp)
{
    char *oldCp = cp;

    while (*cp)
    {
        if (isupper(*cp))
            *cp = (char)tolower(*cp);
        cp++;
    }

    return oldCp;
}


/**************************************************************************
                        s t r i n c m p
** 
**************************************************************************/
int strincmp(char *cp1, char *cp2, FICL_COUNT count)
{
    int i = 0;
    char c1, c2;

    for (c1 = *cp1, c2 = *cp2;
        ((i == 0) && count && c1 && c2);
        c1 = *++cp1, c2 = *++cp2, count--)
    {
        i = tolower(c1) - tolower(c2);
    }

    return i;
}



/**************************************************************************
                                s k i p S p a c e
** Given a string pointer, returns a pointer to the first non-space
** char of the string, or to the NULL terminator if no such char found.
**************************************************************************/
char *skipSpace(char *cp)
{
    assert(cp);

    while (isspace(*cp))
        cp++;

    return cp;
}


char *vmGetString(FICL_VM *pVM, FICL_STRING *sp, char delimiter)
{
    char *pDest;
    FICL_COUNT n = 0;
    char *pSrc = vmGetInBuf(pVM);
    char ch;

    pSrc = skipSpace(pSrc);
    pDest = sp->text;

    for (ch = *pSrc; (ch != '\0') && (ch != delimiter); ch = *++pSrc)
    {
        *pDest++ = ch;
        n++;
    }

    sp->count = n;
    *pDest++ = '\0';

    if (ch == delimiter)
        pSrc++;

    vmUpdateTib(pVM, pSrc);
    return pDest;
}

