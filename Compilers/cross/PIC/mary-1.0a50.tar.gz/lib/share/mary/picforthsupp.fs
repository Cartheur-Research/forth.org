( FORTH MID-RANGE PIC FORTH SUPPORT, PART OF THE GLAZZ PROJECT. )
( WRITTEN BY FRANCISCO RODRIGO ESCOBEDO ROBLES ON 1999DEC28.    )
( LAST REVISED ON 2000FEB21. VERSION 1.0a50 CODENAMED MARY      )
( MORE INFO AT http://www.pepix.net/proyectos/glazz/mary/       )
( CONTACT frer@pepix.net FOR SUGGESTIONS                        )


( REQUIRED ANSI LABELLING:                                  )

( THIS IS AN ANS FORTH PROGRAM                              )
( REQUIRING DEFINITIONS FROM THE SEARCH           WORD SET  )
( REQUIRING FORTH, ALSO FROM THE SEARCH EXT       WORD SET  )
( REQUIRING                  THE PICASM, PICFORTH WORD SETS )



( PIC FORTH VARIABLES )

VARIABLE LASTNOOPT     ( HELPER FOR THE OPTIMIZING WORDS  )
VARIABLE FIRSTDEADCODE ( HELPER FOR THE OPTIMIZING WORDS  )
VARIABLE CURRENTBANK   ( DATA BANK SWITCHING OPTIMIZATION )



( COMPILER WORDS )

: INIT-PIC ( -- ) ( MINIMAL STARTUP CODE FOR PIC FORTH )
    $ @
    0= IF
       5 ORG
    THEN

    $ @          ( SAVES $ FOR MAIN PROGRAM JUMP )

    INITSP MOVLW
    FSR    MOVWF ( INITIAL DATA STACK POINTER    )

    $ @ SWAP     ( SAVES CURRENT $               )

    0 ORG
    ( $ )  GOTO  ( JUMPS TO THE MAIN PROGRAM     )
    $ !          ( RESTORES $                    )
;


: INIT-PICFORTH ( -- ) ( INITIALIZES PIC FORTH SYSTEM )
    CANTOPT          LASTNOOPT     !
    CANTKILLDEADCODE FIRSTDEADCODE !
    INIT-PICASM
(    INIT-PICMEM )
;


INIT-PICFORTH


: PHERE ( -- ADDR ) ( CURRENT COMPILING ADDRESS; AS HERE IN FORTH )
    $ @
;


: TOPATCH ( -- ADDR 0 ) ( AN ADDRESS TO BE PATCHED LATER BY PATCHJUMP )
    PHERE 0
;


: DONTPATCH ( -- ADDR ) ( MARKS A SPOT IN ORDER NOT TO BE PATCHED )
    CANTPATCH
;


: DEADCODE ( -- ) ( MARKS A SPOT AS DEAD CODE BEGIN )
    FIRSTDEADCODE @ CANTKILLDEADCODE = ( IS THERE A PREVIOUS DEAD CODE MARK? )
    IF                                 ( NO, MARK IT NOW                     )
        PHERE FIRSTDEADCODE !
    THEN
;


: NODEADCODE ( -- ) ( MARKS A SPOT AS DEAD CODE CANCELLATION )
    CANTKILLDEADCODE FIRSTDEADCODE !
;


: DEADCODE? ( ADDR -- ADDR F ) ( LEAVES A TRUE FLAG IF WE ARE IN DEAD CODE )
    DUP FIRSTDEADCODE @ =
;


: KILLDEADCODE ( ADDR -- ) ( SUPPRESS DEAD CODE BY BACKSKIPPING IT )
    ORG        ( RESETS $ TO THE BEGINNING OF THE DEAD CODE )
    NODEADCODE ( RESETS DEAD CODE BEGINNING ADDRESS         )
;


: OPT ( -- ) ( MARKS A SPOT AS OPTIMIZABLE )
    CANTOPT LASTNOOPT !
;


: NOOPT ( -- ) ( MARKS A SPOT AS NON-OPTIMIZABLE )
    PHERE LASTNOOPT !
;


: OPT? ( -- F ) ( LEAVES A TRUE FLAG IF OPTIMIZATION IS POSSIBLE )
    PHERE LASTNOOPT @ >
;


: RETURN? ( -- F ) ( TRUE IF LAST ASSEMBLED OPCODE IS A RETURN )
    $-1 $@ $+1 0008 =
;


: CALL? ( -- OPCODE F ) ( OPCODE AND TRUE FLAG IF OPTIMIZATION IS POSSIBLE )
    $-1 $@ DUP
    0F800 AND          ( MASK OUT THE ADDRESS          )
    2000 =             ( TRUE IF IT'S A CALL           )
    IF
        TRUE           ( TRUE, BACKS $                 )
    ELSE
        $+1 DROP FALSE ( FALSE, UNBACKS $ DROPS OPCODE )
    THEN
;


: CALL>JUMP ( OPCODE -- ) ( CONVERTS A CALL INTO A JUMP )
( USE _ONLY_ IN CONJUNCTION WITH CALL? )
    2800 OR        ( MAKE IT A GOTO;         )
    $!             ( THE CALLED WILL RETURN, )
    $+1            ( SAVING ONE STACK LEVEL  )
;


: POP ( -- ) ( GENERATES CODE TO POP W FROM STACK )
        INDF   ,W   MOVF
        FSR    ,F   INCF
;


: PUSH ( -- ) ( GENERATES CODE TO PUSH W INTO STACK )
    FSR    ,F   DECF
    INDF        MOVWF
;


: RESTACK? ( -- F ) ( TRUE FLAG IF RESTACKING POP/PUSH OPTIMIZATION IS POSSIBLE )
    OPT?              ( OPTIMIZATION POSSIBLE?            )
    $-1 $@ 0A84 = AND ( INCF FSR,F   OPCODE               )
    $-1 $@ 0800 = AND ( MOVF INDF,W  OPCODE               )
    IF                ( POP/PUSH OPTIMIZATION POSSIBLE?   )
        TRUE          ( YES, BACK $ 2 WORDS AND TRUE FLAG )
    ELSE
        $+1 $+1 FALSE ( NO, UNBACKS $ AND FALSE FLAG      )
    THEN
;


( CONST, IS SIMILAR TO LITERAL, BUT CURRENTLY MUST )
( BE USED NOT ONLY BY THE COMPILER, BUT EVEN FOR   )
( COMPILING NUMERIC ARGUMENTS                      )
( EXAMPLE: 37 CONST,                               )

: CONST, ( N -- ) ( EMBEDS A CONSTANT IN THE CODE )
    RESTACK?          ( RESTACKING OPTIMIZATION POSSIBLE? )
    0= IF
        PUSH          ( NO, GENERATE CODE FOR SAVING W    )
    THEN
    ( N )       MOVLW ( CONSTANT VALUE                    )
;


( WARNING: FOR CONST? TO WORK PROPERLY, ESPECIALLY FOR IF OPTIMIZATIONS, )
( NO WORD EXCEPT FOR CONST, MUST GENERATE A MOVLW INSTRUCTION AT THE END )

: CONST? ( -- N F ) ( CONSTANT AND TRUE FLAG IF OPTIMIZATION IS POSSIBLE )
    OPT?                            ( OPTIMIZATION POSSIBLE?                 )
    $-1 $@ DUP 0FF00 AND 3000 =     ( MOVLW       OPCODE                     )
    ROT                         AND ( THE CODE FOR CONSTANT AND VARIABLE     )
    IF                              ( CONSTANT OPTIMIZATION POSSIBLE?        )
        LOW8BITS TRUE               ( POSSIBLE: LEAVE CONSTANT AND TRUE FLAG )
                                    ( CAUTION: $ IS BACKED 1 WORD            )
    ELSE
        $+1 DROP FALSE              ( NOT POSSIBLE: LEAVE ONLY FALSE FLAG    )
    THEN
;


: KILLCONST ( -- ) ( BACKS $ IN ORDER TO SUPPRESS A CONSTANT )
                   ( USE _ONLY_ IN CONJUNCTION WITH CONST?   )
    $-1 $@  0080 =     ( MOVWF INDF  OPCODE )
    $-1 $@  0384 = AND ( DECF  FSR,F OPCODE )
    IF
    ELSE
        $+1 $+1
    THEN
;


( SAVETOS AND RESTORETOS USE TMP1; USE THEM _ONLY_ IN THE SAME WORD )

: SAVETOS ( -- ) ( GENERATES CODE TO SAVE TOS, EXCEPT IF PRECEDED BY RESTORETOS )
    OPT?                      ( OPTIMIZATION POSSIBLE?  )
    $-1 $@ 0800 TMP1 OR = AND ( PRECEDED BY RESTORETOS? )
    IF
                              ( YES, SUPPRESS IT        )
    ELSE
        $+1
        TMP1        MOVWF     ( NO, SAVE TOS            )
    THEN
;


: RESTORETOS ( -- ) ( GENERATES CODE TO RESTORE TOS )
    OPT?                      ( OPTIMIZATION POSSIBLE?  )
    $-1 $@ 0080 TMP1 OR = AND ( PRECEDED BY SAVETOS?    )
    IF
                              ( YES, SUPPRESS IT        )
    ELSE
        $+1
        TMP1   ,W   MOVF      ( NO, RESTORE TOS          )
    THEN
;


: ABS8 ( N -- |N| ) ( CALCULATES THE ABSOLUTE VALUE OF N FOR 8 BITS )
    DUP 80 AND IF
       7F AND 80 SWAP -
    THEN
;



: ?PAIRS ( F1 F2 -- ) ( CHECK PARTS OF A FLOW CONTROL STRUCTURE )
    = 0= IF ( FLAGS DON'T MATCH )
        PICERROR ABORT" CONDITIONALS NOT PAIRED"
    THEN
;


: 0=? ( -- F ) ( TRUE FLAG IF 0= OPTIMIZATION. _USE ONLY IN IF_ )
    OPT?                ( OPTIMIZATION POSSIBLE?              )
    $-1 $@ 3AFF = AND   ( XORLW 0FF      OPCODE               )
    $-1 $@ 1903 = AND   ( BTFSC STATUS,Z OPCODE               )
    $-1 $@ 3000 = AND   ( MOVLW 00       OPCODE               )
    $-1 $@ 3800 = AND   ( IORLW 00       OPCODE               )

    IF                  ( 0= OPTIMIZATION POSSIBLE?           )
        TRUE            ( TRUE FLAG, $ IS BACKED 4 WORDS      )
    ELSE
        $+1 $+1 $+1 $+1 ( UNBACKS $                           )
        FALSE           ( NOT POSSIBLE: LEAVE ONLY FALSE FLAG )
    THEN
;


: <? ( -- F ) ( TRUE FLAG IF < OPTIMIZATION. _USE ONLY IN IF_ )
    OPT?                  ( OPTIMIZATION POSSIBLE?              )
    $-1 $@ 0A84 = AND     ( INCF FSR,F     OPCODE               )
    $-1 $@ 0100 = AND     ( CLRW           OPCODE               )
    $-1 $@ 1803 = AND     ( BTFSC STATUS,C OPCODE               )
    $-1 $@ 1D03 = AND     ( BTFSS STATUS,Z OPCODE               )
    $-1 $@ 30FF = AND     ( MOVLW FF       OPCODE               )

    $-1 $@ DUP
           0280 =         ( SUBWF INDF,F   OPCODE               )
           SWAP 0FF00 AND
           3C00 = OR      ( SUBLW NN       OPCODE               )
                  AND

    IF                    ( 0= OPTIMIZATION POSSIBLE?           )
        $+1 TRUE          ( TRUE FLAG, $ IS BACKED 5 WORDS      )
    ELSE
        $+1 $+1 $+1       ( UNBACKS $                           )
        $+1 $+1 $+1
        FALSE             ( NOT POSSIBLE: LEAVE ONLY FALSE FLAG )
    THEN
;


: >? ( -- F ) ( TRUE FLAG IF > OPTIMIZATION. _USE ONLY IN IF_ )
    OPT?                  ( OPTIMIZATION POSSIBLE?              )
    $-1 $@ 0A84 = AND     ( INCF FSR,F     OPCODE               )
    $-1 $@ 0100 = AND     ( CLRW           OPCODE               )
    $-1 $@ 1C03 = AND     ( BTFSS STATUS,C OPCODE               )
    $-1 $@ 1D03 = AND     ( BTFSS STATUS,Z OPCODE               )
    $-1 $@ 30FF = AND     ( MOVLW FF       OPCODE               )

    $-1 $@ DUP
           0280 =         ( SUBWF INDF,F   OPCODE               )
           SWAP 0FF00 AND
           3C00 = OR      ( SUBLW NN       OPCODE               )
                  AND

    IF                    ( 0= OPTIMIZATION POSSIBLE?           )
        $+1 TRUE          ( TRUE FLAG, $ IS BACKED 5 WORDS      )
    ELSE
        $+1 $+1 $+1       ( UNBACKS $                           )
        $+1 $+1 $+1
        FALSE             ( NOT POSSIBLE: LEAVE ONLY FALSE FLAG )
    THEN
;
