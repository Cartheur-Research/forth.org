//
// ficlwinView.cpp : implementation of the CFiclwinView class
//

#include "stdafx.h"
#include "windows.h"
#include "ficlwin.h"
#include "ficlwinDoc.h"
#include "ficlwinView.h"
#include "MainFrm.h"
#include "FiclThread.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// Ficlwin integration words

static const  UINT ficlTextOutMsg = RegisterWindowMessage("ficltextout");
// these can probably be merged into a single "mainframe messsage"..
static const  UINT SetLedMsg      = RegisterWindowMessage("ficlsetleds");
static const  UINT SetDacMsg      = RegisterWindowMessage("ficlsetdac");
static const  UINT GetIregMsg     = RegisterWindowMessage("ficlgetireg");
static const  UINT GetAdcMsg      = RegisterWindowMessage("ficlgetadc");
static const  UINT SetStatusMsg   = RegisterWindowMessage("ficlstatus");
static const  UINT UpdateStackMsg = RegisterWindowMessage("ficlstack");
static const  UINT FiclByeMsg     = RegisterWindowMessage("ficlbye");

static void setLEDs(FICL_VM *pVM);
static void getSwitch(FICL_VM *pVM);
static void setDAC(FICL_VM *pVM);
static void getADC(FICL_VM *pVM);
static void setStatus(FICL_VM *pVM);


/////////////////////////////////////////////////////////////////////
// CFiclwinView

IMPLEMENT_DYNCREATE(CFiclwinView, CEditView)

BEGIN_MESSAGE_MAP(CFiclwinView, CEditView)
	//{{AFX_MSG_MAP(CFiclwinView)
	ON_WM_CHAR()
	ON_COMMAND(ID_EDIT_PASTE, OnEditPaste)
	ON_COMMAND(ID_FILE_NEW, OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, OnFileOpen)
	ON_COMMAND(ID_FILE_SAVE, OnFileSave)
	ON_COMMAND(ID_FILE_SAVE_AS, OnFileSaveAs)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CEditView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CEditView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CEditView::OnFilePrintPreview)
    ON_REGISTERED_MESSAGE(ficlTextOutMsg, OnAppendText)
    ON_REGISTERED_MESSAGE(SetStatusMsg, OnSetStatus)
    ON_REGISTERED_MESSAGE(SetLedMsg, OnSetLed)
    ON_REGISTERED_MESSAGE(SetDacMsg, OnSetDac)
    ON_REGISTERED_MESSAGE(GetIregMsg, OnGetIreg)
    ON_REGISTERED_MESSAGE(GetAdcMsg, OnGetAdc)
    ON_REGISTERED_MESSAGE(UpdateStackMsg, OnUpdateStack)
    ON_REGISTERED_MESSAGE(FiclByeMsg, OnFiclBye)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////
// CFiclwinView construction/destruction

CFiclwinView::CFiclwinView()
{
    m_bNewline = 0;
    m_pThread  = NULL;
}

CFiclwinView::~CFiclwinView()
{
    delete m_pThread;
}


/////////////////////////////////////////////////////////////////////
// S e n d F i c l M s g
// Passes a CString to the interpreter thread, which deletes it
// when finished.
//
void CFiclwinView::SendFiclMsg(CString *pStr)
{
    ASSERT(pStr);
    ASSERT(m_pThread->IsKindOf(RUNTIME_CLASS(CFiclThread)));

    m_pThread->PostThreadMessage(WM_FICL_EXEC, 0, (LPARAM)pStr);
    m_bNewline = 1;
    return;
}


BOOL CFiclwinView::PreCreateWindow(CREATESTRUCT& cs)
{
	BOOL bPreCreated = CEditView::PreCreateWindow(cs);
	cs.style &= ~(ES_AUTOHSCROLL|WS_HSCROLL);

	return bPreCreated;
}

/////////////////////////////////////////////////////////////////////
// CFiclwinView printing

BOOL CFiclwinView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default CEditView preparation
	return CEditView::OnPreparePrinting(pInfo);
}

void CFiclwinView::OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo)
{
	// Default CEditView begin printing.
	CEditView::OnBeginPrinting(pDC, pInfo);
}

void CFiclwinView::OnEndPrinting(CDC* pDC, CPrintInfo* pInfo)
{
	// Default CEditView end printing
	CEditView::OnEndPrinting(pDC, pInfo);
}

/////////////////////////////////////////////////////////////////////
// CFiclwinView diagnostics

#ifdef _DEBUG
void CFiclwinView::AssertValid() const
{
	CEditView::AssertValid();
}

void CFiclwinView::Dump(CDumpContext& dc) const
{
	CEditView::Dump(dc);
}

CFiclwinDoc* CFiclwinView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CFiclwinDoc)));
	return (CFiclwinDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////
// CFiclwinView message handlers

// OnActivateView
// Does initial stack display update when any view gets control
//
void CFiclwinView::OnActivateView(BOOL bActivate, 
                                  CView* pActivateView, 
                                  CView* pDeactiveView) 
{
	if (bActivate)
    {
	    ASSERT(m_pThread->IsKindOf(RUNTIME_CLASS(CFiclThread)));
        m_pThread->PostThreadMessage(WM_FICL_STACK, 0, 0);
    }

    CEditView::OnActivateView(bActivate, pActivateView, pDeactiveView);
}


/////////////////////////////////////////////////////////////////////
// f i c l T e x t O u t
// Send text from the interpreter to the view's edit control.
// Uses the ficlTextOutMsg special message, handled by OnAppendText.
void  ficlTextOut(FICL_VM *pVM, char *msg, int fNewline)
{
    static __declspec (thread) CString * pStr = NULL;
    HWND hView = (HWND)pVM->pExtend;
    bool flush;

    /* Do nothing unless we have a valid view attached */
    if (!hView)
	{
		AfxTrace("*** %s\n", msg);
        return;
	}

    /* 
    ** This line implements the logic that
    ** controls when the string buffer gets flushed to 
    ** the view. Present conditions: Either
    ** NULL message received, or any message with newline
    ** set. Also, (implemented below) there has to be something
    ** to flush (pStr non-NULL)
    */
    flush = ((msg == NULL) || (fNewline));

    /*
    ** If there's a message, allocate a string for it
    ** if necessary, or append to an existing one.
    */
    if (msg)
    {
        if (pStr == NULL)
        {
            pStr = new CString(msg);
        }
        else
        {
            *pStr += msg;
        }

        if (fNewline)
            *pStr += (LPCTSTR)"\r\n";
    }
    /*
    ** Now flush the string if necessary
    */
    if (pStr && flush)
    {
        SendMessage(hView, ficlTextOutMsg, (WPARAM)0, (LPARAM)pStr);
        pStr = NULL;
    }

    return;
}

// O n A p p e n d T e x t
// ficlTextOut message handler
// Adds text to the end of the edit control
// wParam is unused
// lParam is a pointer to the CString to append to the control.
// This function deletes the string before exiting.
//
void CFiclwinView::OnAppendText(WPARAM wParam, LPARAM lParam)
{
    CString *pStr = (CString *)lParam;
    CEdit &edit = GetEditCtrl();
    int len = GetBufferLength();
    &wParam;

    edit.SetSel(len, len, FALSE);
    edit.ReplaceSel((LPCTSTR)*pStr, FALSE);

    delete pStr;
    return;
}


/////////////////////////////////////////////////////////////////////
// O n C h a r
// Deal with the enter and Esc keys:
// Enter: if there's a selection in the edit control, send it 
// to the active interpreter. If no selection, get the last line of
// text in the control, shave off everything up to the prompt (if any),
// and send what's left to the interpreter.
void CFiclwinView::OnChar(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
    CString *pSelected = new CString();
    GetSelectedText(*pSelected);

    switch (nChar)
    {
    case VK_RETURN:    // got return key - send line to interp
        if (pSelected->IsEmpty())
        {
            CEdit &edit   = GetEditCtrl();
            int nLastLine = edit.GetLineCount() - 1;
            int nChars    = edit.GetLine(nLastLine, 
                                         pSelected->GetBufferSetLength(256), 
                                         255);

            pSelected->ReleaseBuffer(nChars);

            nChars = pSelected->Find((LPCTSTR)FICL_PROMPT);
            if (nChars >= 0)
            {
                *pSelected = pSelected->Mid(nChars + strlen(FICL_PROMPT));
            }
        }
        else            // there's a selection - send it
        {
            CString *pStr = new CString(*pSelected);
            *pStr += (LPCSTR)"\r\n";
            OnAppendText(0, (LPARAM)pStr);
        }

        CEditView::OnChar(nChar, nRepCnt, nFlags);
        SendFiclMsg(pSelected);
        break;

    case VK_ESCAPE:
        *pSelected = "cr quit";
        SendFiclMsg(pSelected);
        break;

    default:
        m_bNewline = 0;
        CEditView::OnChar(nChar, nRepCnt, nFlags);
        break;
    }

    return;
}


/////////////////////////////////////////////////////////////////////
// O n E d i t P a s t e
// Handle CF_TEXT format -- append to the edit control and
// send to the interpreter.
void CFiclwinView::OnEditPaste() 
{
    CString *pStr = new CString("");
    HANDLE hText;

    // Check to see if there's some un-entered text at the
    // end of the edit control - if so, put it in the string
    // to send to the VM
    if (m_bNewline)
    {
        CEdit &edit   = GetEditCtrl();
        int nLastLine = edit.GetLineCount() - 1;
        int nChars    = edit.GetLine(nLastLine, 
                                     pStr->GetBufferSetLength(256), 
                                     255);
        pStr->ReleaseBuffer(nChars);

        nChars = pStr->Find((LPCTSTR)FICL_PROMPT);
        if (nChars >= 0)
        {
            *pStr = pStr->Mid(nChars + strlen(FICL_PROMPT));
        }

        *pStr += " ";
    }

    // Now get whatever's in the clipboard, append it
    // to the string, and send it to the VM. Then echo
    // the paste text to the edit control
    OpenClipboard();
    hText = GetClipboardData(CF_TEXT);

    if (hText)
    {
        *pStr += (LPCSTR)hText;
        SendFiclMsg(pStr);

        pStr = new CString((LPCSTR)hText);
        *pStr += (LPCSTR)"\r\n";
        OnAppendText(0, (LPARAM)pStr);
    }

    CloseClipboard();
}


/////////////////////////////////////////////////////////////////////
// O n I n i t i a l U p d a t e
// Print the Ficl version and set the display font
// If this is the first view, load ficlwin.fr.
// Create the interpreter thread, passing the associated 
// view's hWnd so that the thread can send messages back
void CFiclwinView::OnInitialUpdate() 
{
    static bool firstTime = TRUE;
    CString *pStr = new CString(".ver .( " __DATE__ " ) cr");

    if (firstTime)
    {
        *pStr += " load ficlWin.fr\n";
        firstTime = FALSE;
        m_Font.CreatePointFont(120, "Fixedsys");
        GetEditCtrl().SetFont(&m_Font);
    }

    *pStr += " quit";

    if (!m_pThread)
    {
        m_pThread = new CFiclThread(GetSafeHwnd());
        m_pThread->CreateThread();
	    ASSERT(m_pThread->IsKindOf(RUNTIME_CLASS(CFiclThread)));
    }
    else
    {
        *pStr = "quit";
    }

    CEditView::OnInitialUpdate();
	
    m_pThread->PostThreadMessage(WM_FICL_EXEC, 0, (LPARAM)pStr);
    return;
}


/////////////////////////////////////////////////////////////////////
// Handlers for special messages from Ficl thread
//
// O n U p d a t e S t a c k
// Gets sent by the interpreter thread whenever it is finished
// with a ficlExec, and also when it receives 
void CFiclwinView::OnUpdateStack(WPARAM wp, LPARAM pStr)
{
    int depth = wp & 0xffff;
    int base  = wp >> 16;
    CMainFrame *pFrame = (CMainFrame *)GetParentFrame();
    pFrame->SetStack(base, depth, (CString *)pStr);
    return;
}


// O n F i c l B y e
// Handles the ficlBye message from the interpreter thread
// by sending WM_CLOSE to the mainframe
void CFiclwinView::OnFiclBye(WPARAM wUnused, LPARAM lUnused)
{
    CMainFrame *pFrame = (CMainFrame *)GetParentFrame();
    &wUnused;
    &lUnused;
    pFrame->PostMessage(WM_CLOSE, 0, 0);
}


/////////////////////////////////////////////////////////////////////
// Status Line
// s e t S t a t u s
// Update Status line using the setStatusMsg
static void setStatus(FICL_VM *pVM)
{
    HWND hView = (HWND)pVM->pExtend;
    FICL_STRING *pFS = (FICL_STRING *)pVM->pad;
    vmGetString(pVM, pFS, '\"');

    SendMessage(hView, SetStatusMsg, 0, (LPARAM)pFS->text);

    return;
}


// setStatus message handler
void CFiclwinView::OnSetStatus(WPARAM w, LPARAM pMsg)
{
    CMainFrame *pFrame = (CMainFrame *)GetParentFrame();
    &w;
    pFrame->SetStatus((char *)pMsg);
}


// Get simulated switch value
static void getSwitch(FICL_VM *pVM)
{
    HWND hView = (HWND)pVM->pExtend;
    int v;
    SendMessage(hView, GetIregMsg, 0, (LPARAM)&v);
    stackPushINT(pVM->pStack, v);
    return;
}


void CFiclwinView::OnGetIreg(WPARAM w, LPARAM piVal)
{
    CMainFrame *pFrame = (CMainFrame *)GetParentFrame();
    &w;
    *(int *)piVal = pFrame->GetSwitch();
}


// Get slider control (sim ADC) value
static void getADC(FICL_VM *pVM)
{
    HWND hView = (HWND)pVM->pExtend;
    int v;
    SendMessage(hView, GetAdcMsg, 0, (LPARAM)&v);
    stackPushINT(pVM->pStack, v);
    return;
}


void CFiclwinView::OnGetAdc(WPARAM w, LPARAM piVal)
{
    CMainFrame *pFrame = (CMainFrame *)GetParentFrame();
    &w;
    *(int *)piVal = pFrame->GetADC();
}


// Set LED message pair...
static void setLEDs(FICL_VM *pVM)
{
    HWND hView = (HWND)pVM->pExtend;
    int value = stackPopINT(pVM->pStack);
    SendMessage(hView, SetLedMsg, 0, (LPARAM)value);
    return;
}


void CFiclwinView::OnSetLed(WPARAM w, LPARAM val)
{
    CMainFrame *pFrame = (CMainFrame *)GetParentFrame();
    &w;
    pFrame->SetLeds(val);
}


// Set DAC message pair
static void setDAC(FICL_VM *pVM)
{
    HWND hView = (HWND)pVM->pExtend;
    int value = stackPopINT(pVM->pStack);
    SendMessage(hView, SetDacMsg, 0, (LPARAM)value);

    return;
}


void CFiclwinView::OnSetDac(WPARAM w, LPARAM val)
{
    CMainFrame *pFrame = (CMainFrame *)GetParentFrame();
    &w;
    pFrame->SetDAC(val);
}


/////////////////////////////////////////////////////////////////////
// More Ficl wrapper functions...

static void ficlSleep(FICL_VM *pVM)
{
    DWORD msec = stackPopUNS(pVM->pStack);
    Sleep(msec);
    return;
}

void FiclwinBuild(void)
{
    ficlBuild("!oreg",      setLEDs,   FW_DEFAULT);
    ficlBuild("@ireg",      getSwitch, FW_DEFAULT);
    ficlBuild("!dac",       setDAC,    FW_DEFAULT);
    ficlBuild("@adc",       getADC,    FW_DEFAULT);
    ficlBuild("status\"",   setStatus, FW_DEFAULT);
    ficlBuild("ms",         ficlSleep, FW_DEFAULT);
    return;
}


void CFiclwinView::OnFileOpen() 
{
    CFileDialog	fd(TRUE);

    if (fd.DoModal() == IDOK)
    {
        CString *pStr = new CString("load ");
        *pStr += fd.GetPathName();
        AfxGetApp()->AddToRecentFileList(fd.GetPathName());
        SendFiclMsg(pStr);
    }

    return;
}


void CFiclwinView::OnFileNew() 
{
    MessageBox("Not implemented");
}


void CFiclwinView::OnFileSave() 
{
    MessageBox("Not implemented");
}


void CFiclwinView::OnFileSaveAs() 
{
    MessageBox("Not implemented");
}


