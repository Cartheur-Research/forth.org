/* generic bigforth loader in C
   is used for OS/2, Linux and Windows 95 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <setjmp.h>
#include <signal.h>

#ifdef _WIN32
#include <windows.h>
HFILE sinp, sout, serr;
#endif

#ifdef VERBOSE
# ifdef _WIN32
#  define PRINTV(x...)  { char buf[100]; sprintf(buf, x), \
			  _hwrite(sout, buf, strlen(buf)); }
# else
#  define PRINTV(x...)  fprintf(stderr, x)
# endif
#else
#  define PRINTV(x...)
#endif

/* OS-dependend part:

   bigFORTH needs the following file system and memory management
   primitives for loanding:

   get amount of availabe memory
   allocate: read, write and execute
   open file by name (r/o, binary)
   seek in a file to absolute position
   read in a number of bytes
   close the file

*/

#define CLEN(string) string,strlen(string)

#ifdef OS2 /* create OS/2 loader */

#define INCL_SUB
#define INCL_DOS
#include <os2.h>

#define OSFILE  HFILE

#define available_mem(size)   (size=0x01000000)
#define alloc_mem(size,heap)  DosAllocMem((void *)&(heap), size, fALLOC)
/* (heap=(int *) sbrk(size)) */

#define open_by_name(name,handle) \
({ \
     ULONG usAction=OPEN_ACTION_FAIL_IF_NEW; \
     DosOpen(name, &handle, &usAction, 0L, 0, FILE_OPEN, 0x00C0, 0L); \
})

#define seek_to(handle,pos) \
({ \
     long dummy; \
     DosSetFilePtr(handle, pos, FILE_BEGIN, &dummy); \
     dummy; \
})

#define read_bytes(handle,to,size) \
({ \
     long dummy; \
     DosRead(handle, to, size, &dummy); \
     dummy; \
})

#define close_file(handle)    DosClose(handle);

#define PANIC(string) \
({ \
     long dummy; \
     DosWrite(1, CLEN(string), &dummy); \
})

#define LOADER
#endif /* OS/2 */


#ifdef linux /* Create Linux loader */

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

#define OSFILE  int

int bytes=0;

#define available_mem(size)        (size=0x01000000)
#define alloc_mem(size,heap)       (heap=(int *) malloc(size))
#define open_by_name(name,handle)  (handle=open(name, O_RDONLY))
#define seek_to(handle,pos)        ({ long _pos = pos; if(bytes!=_pos) lseek(handle, _pos, SEEK_SET); bytes=_pos; })
#define read_bytes(handle,to,size) (bytes+=read(handle, to, size))
#define close_file(handle)         (close(handle))

#define PANIC(string) \
   (write(fileno(stderr), CLEN(string)))

#define LOADER
#endif


#ifdef _WIN32 /* Generic loader */

#define OSFILE  HFILE

#define available_mem(size)        (size=0x0100000)
#ifdef GLOBAL_ALLOC
#define alloc_mem(size,heap)       (heap=(int *) GlobalAlloc(GMEM_FIXED, size))
#else
int * stackalloc(int size)
{
   asm("movl 8(%ebp),%eax\n\
stlop:	cmpl $0,(%esp)\n\
	addl $-0x1000,%esp\n\
	addl $-0x1000,%eax\n\
	jb stlop\n\
	movl %esp,%eax\n\
	leave\n\
	ret");
}
#define alloc_mem(size,heap)       (heap=stackalloc(size+0x1000)) 
#endif
#define open_by_name(name,handle)  (handle=_lopen(name, OF_READ))
#define seek_to(handle,pos)        (_llseek(handle, pos, FILE_BEGIN))
#define read_bytes(handle,to,size) (_lread(handle, to, size))
#define close_file(handle)         (_lclose(handle))

#define PANIC(string) \
   (_hwrite(serr, string, strlen(string)))
#define PANIC1(string, n) \
   ({ char buf[100], sprintf(buf, string, n); \
      _hwrite(serr, buf, strlen(buf)) })
#undef linux

#define LOADER
#endif
/* end OS-dependend part */

typedef int BIGFORTH(int *, char *, void **);
typedef int THROW(int);
typedef BIGFORTH *PBIGFORTH;
typedef THROW *PTHROW;

#ifdef VERBOSE
char * cstring(char * string)
{
  static char name[32];
  
  memcpy(name, string+1, (int)(*string) & 0x1F);
  name[(int)(*string)]=0;
  
  return name;
}
#endif

static char bigforth_header[] =
#ifdef OS2
  "\353\137\037ANS bigforth 386-OS/2 rev. 1.22"
  "\022compiled 24jan97py"
#endif
#ifdef linux
  "\353\137\040ANS bigforth 386-Linux rev. 1.22"
  "\022compiled " DATE "py"
#endif
#ifdef _WIN32
  "\353\137\040ANS bigforth 386-Win32 rev. 1.22"
  "\022compiled " DATE "py"
#endif
  "\011#00001py "
  "\035(c) 1990-1997 by Bernd Paysan"
  "\016plain bigFORTH"
;

int bfdat[9]=
{
  0,          /* mroot    */
  0,          /* heaps    */
  0,          /* reserved */
  0x0080000,  /* Minimal  */
  0x0800000,  /* Maximal  */
  0x0008000,  /* Stacklen */
  1,          /* argc     */
  0,          /* argv     */
  0,          /* env      */
};

int recovery[32];
char fpdump[108];

jmp_buf throw_jmp_buf;

#define mroot ((int **)bfdat)[0]
#define heaps ((int **)bfdat)[1]
#define memdat (bfdat+2)
#define stlen (bfdat[5])
#define argc_ (bfdat[6])
#define argv_ ((char ***)bfdat)[7]
#define env_  ((char ***)bfdat)[8]

#ifdef _WIN32
#define hinst_ *((HINSTANCE *)(((int *)bfdat)+9))
#define cmdsh_ ((int *)bfdat)[10]
#define win_ ((int *)bfdat)[11]
#define gc_ ((int *)bfdat)[12]
#define sp_ ((int *)bfdat)[13]
#endif
		
char fileerr[8]="where's ";
char file[128];

char* linkinfo;

void makeempty(int * block, int n)
/* Marks the n bytes long block at block */
{

  PRINTV("Blocking %08x size %08x\n", (int)block, n);

  block[1]=0;
  block[0]=n;
  *(int *)(((char *)block)+n-sizeof(int))=n;
}

int * bf_alloc(int * free, int n)
/* returns next free: free+2 is pointer for object! */
{
  int m;

  PRINTV("Allocate %08x size %08x\n", (int)free, n);

  n=(n+0x1B) & -0x10;

  if(*free < n)
    {
      PANIC("Running out of Memory!\n");
      exit(1);
    }

  m=*free-n;

  makeempty(free,n);
  free[1]=-1;
  free=(int *)((int)free+n);
  makeempty((int *)free,m);
  return free;
}

int * find_module(char * name, int date, int * module)
{
  int * retmodule;

  PRINTV("Trying to find %s date %08x", cstring(name), date);
  PRINTV(" in module %s (%08x), date %08x\n", cstring(((char*)module)+0x30),
	  module, module[5]);

  if(!memcmp(name,"\003nil",4)) return NULL;

  do
    {
      if(module[5]==date && !memcmp(name,((char *)module)+0x30,1+*name))
	  return module;
      PRINTV("Not found on this trial %x\n", module);
      if(module[2] && (retmodule = find_module(name, date, (int *)(module[2]))))
	return retmodule;
      else module=(int *)(module[4]);
    }
  while(module!=NULL);

  return NULL;
}

void bf_link(int * this, int * that, unsigned short * thread)
{
  PRINTV("Linking %s ", cstring(((char*)this)+0x30));
  PRINTV("with %x\n", that ? cstring(((char*)that)+0x30) : "nil");

  asm("pushal\n\
	movl	0x10(%ebp),%ebx\n\
	movl	0x08(%ebp),%esi\n\
	movl	0x0C(%ebp),%ebp\n\
	movw	(%ebx),%ax\n\
	shll	$16,%eax\n\
	movw	4(%ebx),%ax\n\
	pushl	%ebx\n\
	movw	2(%ebx),%bx\n\
	shll	$16,%ebx\n\
	call	linkthread\n\
	popl	%ebx\n\
	movw	6(%ebx),%ax\n\
	movw	2(%ebx),%bx\n\
	shll	$16,%ebx\n\
	call	linkrel\n\
	popal");
}

void linkit(unsigned char * nametable)
{
  int tablesize, namesize;
  int *this, *that;
  char* endtable;

  while((tablesize= *((unsigned short *)nametable)++))
    {
      PRINTV("Link module %s, table size %04x\n",cstring(nametable),tablesize);
      endtable=nametable+tablesize;

      namesize = ((int)*nametable)+1;
      this=that=find_module(nametable, *(int *)(nametable + namesize), mroot);
      PRINTV("Module %s found\n", cstring(((char*)this)+0x30));
      nametable += namesize + sizeof(int);

      bf_link(this, that, (unsigned short *)nametable);

      nametable += 4*sizeof(short);

      while(((unsigned int)nametable < (unsigned int)endtable) && that)
	{
	  namesize = 1 + *nametable;
	  that=find_module(nametable, *(int *)(nametable + namesize), mroot);
	  nametable += namesize;
	  if(that) nametable += sizeof(int);

	  bf_link(this, that, (unsigned short *)nametable);

	  nametable += 4*sizeof(short);

      PRINTV("Table rest length %04x\n",(int)endtable - (int)nametable);
	}
    }
}

int * loadmod(int * freemem, OSFILE handle, int * modptr, long filepos)
{
  int * module;

  PRINTV("Loading to %08x from %08x module %08x pos %08x\n",
	 (int)freemem, (int)handle, (int)modptr, filepos);

  do
    {
      if(filepos) seek_to(handle, filepos);
      
      module=freemem+3;
      
      read_bytes(handle, module, 8L);

      PRINTV("Load Module with size %08x and DP %08x\n",module[1],module[0]);
      
      freemem=bf_alloc(freemem, module[1] + ((module[1]-1) >> 3) +
		       1 + sizeof(int));
      
      memset(module+module[1], 0, ((module[1]-1)>>3) + 1);
      
      module[-1]=1;
      
      read_bytes(handle, module+2, module[0] - 2*sizeof(int));

      PRINTV("Loaded %s\n", cstring((char*)module+0x30));

      read_bytes(handle, linkinfo, 2);

      PRINTV("Loading link table %04x\n",*(unsigned short *)linkinfo);

      read_bytes(handle, linkinfo+2, *(unsigned short *)linkinfo);
      
      linkinfo += 2 + *(unsigned short *)linkinfo;
      
      if(modptr == NULL)
	mroot=module;
      else
	{
	  int* parent = modptr-2;
	  while(parent[4])
	    parent=(int *)parent[4];
	  parent[4]=(int)module;
	  module[3]=(int)modptr;
	}
      {
	int submodule=module[2];
	module[2]=0;
	if(submodule)
	  freemem=loadmod(freemem, handle, module, submodule);
      }

      filepos=module[4];

      PRINTV("Loading next module at %08x to %08x\n", filepos, freemem);

      module[4]=0;
    }
  while(filepos);

  return freemem;
}


/* This loader is used for OSes with dynamic link libraries (such as
   Windows, OS/2 or Linux), and therefore it presents a wrapper for
   DLL loading

   The wrapper runs over a table containing the following functionality:
     - LoadModule
     - GetProcAddr
   for standard module loading
     - type
     - getkey
     - at
     - at?
     - form
     - bye
   for kernal basic IO
   and optionally
     - set_recovery
   for basic exception recovery.
*/

#ifdef OS2  /* Create OS/2-specific wrapper */

long bf_getkey(flag)
{
  KBDKEYINFO inRecord;

  KbdCharIn(&inRecord, flag ? 0 : 1, 0); /* Read Key, but don't wait */

  if(inRecord.fbStatus)
    return ((inRecord.chChar) | (inRecord.chScan << 8) |
	    (inRecord.fsState << 16));
  else
    return 0L;
}

void bf_type(long length, char * addr)
{
  long dummy;

  DosWrite(0, addr, length, &dummy);
}

long bf_at_query()
{
  unsigned short row, col;

  VioGetCurPos (&row, &col, 0);

  return ((long)row << 16) | (long)col;
}

static long form=0;

long bf_form()
{
  VIOMODEINFO mode;

  if(form == 0)
    {
      if(VioGetMode (&mode, 0))
	{
	  mode.row=25; mode.col=80;
	}
      form = (mode.row << 16) | (long)mode.col;
    }

  return form;
}

void bf_at(int col, int row)
{
  VioSetCurPos (row, col, 0);
}

long bf_get_library(int length, char * addr)
{
  char name[length+1];
  HMODULE lib;
  int rc;

  memcpy(name, addr, length);
  name[length]=0;
  
  rc=DosLoadModule("", 0, name, &lib);

  return (rc ? 0 : lib);
}

long bf_proc_addr(HMODULE lib, int length, char * addr)
{
  char name[length+1];
  PFN proc;
  int rc;

  memcpy(name, addr, length);

  name[length]=0;
  
  rc=DosQueryProcAddr (lib, 0, name, &proc);

  return (long)(rc ? 0 : proc);
}

void prep_terminal()
{
  KBDINFO kbdinfo;

  KbdGetStatus(&kbdinfo, 0);

  kbdinfo.fsMask = (kbdinfo.fsMask & 0xFFF0) | 6; /* noecho, raw mode */

  KbdSetStatus(&kbdinfo, 0);

  (void)bf_form();
}

void deprep_terminal()
{
  KBDINFO kbdinfo;

  KbdGetStatus(&kbdinfo, 0);

  kbdinfo.fsMask = (kbdinfo.fsMask & 0xFFF0) | 0xA; /* noecho, cooked mode */

  KbdSetStatus(&kbdinfo, 0);
}

void bf_bye(int ret)
{
  deprep_terminal();
  exit(ret);
}

void install_signal_handlers()
{
  /* dummy */
}

#endif /* OS/2 specific wrapper */

#ifdef linux
#include <dlfcn.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <sys/file.h>
#include <errno.h>
extern int errno;

static struct termios otio;
int readline_echoing_p = 1;

#ifndef CTRL
#define CTRL(key)	((key)^'@')
#endif

static int eof_char = CTRL('D');
static int terminal_prepped = 0;

static unsigned long cout=0, maxcur=0;

void get_winsize()
{
  unsigned short rows=0, cols=0;
#ifdef TIOCGWINSZ
  struct winsize size;
  
  if (ioctl (1, TIOCGWINSZ, (char *) &size) >= 0) {
    rows = size.ws_row;
    cols = size.ws_col;
  }
#else
  char *s, *ends;
  unsigned long ul;
  if (s=getenv("LINES")) {
    rows=atoi(s);
    if (rows==0)
      rows=24;
  }
  if (s=getenv("COLUMNS")) {
    rows=atoi(s);
    if (rows==0)
      cols=80;
  }
#endif

  maxcur = ((long)rows << 16) | (long)cols;
}

static void change_winsize(int sig)
{
  signal(sig,change_winsize);
#ifdef TIOCGWINSZ
  get_winsize();
#endif
}

void prep_terminal();

long get_screenpos()
{
  unsigned short row=0, col=0;
  char inchar;

  if(!terminal_prepped)  prep_terminal();

  write(fileno(stdin), "\033[6n", 4);

  while(read(fileno(stdin), &inchar, 1) && inchar !='R')
    {
      switch(inchar)
        {
        case '\033': break;
        case '[': break;
        case ';': row=col; col=0; break;
        case '0':
        case '1':
        case '2':
        case '3':
        case '4':
        case '5':
        case '6':
        case '7':
        case '8':
        case '9': col=col*10+inchar-'0'; break;
        default: /* something went wrong */ break;
        }
    }
  row--; col--;

  return ((long)row << 16) | (long)col;
}

void prep_terminal ()
{
  int tty = fileno (stdin);

  struct termios tio;
  sigset_t set, oset;

  if (terminal_prepped)
    return;

  sigemptyset (&set);
  sigemptyset (&oset);
  sigaddset (&set, SIGINT);
  sigprocmask (SIG_BLOCK, &set, &oset);

  tcgetattr (tty, &tio);

  otio = tio;

  readline_echoing_p = (tio.c_lflag & ECHO);

  tio.c_lflag &= ~(ICANON | ECHO);

  if (otio.c_cc[VEOF] != _POSIX_VDISABLE)
    eof_char = otio.c_cc[VEOF];
   
  if ((tio.c_cflag & CSIZE) == CS8)
    tio.c_iflag &= ~(ISTRIP | INPCK);

  tio.c_iflag &= ~(ICRNL | INLCR);
  tio.c_lflag |= ISIG;
  tio.c_cc[VMIN] = 1;
  tio.c_cc[VTIME] = 0;

  tio.c_cc[VLNEXT] = _POSIX_VDISABLE;

  tcsetattr (tty, TCSADRAIN, &tio);
  tcflow (tty, TCOON);

  terminal_prepped = 1;

  sigprocmask (SIG_SETMASK, &oset, (sigset_t *)NULL);

#ifdef CLEAR_SCREEN
  write(fileno(stdin), "\033[2J\033[H", 7);
  cout = 0;
#else
  cout = get_screenpos();
#endif

  get_winsize();
}

void deprep_terminal ()
{
  int tty = fileno (stdin);
  sigset_t set, oset;

  if (!terminal_prepped)
    return;

  sigemptyset (&set);
  sigemptyset (&oset);
  sigaddset (&set, SIGINT);
  sigprocmask (SIG_BLOCK, &set, &oset);

  tcsetattr (tty, TCSADRAIN, &otio);
  tcflow (tty, TCOON);

  terminal_prepped = 0;


  sigprocmask (SIG_SETMASK, &oset, (sigset_t *)NULL);
}

long pending = -1L;

long key_avail (stream)
	FILE *stream;
{
  int tty = fileno (stream);
  long chars_avail = pending;
  int result;

  if(!terminal_prepped)  prep_terminal();

  result = ioctl (tty, FIONREAD, &chars_avail);

  return chars_avail;
}

unsigned char getkey(stream)
     FILE *stream;
{
  int result;
  unsigned char c;

  if(!terminal_prepped)  prep_terminal();

  if (pending < 0)
    {
      result = read (fileno (stream), &c, sizeof (char));

      if (result == sizeof (char))
        return c;

      if (result == 0)
	return (0);

      if (errno != EINTR)
	return (EOF);
    }

  result = (int) pending;
  pending = -1L;

  return result;
}

long bf_getkey(int flag)
{
  return((flag || key_avail(stdin)) ? (long)getkey(stdin) : 0L);
}

long bf_at_query()
{
  if(!terminal_prepped)  prep_terminal();

  return cout;
}

long bf_form()
{
  if(!maxcur)  get_winsize();

  return maxcur;
}

void bf_type(long length, char * addr)
{
  int i;

  write(fileno(stdout), addr, length);

  for(i=0; i<length; i++)
    switch(*addr++)
      {
      case '\b':  cout--; break;
      case '\n':  cout >>= 0x10; cout++;
	if(cout >= (maxcur >> 0x10))
	  cout = (maxcur >> 0x10) -1;
	cout <<= 0x10; break;
      default:    cout++; break;
      }
}

void bf_at(int col, int row)
{
  char buf[20];

  if(cout != (unsigned int)((row << 16) | col)) {
    sprintf(buf,"\033[%d;%dH", row+1, col+1);
    write(fileno(stdout), buf, strlen(buf));
    
    cout = (row << 16) | col;
  }
}

long bf_get_library(int length, char * addr)
{
  char name[length+1];

  memcpy(name, addr, length);
  name[length]=0;
  
  return (long)dlopen(name, RTLD_LAZY); /* NOW */
}

long bf_proc_addr(long lib, int length, char * addr)
{
  char name[length+1];

  memcpy(name, addr, length);

  name[length]=0;
  
  return (long)dlsym((void *)lib, name);
}

void bf_bye(int ret)
{
  deprep_terminal();
  exit(ret);
}


static void
graceful_exit (int sig)
{
  fprintf (stderr, "\n\n%s.\n", strsignal (sig));
  deprep_terminal();
  exit (0x80|sig);
}

static void 
signal_throw(int sig)
{
  int code, i;
  long *dump1, *dump2;

  struct {
    int signal;
    int throwcode;
  } *p, throwtable[] = {
    { SIGINT, -28 },
/*    { SIGFPE, -55 }, */
    { SIGBUS, -23 },
    { SIGSEGV, -9 },
  };

  dump1 = ((long*)(&sig))+5;
  dump2 = ((long*)(recovery))+1;

  for(i=0; i<8; i++)
    *(dump2++) = *(dump1++);

  *dump2++ = ((long*)(&sig))[15];
  *dump2++ = ((long*)(&sig))[16];
  *dump2++ = ((long*)(&sig))[17];
  *dump2++ = ((long*)(&sig))[13];
  memcpy(fpdump, (char*)(((long*)(&sig))[20]), 108);
  *dump2++ = (long)fpdump;

  signal(sig,signal_throw);
  for (code=-256-sig, p=throwtable; p<throwtable+(sizeof(throwtable)/sizeof(*p)); p++)
    if (sig == p->signal) {
      code = p->throwcode;
      break;
    }
  longjmp(throw_jmp_buf,code); /* or use siglongjmp ? */
}

static void termprep (int sig)
{
  signal(sig,termprep);
  terminal_prepped=0;
}

void install_signal_handlers (void)
{
  static short sigs_to_throw [] = {
#ifdef SIGBREAK
    SIGBREAK,
#endif
#ifdef SIGINT
    SIGINT,
#endif
#ifdef SIGILL
    SIGILL,
#endif
#ifdef SIGEMT
    SIGEMT,
#endif
#ifdef SIGFPE
    SIGFPE,
#endif
#ifdef SIGIOT
    SIGIOT,
#endif
#ifdef SIGSEGV
    SIGSEGV,
#endif
#ifdef SIGALRM
    SIGALRM,
#endif
#ifdef SIGPIPE
    SIGPIPE,
#endif
#ifdef SIGPOLL
    SIGPOLL,
#endif
#ifdef SIGPROF
    SIGPROF,
#endif
#ifdef SIGBUS
    SIGBUS,
#endif
#ifdef SIGSYS
    SIGSYS,
#endif
#ifdef SIGTRAP
    SIGTRAP,
#endif
#ifdef SIGURG
    SIGURG,
#endif
#ifdef SIGUSR1
    SIGUSR1,
#endif
#ifdef SIGUSR2
    SIGUSR2,
#endif
#ifdef SIGVTALRM
    SIGVTALRM,
#endif
#ifdef SIGXFSZ
    SIGXFSZ,
#endif
  };
  static short sigs_to_quit [] = {
#ifdef SIGHUP
    SIGHUP,
#endif
#ifdef SIGQUIT
    SIGQUIT,
#endif
#ifdef SIGABRT
    SIGABRT,
#endif
#ifdef SIGTERM
    SIGTERM,
#endif
#ifdef SIGXCPU
    SIGXCPU,
#endif
  };
  unsigned int i;

#define DIM(X)		(sizeof (X) / sizeof *(X))
/*
  for (i = 0; i < DIM (sigs_to_ignore); i++)
    signal (sigs_to_ignore [i], SIG_IGN);
*/
  for (i = 0; i < DIM (sigs_to_throw); i++)
    signal (sigs_to_throw [i], signal_throw);
  for (i = 0; i < DIM (sigs_to_quit); i++)
    signal (sigs_to_quit [i], graceful_exit);
#ifdef SIGCONT
    signal (SIGCONT, termprep);
#endif
#ifdef SIGWINCH
    signal (SIGWINCH, change_winsize);
#endif
}

#endif /* Linux specific wrapper */

#ifdef _WIN32

int terminal_prepped=0;

void prep_terminal()
{
   sinp =GetStdHandle(STD_INPUT_HANDLE);
   sout=GetStdHandle(STD_OUTPUT_HANDLE);
   serr=GetStdHandle(STD_ERROR_HANDLE);
   terminal_prepped=1;
}

void deprep_terminal()
{
}

static unsigned long cout=0, maxcur=0;

void get_winsize()
{
   maxcur = ((long)24 << 16) | (long)80;
}

long bf_getkey(int flag)
{
  INPUT_RECORD conin;
  int n;
   
  if(!PeekConsoleInput(sinp, &conin, 1, &n)) return 0;

  if(!n || !ReadConsoleInput(sinp, &conin, 1, &n)) return 0;
  
  if(n && (conin.EventType == KEY_EVENT) && conin.Event.KeyEvent.bKeyDown)
    return conin.Event.KeyEvent.AsciiChar;
  else
    return 0;
}

long bf_at_query()
{
  if(!terminal_prepped)  prep_terminal();

  return cout;
}

long bf_form()
{
  if(!maxcur)  get_winsize();

  return maxcur;
}

void bf_type(long length, char * addr)
{
  int i;

  _hwrite(sout, addr, length);

  for(i=0; i<length; i++)
    switch(*addr++)
      {
      case '\b':  cout--; break;
      case '\n':  cout >>= 0x10; cout++;
	if(cout >= (maxcur >> 0x10))
	  cout = (maxcur >> 0x10) -1;
	cout <<= 0x10; break;
      default:    cout++; break;
      }
}

void bf_at(int col, int row)
{
  COORD curpos;
  
  curpos.X=col;
  curpos.Y=row+1;
   
  SetConsoleCursorPosition(sout, curpos);

  cout = (row << 16) | col;
}

long bf_get_library(int length, char * addr)
{
  char name[32];
  long ret;
   
  memcpy(name, addr, length);
  name[length]=0;
  
  if((ret=(long)GetModuleHandle(name)))
    return ret;
  return(long)LoadLibrary(name);
}

long bf_proc_addr(long lib, int length, char * addr)
{
  char name[32];

  memcpy(name, addr, length);

  name[length]=0;
  
  return (long)GetProcAddress((HMODULE)lib, name);
}

void bf_bye(int ret)
{
  deprep_terminal();
  exit(ret);
}

char * strsignal(int sig)
{
  static char signal[5];
  sprintf(signal,"%d",sig);
  return signal;
}
/*
static void
graceful_exit (int sig)
{
  PANIC1 ("\n\n%s.\n", strsignal (sig));
  deprep_terminal();
  exit (0x80|sig);
}
*/
void install_signal_handlers()
{
  /* dummy */
}
#endif

void * function_table[9] =
{
  bf_get_library,
  bf_proc_addr,
  bf_type,
  bf_getkey,
  bf_at_query,
  bf_at,
  bf_form,
  bf_bye,
  (void *) recovery
};

void go_bigforth()
{
  int throw_code;
  int throw_to;
  
  install_signal_handlers();
  recovery[0] = 0;

  if ((throw_code=setjmp(throw_jmp_buf))) {
    throw_to = recovery[0];

    if(throw_to) ((PTHROW)throw_to)(throw_code);
    else {
#ifdef _WIN32
       char buf[100];
      sprintf (buf, "\n\nbigforth: %s.\n", strsignal (throw_code));
      _hwrite(serr, buf, strlen(buf));
#else
      fprintf (stderr, "\n\nbigforth: %s.\n", strsignal (throw_code));
#endif
       deprep_terminal();
      exit (0x80|throw_code);
    }
  }
  else
    ((PBIGFORTH)mroot[6])(bfdat, &bigforth_header[0], function_table);
}

#ifdef _WIN32
/*
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
		   LPSTR lpCmdLine, int nCmdShow)
*/
int main(int argc, char ** argv, char **env)
{
  int freemem, reg;
  int* nextfree;
  OSFILE handle;

  argc_=argc;
  argv_=argv;
   
  freemem=memdat[2];

  PRINTV("Running as %s\n",argv[0]);

  alloc_mem(freemem, heaps);

  PRINTV("Allocated %08x\n",heaps);

  *heaps++=0; *heaps++=0;
  heaps[(freemem>>2)-4]=0;
  heaps[(freemem>>2)-3]=0;

  makeempty(heaps,freemem-4*sizeof(int));
  nextfree=heaps;
  linkinfo = (char *)(heaps+2);

  nextfree=bf_alloc(nextfree,stlen);

  strcpy(file,argv[0]);

#if (defined OS2) || (defined _WIN32)
  if(!memcmp(".exe", file+strlen(file)-4, 4))
     file[strlen(file)-4]=0;
#endif

  strcpy(file+strlen(file),".sys");

  PRINTV("Load file %s\n", file);

  open_by_name(file, handle);

  nextfree=loadmod(nextfree, handle, NULL, 0L);

  close_file(handle);

  *((short *) linkinfo) = 0;

  linkit((char *)(heaps+2));

#ifdef CLEAR_SCREEN
  cout = 0;
  bf_at_query();
#endif

  go_bigforth();

  deprep_terminal();

  exit(0);
}
#else
int main(int argc, char ** argv, char **env)
{
  int freemem;
  int* nextfree;
  OSFILE handle;

  argc_=argc; argv_=argv; env_=env;

  freemem=memdat[2];

  PRINTV("Running as %s\n",argv[0]);

  alloc_mem(freemem, heaps);

/*  heaps=(int *)malloc(freemem);*/

  PRINTV("Allocated %08x\n",heaps);

  *heaps++=0; *heaps++=0;
  heaps[(freemem>>2)-4]=0;
  heaps[(freemem>>2)-3]=0;

  makeempty(heaps,freemem-4*sizeof(int));
  nextfree=heaps;
  linkinfo = (char *)(heaps+2);

  nextfree=bf_alloc(nextfree,stlen);

  strcpy(file,argv[0]);

#if (defined OS2) || (defined _WIN32)
  if(!memcmp(".exe", file+strlen(file)-4, 4))
     file[strlen(file)-4]=0;
#endif

  strcpy(file+strlen(file),".sys");

  PRINTV("Load file %s\n", file);

  open_by_name(file, handle);

  nextfree=loadmod(nextfree, handle, NULL, 0L);

  close_file(handle);

  *((short *) linkinfo) = 0;

  linkit((char *)(heaps+2));

#ifdef CLEAR_SCREEN
  write(fileno(stdin), "\033[2J\033[H", 7);
  cout = 0;
  bf_at_query();
#endif

  go_bigforth();

  deprep_terminal();

  exit(0);
}
#endif
