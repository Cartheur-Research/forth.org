/*******************************************************************
** d i c t . c
** Forth Inspired Command Language - dictionary methods
** Author: John Sadler
** Created: 19 July 1997
** 
*******************************************************************/
/*
** This file implements the dictionary -- FICL's model of 
** memory management. All FICL words are stored in the
** dictionary. A word is a named chunk of data with its
** associated code. FICL treats all words the same, even
** precompiled ones, so your words become forst class
** extensions of the language. You can even define new 
** control structures.
*/

#include <stdlib.h>
#include <stdio.h>          /* sprintf */
#include <string.h>
#include <ctype.h>
#include "ficl.h"


/**************************************************************************
                        d i c t C o p y N a m e
** Copy up to nFICLNAME characters of the name specified by si into
** the dictionary starting at "here", then NULL-terminate the name,
** point "here" to the next available byte, and return the address of
** the beginning of the name. Used by dictAppendWord.
** N O T E : "here" is guaranteed to be aligned after this operation.
**************************************************************************/
static char *dictCopyName(FICL_DICT *pDict, STRINGINFO si)
{
    char *oldCP    = (char *)pDict->here;
    char *cp       = oldCP;
    char *name     = SI_PTR(si);
    int   i        = SI_COUNT(si);

    if (i > nFICLNAME)
        i = nFICLNAME;
    
    for (; i > 0; --i)
    {
        *cp++ = *name++;
    }

    *cp++ = '\0';

    pDict->here = PTRtoCELL cp;
    dictAlign(pDict);
    return oldCP;
}



/*
** Abort a definition in process: reclaim its memory and unlink it
** from the dictionary list. Assumes that there is a smudged 
** definition in process...otherwise does nothing.
*/
void dictAbortDefinition(FICL_DICT *pDict)
{
    pDict->here = (CELL *)pDict->smudge;    /* recover memory */
    return;
}


/*
** Aligns the given pointer to FICL_ALIGN address units.
** Returns the aligned pointer value.
*/
void *alignPtr(void *ptr)
{
#if FICL_ALIGN > 0
    char *cp;
    CELL c;
    cp = (char *)ptr + FICL_ALIGN_ADD;
    c.p = (void *)cp;
    c.u = c.u & (~FICL_ALIGN_ADD);
    ptr = (CELL *)c.p;
#endif
    return ptr;
}

/*
** Align the dictionary's free space pointer
*/
void dictAlign(FICL_DICT *pDict)
{
    pDict->here = alignPtr(pDict->here);
}


/*
** Allocate or remove n chars of dictionary space, with
** checks for underrun and overrun
*/
int dictAllot(FICL_DICT *pDict, int n)
{
    char *cp = (char *)pDict->here;
#if FICL_ROBUST
    if (n > 0)
    {
        if ((unsigned)n <= dictCellsAvail(pDict) * sizeof (CELL))
            cp += n;
        else
            return 1;       /* dict is full */
    }
    else
    {
        n = -n;
        if ((unsigned)n <= dictCellsUsed(pDict) * sizeof (CELL))
            cp -= n;
        else                /* prevent underflow */
            cp -= dictCellsUsed(pDict) * sizeof (CELL);
    }
#else
    cp += n;
#endif
    pDict->here = PTRtoCELL cp;
    return 0;
}


/*
** Reserve space for the requested number of cells in the
** dictionary. If nCells < 0 , removes space from the dictionary.
*/
int dictAllotCells(FICL_DICT *pDict, int nCells)
{
#if FICL_ROBUST
    if (nCells > 0)
    {
        if (nCells <= dictCellsAvail(pDict))
            pDict->here += nCells;
        else
            return 1;       /* dict is full */
    }
    else
    {
        nCells = -nCells;
        if (nCells <= dictCellsUsed(pDict))
            pDict->here -= nCells;
        else                /* prevent underflow */
            pDict->here -= dictCellsUsed(pDict);
    }
#else
    pDict->here += nCells;
#endif
    return 0;
}


/*
** Append the specified cell to the dictionary
*/
void dictAppendCell(FICL_DICT *pDict, CELL c)
{
    *pDict->here++ = c;
    return;
}


/*
** Append the specified char to the dictionary
*/
void dictAppendChar(FICL_DICT *pDict, char c)
{
    char *cp = (char *)pDict->here;
    *cp++ = c;
    pDict->here = PTRtoCELL cp;
    return;
}


/*
** Create a new word in the dictionary with the specified
** name, code, and flags
*/
FICL_WORD *dictAppendWord(FICL_DICT *pDict, 
                          char *name, 
                          FICL_CODE pCode, 
                          UNS8 flags)
{
    STRINGINFO si;
    SI_SETLEN(si, strlen(name));
    SI_SETPTR(si, name);
    return dictAppendWord2(pDict, si, pCode, flags);
}


FICL_WORD *dictAppendWord2(FICL_DICT *pDict, 
                           STRINGINFO si, 
                           FICL_CODE pCode, 
                           UNS8 flags)
{
    FICL_COUNT len  = SI_COUNT(si);
    char *name      = SI_PTR(si);
    char *pName     = dictCopyName(pDict, si);

    FICL_WORD *pFW = (FICL_WORD *)pDict->here;
    UNS16 hashIdx  = dictHash(name, len);

    pDict->smudge = pFW;
    pFW->link     = pDict->hashTbl[hashIdx];
    pFW->hash     = hashIdx;
    pFW->code     = pCode;
    pFW->flags    = flags;
    pFW->nName    = (char)len;
    pFW->name     = pName;
    /*
    ** Point "here" to first cell of new word's param area...
    */
    pDict->here   = pFW->param;

    if (!(flags & FW_SMUDGE))
        dictUnsmudge(pDict);

    return pFW;
}


/*
** Append the specified UNS32 to the dictionary
*/
void dictAppendUNS32(FICL_DICT *pDict, UNS32 u)
{
    *pDict->here++ = LVALUEtoCELL(u);
    return;
}


/*
** Returns the number of empty cells left in the dictionary
*/
int dictCellsAvail(FICL_DICT *pDict)
{
    return pDict->size - dictCellsUsed(pDict);
}


/*
** Returns the number of cells consumed in the dicionary
*/
int dictCellsUsed(FICL_DICT *pDict)
{
    return pDict->here - pDict->dict;
}


/*
** Checks the dictionary for corruption and throws appropriate
** errors
*/
void dictCheck(FICL_DICT *pDict, FICL_VM *pVM, int nCells)
{
    if ((nCells >= 0) && (dictCellsAvail(pDict) < nCells))
    {
        vmTextOut(pVM, "Error: dictionary full", 1);
        vmThrow(pVM, VM_ERREXIT);
    }

    if ((nCells <= 0) && (dictCellsUsed(pDict) < -nCells))
    {
        vmTextOut(pVM, "Error: dictionary underflow", 1);
        vmThrow(pVM, VM_ERREXIT);
    }

    return;
}


/*
** Create and initialize a dictionary with the specified number
** of cells capacity
*/
FICL_DICT  *dictCreate(unsigned nCells)
{
    FICL_DICT *pDict;

    pDict = ficlMalloc(sizeof (FICL_DICT) + nCells * sizeof (CELL));
    pDict->size = nCells;
    dictReset(pDict);
    return pDict;
}


/*
** Free all memory allocated for the given dictionary 
*/
void dictDelete(FICL_DICT *pDict)
{
    ficlFree(pDict);
    return;
}


/**************************************************************************
                             I t e r a t o r
** dictFirst initializes a DICT_ITERATOR struct to refer to the
** "first" word in the dictionary, and returns the address of that word.
** The "first" is quoted because the returned word in not guaranteed to
** be first in any real sense - it is just guaranteed to be a good
** starting place for dictNext! 
**************************************************************************/
FICL_WORD *dictFirst(FICL_DICT *pDict, DICT_ITERATOR *pDI)
{
    FICL_WORD *pFW;
    pDI->pDict = pDict;
    pDI->index = 0;
    pFW = pDict->hashTbl[0];
    pDI->next = pFW->link;
    return pFW;
}


FICL_WORD *dictNext(DICT_ITERATOR *pDI)
{
    FICL_WORD *pFW = pDI->next;

    while (!pFW && (++pDI->index < HASHSIZE))
    {
        pFW = pDI->pDict->hashTbl[pDI->index];
    }

    if (pFW)
        pDI->next = pFW->link;

    return pFW;
}


/**************************************************************************
                             D i c t H a s h
** 
** Generate a 16 bit hashcode from a character string using a rolling
** shift and add stolen from PJ Weinberger of Bell Labs fame. Case folds
** the name before hashing it...
**************************************************************************/
#if 1
UNS16 dictHash(char *name, FICL_COUNT count)
{   
    /* hashPJW */
    UNS8 *cp = (UNS8 *)name;
    UNS16 code = count;
    UNS16 shift = 0;

    while (*cp && count--)
    {
        code = (UNS16)((code << 4) + tolower(*cp++));
        shift = (UNS16)(code & 0xf000);
        if (shift)
        {
            code ^= (UNS16)(shift >> 8);
            code ^= (UNS16)shift;
        }
    }

    return (UNS16)(code % HASHSIZE);
}
#else
UNS16 dictHash(char *name, FICL_COUNT count)
{   
    /* hashJB from DDJ Jan 98 */
    UNS8 *cp = (UNS8 *)name;
    UNS16 code = count;
    UNS16 shift = 0;
    UNS8 ch;

    for ( ; ((0 != (ch=(UNS8)tolower(*cp++))) && count--); shift ^= 1)
    {
        if (shift)
            code += (UNS16)ch;
        else 
            code *= (UNS16)ch;

        code += (UNS16)((code & 0xffff0000) >> 16);
        code += (UNS16)((code & 0x0000ff00) >> 8);
    }

    return (UNS16)(code % HASHSIZE);
}
#endif


/*
** Calculate a figure of merit for the dictionary hash table based
** on the average search depth for all the words in the dictionary.
*/
void dictHashSummary(FICL_VM *pVM)
{
    FICL_WORD **pHash = ficlGetDict()->hashTbl;
    FICL_WORD *pFW;

    int i;
    int nMax = 0;
    int nWords = 0;
    int nFilled = HASHSIZE;
    double avg = 0.0;
    double best;
    int nAvg, nRem, nDepth;

    for (i = 0; i < HASHSIZE; i++)
    {
        int n = 0;
        pFW = pHash[i];

        while (pFW)
        {
            ++n;
            ++nWords;
            pFW = pFW->link;
        }

        avg += (double)(n * (n+1)) / 2.0;

        if (n > nMax)
            nMax = n;
        if (n == 0)
            --nFilled;
    }

    /* Calc actual avg search depth for this hash */
    avg = avg / nWords;

    /* Calc best possible performance with this size hash */
    nAvg = nWords / HASHSIZE;
    nRem = nWords % HASHSIZE;
    nDepth = HASHSIZE * (nAvg * (nAvg+1))/2 + (nAvg+1)*nRem;
    best = (double)nDepth/nWords;

    sprintf(pVM->pad, 
        "%d bins, %2.0f%% filled, Depth: Max=%d, Avg=%2.1f, Best=%2.1f, Score: %2.0f%%", 
        HASHSIZE,
        (double)nFilled * 100.0 / HASHSIZE, nMax,
        avg, 
        best,
        100.0 * best / avg);

    ficlTextOut(pVM, pVM->pad, 1);

    return;
}


/*
** Find the FICL_WORD that matches the given name and length.
** If found, returns the word's address. Otherwise returns NULL.
*/
FICL_WORD *dictLookup(FICL_DICT *pDict, char *name, FICL_COUNT count)
{
    FICL_COUNT nCmp = count;
    UNS16 hashIdx   = dictHash(name, count);
    FICL_WORD *pFW;

    if (nCmp > nFICLNAME)
        nCmp = nFICLNAME;

    ficlLockDictionary(1);
    pFW = pDict->hashTbl[hashIdx];
    while (pFW)
    {
        if ( (pFW->nName == count) 
            && (!strincmp(name, pFW->name, nCmp)) )
            return pFW;

        assert(pFW != pFW->link);
        pFW = pFW->link;
    }

    ficlLockDictionary(0);
    return NULL;
}


/*
** Initialize the given dictionary
*/
void dictReset(FICL_DICT *pDict)
{
    int i;
    FICL_WORD **ppFW;
    assert(pDict);
    pDict->here = pDict->dict;
    pDict->smudge = NULL;
    for (i = 0, ppFW = pDict->hashTbl; i < HASHSIZE; i++)
        *ppFW++ = NULL;

    return;
}


/*
** Set the most recently defined word as IMMEDIATE
*/
void dictSetImmediate(FICL_DICT *pDict)
{
    pDict->smudge->flags |= FW_IMMEDIATE;
    return;
}


/*
** Completes the definition of a word by linking it
** into the main list
*/
void dictUnsmudge(FICL_DICT *pDict)
{
    FICL_WORD *pFW = pDict->smudge;
    pDict->hashTbl[pFW->hash] = pFW;
    return;
}


/*
** Returns the value of the HERE pointer -- the address
** of the next free cell in the dictionary
*/
CELL *dictWhere(FICL_DICT *pDict)
{
    return pDict->here;
}


