\ automatic generated code
\ do not edit
windows also forth

window class dialog
public:
  early open
  infonumberfield ptr a#
  infonumberfield ptr b#
  | button ptr (button-00)
  | button ptr (button-01)
  | button ptr (button-02)
  | button ptr (button-03)
  | button ptr (button-04)
  | button ptr (button-05)
  | button ptr (button-06)
  infonumberfield ptr r#
how:
  : init  super init ( [dumpstart] )
        &12341234. ]N s" A:" ^ infonumberfield new dup bind a#
        &1234. ]N s" B:" ^ infonumberfield new dup bind b#
          ^ S[ a# get b# get d+ r# assign ]S s" +" ^ button new dup bind (button-00)
          ^ S[ a# get b# get d- r# assign ]S s" -" ^ button new dup bind (button-01)
          ^ S[ a# get b# get d* r# assign ]S s" *" ^ button new dup bind (button-02)
          ^ S[ a# get b# get drop ud/mod r# assign drop ]S s" /" ^ button new dup bind (button-03)
          ^ S[ a# get 1. b# get drop 0 ?DO 2over d* LOOP 2swap 2drop r# assign ]S s" ^" ^ button new dup bind (button-04)
          ^ S[ r# get a# assign ]S s" >A" ^ button new dup bind (button-05)
          ^ S[ r# get b# assign ]S s" >B" ^ button new dup bind (button-06)
        7 ^ hatbox new 1 hskips
        &12340000. ]N s" R:" ^ infonumberfield new dup bind r#
      4 ^ vabox new 1 vskips
    ( [dumpend] ) 1 0 ^ modal new s" Dialog" assign ;
  : open  screen self new >o map stop pause unmap dispose o> ;
class;

script? [IF]  dialog open bye  [THEN]
