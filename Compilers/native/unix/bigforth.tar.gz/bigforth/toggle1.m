\ automatic generated code
\ do not edit
windows also forth

window class toggle1
public:
  early open
  early modal-open
  | topindex ptr (topindex-00)
  | topindex ptr (topindex-01)
  | topindex ptr (topindex-02)
  | topindex ptr (topindex-03)
  | infotextfield ptr (infotextfield-04)
  | infotextfield ptr (infotextfield-05)
  | infotextfield ptr (infotextfield-06)
  | glue ptr (glue-07)
  | infotextfield ptr (infotextfield-08)
  | infonumberfield ptr (infonumberfield-09)
  | infotextfield ptr (infotextfield-0A)
  | infotextfield ptr (infotextfield-0B)
how:
  : open       screen self new >o map o> ;
  : modal-open screen self new >o map stop o> ;
class;

toggle1 implements
  : init  super init ^ { ^^ | ( [dumpstart] )
          0 0 flipper s" Toggle" ^ topindex new dup ^^ with bind (topindex-00) endwith 
          0 0 flipper s" Toggle-Var" ^ topindex new dup ^^ with bind (topindex-01) endwith 
          0 -1 flipper s" Toggle-Num" ^ topindex new dup ^^ with bind (topindex-02) endwith 
          0 0 flipper s" Toggle-State" ^ topindex new dup ^^ with bind (topindex-03) endwith 
        4 ^ harbox new
            s" " s" On:" ^ infotextfield new dup ^^ with bind (infotextfield-04) endwith 
            s" " s" Off:" ^ infotextfield new dup ^^ with bind (infotextfield-05) endwith 
          2 ^ vabox new flipbox  panel dup ^^ with C[ (topindex-00) ]C endwith 
            s" " s" Var:" ^ infotextfield new dup ^^ with bind (infotextfield-06) endwith 
            $0 $1 *hfil $14 $1 *vfil ^ glue new dup ^^ with bind (glue-07) endwith 
          2 ^ vabox new flipbox  panel dup ^^ with C[ (topindex-01) ]C endwith 
            s" " s" Var:" ^ infotextfield new dup ^^ with bind (infotextfield-08) endwith 
            &0. ]N s" Num:" ^ infonumberfield new dup ^^ with bind (infonumberfield-09) endwith 
          2 ^ vabox new panel dup ^^ with C[ (topindex-02) ]C endwith 
            s" " s" Fetch:" ^ infotextfield new dup ^^ with bind (infotextfield-0A) endwith 
            s" " s" Store" ^ infotextfield new dup ^^ with bind (infotextfield-0B) endwith 
          2 ^ vabox new flipbox  panel dup ^^ with C[ (topindex-03) ]C endwith 
        4 ^ vabox new $10  noborderbox  2 borderbox
      2 ^ vabox new
    ( [dumpend] ) } 1 0 ^ modal new 0 hskips 0 vskips s" Toggle" assign ;
class;

script? [IF]
  toggle1 modal-open
bye [TNEN]
