// MainFrm.h : interface of the CMainFrame class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MAINFRM_H__56346669_C818_11D1_84A4_0080C7B2ADBF__INCLUDED_)
#define AFX_MAINFRM_H__56346669_C818_11D1_84A4_0080C7B2ADBF__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class CMainFrame : public CFrameWnd
{
protected: // create from serialization only
	CMainFrame();
	DECLARE_DYNCREATE(CMainFrame)

    CSplitterWnd m_Splitter;
// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainFrame)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual BOOL OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMainFrame();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

    void SyncLeds(int value = 0);
    void SyncDAC(int value = 0);
    void SetLeds(int val);
    int  GetSwitch(void);
    void SetDAC(int val);
    int  GetADC(void);
    void SetStatus(char *msg);
    void SetStack(int base, int depth, CString *pStr);

protected:  // control bar embedded members
	CStatusBar  m_wndStatusBar;
	CToolBar    m_wndToolBar;
    CDialogBar  m_hardwareBar;
    CDialogBar  m_stackBar;

    BOOL m_hardwareShow;
    BOOL m_stackShow;
    int m_simSwitches;
    int m_simLeds;
    int m_simDAC;
    int m_simADC;
    int m_base;     // numeric base of running VM
    int m_depth;    // stack depth of running VM
    HICON m_hLedRed;
    HICON m_hLedOff;

    void OnSimSwitches(UINT nID);

// Generated message map functions
protected:
    afx_msg void OnUpdateIndicatorBase(CCmdUI *pCmdUI);
    afx_msg void OnUpdateIndicatorDepth(CCmdUI *pCmdUI);
	//{{AFX_MSG(CMainFrame)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnViewHardware();
	afx_msg void OnUpdateViewHardware(CCmdUI* pCmdUI);
	afx_msg void OnViewStack();
	afx_msg void OnUpdateViewStack(CCmdUI* pCmdUI);
	afx_msg void OnClose();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAINFRM_H__56346669_C818_11D1_84A4_0080C7B2ADBF__INCLUDED_)
