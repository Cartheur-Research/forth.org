/*
 * This file is part of the portable Forth environment written in ANSI C.
 * Copyright (C) 1999  Stefan Wenk
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 * This file is version 0.9.22 of 07-January-99
/*
 * fcinterf.c --- FORTH/C interface for C++Builder port
 */
#include "fcinterf.h"
#include "support.h"

char *field_addr_to_name(long xt)
{
  return to_name ( BODY_FROM( (Xt) xt) );
};

char * pfa_to_name(long xt )
{
  static char p[34];
  char *nfa=to_name ( (Xt) xt );
  sprintf (p, "%.*s", *nfa & 0x1F, nfa + 1);
  return ( p );
}
