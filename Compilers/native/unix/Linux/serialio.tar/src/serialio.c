/* serialio.c              Code to access the Serial ports,
 *                         set up for PFE
 */

/* The typical arrangement:
 *    /dev/cua0, /dev/ttyS0            COM1 
 *    /dev/cua1, /dev/ttyS1            COM2
 *    /dev/cua2, /dev/ttyS2            COM3
 *    /dev/cua3, /dev/ttyS3            COM4
 * 
 *    /dev/cuaN  are for outgoing connections
 *    /dev/ttySN are for incoming connections
 *
 */

#include <stdio.h>
#include <fcntl.h>
#include <signal.h>
#include <string.h>
#include <errno.h>
#include <setjmp.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <termios.h>
#include <sys/wait.h>



static void lm_setrts ( int fd );
static void lm_savestate ( int fd );
static void lm_restorestate ( int fd );
static void lm_nohang ( int fd );
static void lm_hupcl ( int fd, int on );
static void lm_flush ( int fd );
static void lm_setparms ( int fd , char *baudr , char *par , char *bits, int hwf, int swf );
static int lm_wait ( int* fd );


static jmp_buf albuf;


#define P_LOCK "/var/spool/uucp"

#define P_CALLIN  ""
#define P_CALLOUT ""

#ifndef CNULL
#define CNULL  ( (char *)0 )
#endif

typedef struct portinfo  {
              int   portfd;
              uid_t real_uid;	/* Real uid */
              gid_t real_gid;	/* Real gid */
              uid_t portuid;     /* Uid and Gid of /dev/ttyS... */
              gid_t portgid;
              char  s_port[32];
              char  lockfile[128];  /* UUCP lock file of terminal */
} portinfo;



static portinfo port_table[] =          /* if its not here, you cant open it */
{
     { -1, -1, -1, -1, -1, "/dev/cua0", "" },
     { -1, -1, -1, -1, -1, "/dev/cua1", "" },
     { -1, -1, -1, -1, -1, "/dev/cua2", "" },
     { -1, -1, -1, -1, -1, "/dev/cua3", "" },
     { -1, -1, -1, -1, -1, "/dev/ttyS0", "" },
     { -1, -1, -1, -1, -1, "/dev/ttyS1", "" },
     { -1, -1, -1, -1, -1, "/dev/ttyS2", "" },
     { -1, -1, -1, -1, -1, "/dev/ttyS3", "" },
     { -1, -1, -1, -1, -1, "/dev/modem", "" },
};


#define TABLE_SIZE  ( sizeof(port_table) / sizeof(portinfo) )

Code(fd_write)            /* write to fd */
{
  char *c_addr = (char *) sp[2];
  uCell u = sp[1];
  int fd = sp[0];

  sp += 2;
  sp[0] = write (fd, c_addr, u);
}

Code (fd_read)            /* read from fd */
{
  char *c_addr = (char *) sp[2];
  uCell u = sp[1];
  int fd =  sp[0];
  Cell r = read(fd, c_addr, u);

  sp += 2;
  sp[0] = r;
}

Code (fd_open)
{
  char *fn = (char *) sp[2];	/* c-addr, name */
  uCell u = sp[1];		/* length of name */
  Cell fam = sp[0];		/* file access mode */
  int fd = open(fn, u, fam);

  sp += 1;
  sp[1] = (Cell) fd;
  sp[0] = fd ? 0 : errno;
}

Code (fd_close)
{
  int fd = sp[0];

  sp[0] = close (fd) ? errno : 0;
}

Code (fd_nonblock)
{
   int fd = sp[0];
   
   sp[0] = fcntl( fd, F_SETFL, O_NONBLOCK);
}


static int findbyname(char* s, unsigned int u)
{
       int k;
   
       for (k = 0; k < TABLE_SIZE; ++k)
              if ( strncmp(port_table[k].s_port, s, u) == 0 )
	                              return k;

       errno = ENOENT;    /* no such device */
   
       return -1;
}

static int findbynumber(int fd)
{
       int k;
   
       for (k = 0; k < TABLE_SIZE; ++k)
              if ( fd == port_table[k].portfd )
	                              return k;

       errno = EINVAL;    /* invalid argument */

       return -1;
}

 /*
 * Return the last part of a filename.
 */

static char *Basename(char* s)
{
  char *p;
  
  if((p = strrchr(s, '/')) == (char *)NULL)
  	p = s;
  else
  	p++;
  return(p);
}

static void get_alrm(int dummy)
{
  (void)dummy;
  longjmp(albuf, 1);
}

/*
 * A modified version of the getargs routine.
 */
static int getargs(s, arps, maxargs)
register char *s;
char *arps[];
int maxargs;
{
	register int i;
	register char *sp;
	register char qchar;
	int literal = 0;

	i = 0;
	while (i < maxargs) {
		while (*s == ' ' || *s == '\t')
			++s;
		if (*s == '\n' || *s == '\0')
			break;
		arps[i++] = sp = s;
		qchar = 0;
		while(*s != '\0'  &&  *s != '\n') {
			if (literal) {
				literal = 0;
				*sp++ = *s++;
				continue;
			}
			literal = 0;
			if (qchar == 0 && (*s == ' ' || *s == '\t')) {
				++s;
				break;
			}
			switch(*s) {
			default:
				*sp++ = *s++;
				break;
			case '\\':
				literal = 1;
				s++;
				break;	
			case '"':
			case '\'':
				if(qchar == *s) {
					qchar = 0;
					++s;
					break;
				}
				if(qchar)
					*sp++ = *s++;
				else
					qchar = *s++;
				break;
			}
		}
		*sp++ = 0;
	}
	if (i >= maxargs)
		return -1;
	arps[i] = (char *)0;
	return i;
}

/*
 * Is a character from s2 in s1?
 */
static int anys(char* s1,char* s2)
{
  while(*s2)
  	if (strchr(s1, *s2++) != (char *)NULL) return(1);
  return(0);
}

/*
 * If there is a shell-metacharacter in "cmd",
 * call a shell to do the dirty work.
 */
static int fastexec(char* cmd)
{
  char *words[128];
  char *p;

  if (anys(cmd, "~`$&*()=|{};?><"))
  	return(execl("/bin/sh", "sh", "-c", cmd, (char *)0));

  /* Delete escape-characters ment for the shell */
  p = cmd;
  while((p = strchr(p, '\\')) != (char *)NULL)
  	strcpy(p, p + 1);

  /* Split line into words */
  if (getargs(cmd, words, 127) < 0) {
  	return(-1);
  }
  return (execvp(words[0], words));
}

/*
 * Fork, then redirect I/O if neccesary.
 * in    : new stdin
 * out   : new stdout
 * err   : new stderr
 * Returns exit status of "cmd" on success, -1 on error.
 */
static int fastsystem(char* cmd,char* in,char* out,char* err)
{
  int pid;
  int st;
  int async = 0;
  char *p;

  /* If the command line ends with '&', don't wait for child. */
  p = strrchr(cmd, '&');
  if (p != (char *)0 && !p[1]) {
  	*p = 0;
  	async = 1;
  }
  
  /* Fork. */
  if ((pid = fork()) == 0) { /* child */
  	if (in != (char *)NULL) {
  		close(0);
  		if (open(in, O_RDONLY) < 0) exit(-1);
  	}
  	if (out != (char *)NULL) {
  		close(1);
  		if (open(out, O_WRONLY) < 0) exit(-1);
  	}
  	if (err != (char *)NULL) {
  		close(2);
  		if (open(err, O_RDWR) < 0) exit(-1);
  	}
  	exit(fastexec(cmd));
  } else if (pid > 0) { /* parent */
  	if (async) return(0);
  	pid = lm_wait(&st);
  	if (pid < 0) return(-1);
  	return(st);
  }
  return(-1);
}

 /*
 * Open the port.
 */

static int open_portinfo(struct portinfo *p, int doinit)
{
  struct stat stt;
  char buf[128];
  int fd, n = 0;
  int pid;

   p->real_uid = getuid();
   p->real_gid = getgid();
   
  /* First see if the lock file directory is present. */
  if (P_LOCK[0] && stat(P_LOCK, &stt) == 0)
  	sprintf(p->lockfile, "%s/LCK..%s", P_LOCK, Basename(p->s_port));
  else
	p->lockfile[0] = 0;

  if (doinit >= 0 && p->lockfile[0] && (fd = open(p->lockfile, O_RDONLY)) >= 0) {
	n = read(fd, buf, 127);
	close(fd);
	if (n > 0) {
		pid = -1;
		if (n == 4)
			/* Kermit-style lockfile. */
			pid = *(int *)buf;
		else {
			/* Ascii lockfile. */
			buf[n] = 0;
			sscanf(buf, "%d", &pid);
		}
		if (pid > 0 && kill(pid, 0) < 0 &&
			errno == ESRCH) {
		    fprintf(stderr, "Lockfile is stale. Overriding it..\n");
		    sleep(1);
		    unlink(p->lockfile);
		} else
		    n = 0;
	}
	if (n == 0) {
  		fprintf(stderr, "Device %s is locked.\n", p->s_port);
		return(-1);
	}
  }

  /* Run a special program to disable callin if needed. */
  if (doinit > 0 && P_CALLOUT[0]) {
	if(fastsystem(P_CALLOUT, CNULL, CNULL, CNULL) < 0) {
  		fprintf(stderr, "Could not setup for dial out.\n");
  		if (p->lockfile[0]) unlink(p->lockfile);
		close(p->portfd);
		return(-1);
  	}
  }

  /* Now open the tty device. */
  if (setjmp(albuf) == 0) {
	p->portfd = -1;
	signal(SIGALRM, get_alrm);
	alarm(2);
#ifdef O_NDELAY
	p->portfd = open(p->s_port, O_RDWR|O_NDELAY);
	if (p->portfd >= 0){
		/* Open it a second time, now with O_NDELAY. */
		if (doinit >= 0) lm_savestate(p->portfd);
		/* port_init(); */
		fd = p->portfd;
		p->portfd = open(p->s_port, O_RDWR);
		if (p->portfd < 0 && doinit >= 0) lm_restorestate(fd);
		close(fd);
	}
#else
	p->portfd = open(p->s_port, O_RDWR);
	if (p->portfd >= 0) {
		if (doinit >= 0) lm_savestate(p->portfd);
		/* port_init(); */
	}
#endif
  }
  alarm(0);
  signal(SIGALRM, SIG_IGN);
  if (p->portfd < 0) {
	if (doinit >= 0) {
  		fprintf(stderr, "Cannot open %s. Sorry.\n",
  				p->s_port);
		return(-1);
	}
	fprintf(stderr,"Cannot open %s!", p->s_port);
	return(-1);
  }
  /* Remember owner of port */
  stat(p->s_port, &stt);
  p->portuid = stt.st_uid;
  p->portgid = stt.st_gid;

  /* Give it to us! */
  if (p->real_uid != 0) chown(p->s_port, p->real_uid, p->real_gid);

  if (doinit >= 0 && p->lockfile[0]) {
  	/* Create lockfile compatible with UUCP-1.2 */
#ifdef _COH3
	if ((fd = creat(p->lockfile, 0666)) < 0) {
#else
  	if ((fd = open(p->lockfile, O_WRONLY | O_CREAT | O_EXCL, 0666)) < 0) {
#endif
  		fprintf(stderr, "Cannot create lockfile. Sorry.\n");
		return(-1);
  	}
  	sprintf(buf, "%05d forth %20.20s", getpid(), getenv("LOGNAME"));
  	write(fd, buf, strlen(buf));
  	close(fd);
  }
  /* Set CLOCAL mode */
  lm_nohang(p->portfd);
  /* Set Hangup on Close if program crashes. (Hehe) */
  lm_hupcl(p->portfd, 1);
  if (doinit > 0) lm_flush(p->portfd);
  errno = 0;
  return( p->portfd );
}

Code (open_serial)
{
        int idx;
        char *s_port = (char *)sp[2];
        uCell u = sp[1];
        Cell doinit = sp[0];
   
        if ( (idx = findbyname( s_port, u ) ) < 0 )
        {
	              sp += 1;
	              sp[1] = idx;
	              sp[0] = errno;
	              return;
	}
   
        idx = open_portinfo(&port_table[idx], doinit);

        if ( idx < 0 )
                errno = EACCES;     /* busy or access denied */
        else
   	        lm_setparms( idx, "B9600", "NONE", "8", 1, 0);

        sp += 1;
        sp[1] = idx;
        sp[0] = idx < 0 ? errno : 0;
}

   
/*
 * Leave.
 */
static int close_portinfo(struct portinfo *p)
{
   int retval = -1;
  if (p->portfd > 0) {
	lm_restorestate(p->portfd);
	retval = close(p->portfd);
  }
  if (p->lockfile[0]) unlink(p->lockfile);
  if (P_CALLIN[0]) (void) fastsystem(P_CALLIN, CNULL, CNULL, CNULL);
  if (p->real_uid) chown(p->s_port, p->portuid, p->portgid);
   
   p->portfd = -1;
   return retval;
}

Code (close_serial)
{
        int idx;
        int portfd = (int) sp[0];

        errno = 0;
        if ( (idx = findbynumber( portfd ) ) >= 0 )
                        errno = close_portinfo( &port_table[idx] );

        sp[0] = errno;
}

/*
 * sysdep1.c	system dependant routines.
 *
 *		m_dtrtoggle	- dropt dtr and raise it again
 *		m_break		- send BREAK signal
 *		m_getdcd	- get modem dcd status
 *		m_setdcd	- set modem dcd status
 *		m_savestate	- save modem state
 *		m_restorestate	- restore saved modem state
 *		m_nohang	- tell driver not to hang up at DTR drop
 *		m_hupcl		- set hangup on close on/off
 *		m_setparms	- set baudrate, parity and number of bits.
 *		m_wait		- wait for child to finish. Sysdep. too.
 *
 *		If it's possible, Posix termios are preferred.
 *
 *		This file is part of the minicom communications package,
 *		Copyright 1991,1992,1993,1994 Miquel van Smoorenburg.
 *
 *		This program is free software; you can redistribute it and/or
 *		modify it under the terms of the GNU General Public License
 *		as published by the Free Software Foundation; either version
 *		2 of the License, or (at your option) any later version.
 */

#  ifndef WEXITSTATUS
#    define WEXITSTATUS(s) (((s) >> 8) & 0377)
#  endif
#  ifndef WTERMSIG
#    define WTERMSIG(s) ((s) & 0177)
#  endif

/* Set RTS line. Sometimes dropped. Linux specific? */
static void lm_setrts(int fd)
{
#if defined(TIOCM_RTS) && defined(TIOCMODG)
  int mcs;

  ioctl(fd, TIOCMODG, &mcs);
  mcs |= TIOCM_RTS;
  ioctl(fd, TIOCMODS, &mcs);
#endif
#ifdef _COHERENT
  ioctl(fd, TIOCSRTS, 0);
#endif
}

Code(m_setrts)
{
   int fd = (int)sp[0];
   lm_setrts( fd );
   sp += 1;
}
   
/*
 * Drop DTR line and raise it again.
 */
Code(m_dtrtoggle) 
{
   int fd = (int)sp[0];
#if defined (_POSIX_SOURCE) && !defined(_HPUX_SOURCE)
  struct termios tty, old;

  tcgetattr(fd, &tty);
  tcgetattr(fd, &old);
  cfsetospeed(&tty, B0);
  cfsetispeed(&tty, B0);
  tcsetattr(fd, TCSANOW, &tty);
  sleep(1);
  tcsetattr(fd, TCSANOW, &old);
#else
#  ifdef _V7
#    ifndef TIOCCDTR
  /* Just drop speed to 0 and back to normal again */
  struct sgttyb sg, ng;
  
  ioctl(fd, TIOCGETP, &sg);
  ioctl(fd, TIOCGETP, &ng);
  
  ng.sg_ispeed = ng.sg_ospeed = 0;
  ioctl(fd, TIOCSETP, &ng);
  sleep(1);
  ioctl(fd, TIOCSETP, &sg);
#    else
  /* Use the ioctls meant for this type of thing. */
  ioctl(fd, TIOCCDTR, 0);
  sleep(1);
  ioctl(fd, TIOCSDTR, 0);
#    endif
#  endif
#  ifdef _HPUX_SOURCE
  unsigned long mflag = 0L;

  ioctl(fd, MCSETAF, &mflag);
  ioctl(fd, MCGETA, &mflag);
  mflag = MRTS | MDTR;
  sleep(1);
  ioctl(fd, MCSETAF, &mflag);
#  endif
#endif
   sp += 1;
}

/*
 * Send a break
 */
Code (m_break)
{ 
   int fd = (int)sp[0];
#ifdef _POSIX_SOURCE
#  ifdef linux
  /* Linux kernels < .99pl8 don't support tcsendbreak() yet.. */
  ioctl(fd, TCSBRK, 0);
#  else
  tcsendbreak(fd, 0);
#  endif
#else
#  ifdef _V7
#    ifndef TIOCSBRK
  struct sgttyb sg, ng;

  ioctl(fd, TIOCGETP, &sg);
  ioctl(fd, TIOCGETP, &ng);
  ng.sg_ispeed = ng.sg_ospeed = B110;
  ng.sg_flags = BITS8 | RAW;
  ioctl(fd, TIOCSETP, &ng);
  write(fd, "\0\0\0\0\0\0\0\0\0\0", 10);
  ioctl(fd, TIOCSETP, &sg);
#    else
  ioctl(fd, TIOCSBRK, 0);
  sleep(1);
  ioctl(fd, TIOCCBRK, 0);
#    endif
#  endif
#endif
   sp += 1;
}

/*
 * Get the dcd status
 */
Code(m_getdcd)
{
   int fd = (int)sp[0];
#ifdef _MINIX
  struct sgttyb sg;
  
  ioctl(fd, TIOCGETP, &sg);
  sp[0] = sg.sg_flags & DCD ? 1 : 0;
#else
#  ifdef TIOCMODG
  int mcs;
   
  ioctl(fd, TIOCMODG, &mcs);
  sp[0] = (mcs & TIOCM_CAR ? 1 : 0);
#  else
  (void)fd;
  sp[0] = 0; /* Impossible!! (eg. Coherent) */
#  endif
#endif
}

/*
 * Set the DCD status
 */
/*ARGSUSED*/
Code(m_setdcd)
{
     int what = sp[0];
     int fd = sp[1];
#ifdef _MINIX
  /* Just a kludge for my Minix rs 232 driver */
  struct sgttyb sg;
  
  ioctl(fd, TIOCGETP, &sg);
  if (what)
  	sg.sg_flags |= DCD;
  else
  	sg.sg_flags &= ~DCD;
  ioctl(fd, TIOCSETP, &sg);
#else
  /* Shut up compilers. */
  (void)fd;
  (void)what;
#endif
   sp += 2;
}

/* Variables to save states in */
#ifdef _POSIX_SOURCE
static struct termios savetty;
/* static int m_word; */
#else
#  if defined (_BSD43) || defined (_V7)
static struct sgttyb sg;
static struct tchars tch;
static int lsw;
static int m_word;
#  endif
#endif

/*
 * Save the state of a port
 */
static void lm_savestate(int fd)
{
#ifdef _POSIX_SOURCE
  tcgetattr(fd, &savetty);
#else
#  if defined(_BSD43) || defined(_V7)
  ioctl(fd, TIOCGETP, &sg);
  ioctl(fd, TIOCGETC, &tch);
#  endif
#  ifdef _BSD43
  ioctl(fd, TIOCLGET, &lsw);
#  endif
#endif
#ifdef TIOCMODG
  ioctl(fd, TIOCMODG, &m_word);
#endif
}

Code(m_savestate)
{
    int fd = sp[0];
   
     lm_savestate( fd );
   
      sp += 1;
}
   
/*
 * Restore the state of a port
 */
static void lm_restorestate(int fd)
{
#ifdef _POSIX_SOURCE
  tcsetattr(fd, TCSANOW, &savetty);
#else
#  if defined(_BSD43) || defined(_V7)
  ioctl(fd, TIOCSETP, &sg);
  ioctl(fd, TIOCSETC, &tch);
#  endif
#  ifdef _BSD43  
  ioctl(fd, TIOCLSET, &lsw);
#  endif
#endif
#ifdef TIOCMODS
  ioctl(fd, TIOCMODS, &m_word);
#endif
}

Code(m_restorestate)
{
	
	int fd = sp[0];
	lm_restorestate( fd );
	sp += 1;
}
   
/*
 * Set the line status so that it will not kill our process
 * if the line hangs up.
 */
/*ARGSUSED*/ 
static void lm_nohang( int fd )
{
#ifdef _POSIX_SOURCE
  struct termios sgg;
  
  tcgetattr(fd, &sgg);
  sgg.c_cflag |= CLOCAL;
  tcsetattr(fd, TCSANOW, &sgg);
#else
#  if defined (_BSD43) && defined(LNOHANG)
  int lsw;
  
  ioctl(fd, TIOCLGET, &lsw);
  lsw |= LNOHANG;
  ioctl(fd, TIOCLSET, &lsw);
#  endif
#  ifdef _MINIX
  /* So? What about 1.6 ? */
#  endif
#  ifdef _COHERENT
  /* Doesn't know about this either, me thinks. */
#  endif
#endif
}

Code(m_nohang)
{
	
	int fd = sp[0];
	lm_nohang( fd );
	sp += 1;
}
   
/*
 * Set hangup on close on/off.
 */
void lm_hupcl(int fd,int on)
{
  /* Eh, I don't know how to do this under BSD (yet..) */
#ifdef _POSIX_SOURCE
  struct termios sgg;
  
  tcgetattr(fd, &sgg);
  if (on)
  	sgg.c_cflag |= HUPCL;
  else
	sgg.c_cflag &= ~HUPCL;
  tcsetattr(fd, TCSANOW, &sgg);
#endif
}

Code(m_hupcl)
{
	int on = sp[0];
	int fd = sp[1];
	
	lm_hupcl( fd, on );
	sp += 2;
}
	
/*
 * Flush the buffers
 */
static void lm_flush(int fd)
{
/* Should I Posixify this, or not? */
#ifdef TCFLSH
  ioctl(fd, TCFLSH, 2);
#endif
#ifdef TIOCFLUSH
#ifdef _COHERENT
  ioctl(fd, TIOCFLUSH, 0);
#else
  ioctl(fd, TIOCFLUSH, (void *)0);
#endif
#endif
}

Code(m_flush)
{
     int fd = sp[0];
	lm_flush( fd );
	sp += 1;
}
/*
 * Set baudrate, parity and number of bits.
 */
static void lm_setparms(int fd,char* baudr,char* par,char* bits,int hwf,int swf)
{
  int spd = -1;
  int newbaud;

#ifdef _POSIX_SOURCE
  struct termios tty;

  tcgetattr(fd, &tty);
#else
  struct sgttyb tty;

  ioctl(fd, TIOCGETP, &tty);
#endif

  /* Check if 'baudr' is really a number */
  if ((newbaud = atoi(baudr)) == 0 && baudr[0] != '0') newbaud = -1;

  switch(newbaud) {
  	case 0:
#ifdef B0
			spd = B0;	break;
#else
			spd = 0;	break;
#endif
  	case 300:	spd = B300;	break;
  	case 600:	spd = B600;	break;
  	case 1200:	spd = B1200;	break;
  	case 2400:	spd = B2400;	break;
  	case 4800:	spd = B4800;	break;
  	case 9600:	spd = B9600;	break;
#ifdef B19200
  	case 19200:	spd = B19200;	break;
#else
#  ifdef EXTA
	case 19200:	spd = EXTA;	break;
#   else
	case 19200:	spd = B9600;	break;
#   endif	
#endif	
#ifdef B38400
  	case 38400:	spd = B38400;	break;
#else
#  ifdef EXTA
	case 38400:	spd = EXTA;	break;
#   else
	case 38400:	spd = B9600;	break;
#   endif
#endif	

  }
  
#if defined (_BSD43) && !defined(_POSIX_SOURCE)
  if (spd != -1) tty.sg_ispeed = tty.sg_ospeed = spd;
  /* Number of bits is ignored */

  tty.sg_flags = RAW | TANDEM;
  if (par[0] == 'E')
	tty.sg_flags |= EVENP;
  else if (par[0] == 'O')
	tty.sg_flags |= ODDP;
  else
  	tty.sg_flags |= PASS8 | ANYP;

  ioctl(fd, TIOCSETP, &tty);

#  ifdef TIOCSDTR
  /* FIXME: huh? - MvS */
  ioctl(fd, TIOCSDTR, 0);
#  endif
#endif

#if defined (_V7) && !defined(_POSIX_SOURCE)
  if (spd != -1) tty.sg_ispeed = tty.sg_ospeed = spd;
#ifdef _MINIX
  switch(bits[0]) {
  	case '5' : spd = BITS5; break;
  	case '6' : spd = BITS6; break;
  	case '7' : spd = BITS7; break;
  	case '8' :
  	default: spd = BITS8; break;
  }
  tty.sg_flags = RAW | spd;
#else
  tty.sg_flags = RAW;
#endif
  if (par[0] == 'E')
	tty.sg_flags |= EVENP;
  else if (par[0] == 'O')
	tty.sg_flags |= ODDP;

  ioctl(fd, TIOCSETP, &tty);
#endif

#ifdef _POSIX_SOURCE

  if (spd != -1) {
	cfsetospeed(&tty, (speed_t)spd);
	cfsetispeed(&tty, (speed_t)spd);
  }

  switch (bits[0]) {
  	case '5':
  		tty.c_cflag = (tty.c_cflag & ~CSIZE) | CS5;
  		break;
  	case '6':
  		tty.c_cflag = (tty.c_cflag & ~CSIZE) | CS6;
  		break;
  	case '7':
  		tty.c_cflag = (tty.c_cflag & ~CSIZE) | CS7;
  		break;
  	case '8':
	default:
  		tty.c_cflag = (tty.c_cflag & ~CSIZE) | CS8;
  		break;
  }		
  /* Set into raw, no echo mode */
  tty.c_iflag &= ~(IGNBRK | IGNCR | INLCR | ICRNL | IUCLC | 
  	IXANY | IXON | IXOFF | INPCK | ISTRIP);
  tty.c_iflag |= (BRKINT | IGNPAR);
  tty.c_oflag &= ~OPOST;
  tty.c_lflag = ~(ICANON | ISIG | ECHO | ECHONL | ECHOE | ECHOK);
  tty.c_cflag |= CREAD | CRTSCTS;
  tty.c_cc[VMIN] = 1;
  tty.c_cc[VTIME] = 5;

  /* Flow control. */
  if (!hwf) tty.c_cflag &= ~CRTSCTS;
  if (swf) tty.c_iflag |= IXON;

  tty.c_cflag &= ~(PARENB | PARODD);
  if (par[0] == 'E')
	tty.c_cflag |= PARENB;
  else if (par[0] == 'O')
	tty.c_cflag |= PARODD;

  tcsetattr(fd, TCSANOW, &tty);

  lm_setrts(fd);
#endif
}

Code(m_setparms)
{
         int swf = sp[0];
         int hwf = sp[1];
         /* int bcnt = sp[2]; */
         char* bits = (char *)sp[3];
         /* int pcnt = sp[4]; */
         char* par = (char *)sp[5];
         /* int bdcnt = sp[6]; */
         char* baudr = (char *)sp[7];
         int fd = sp[8];

         lm_setparms(fd,baudr,par,bits,hwf,swf);
   
         sp += 9;
}

/*
 * Wait for child and return pid + status
 */
static int lm_wait( int *stt )
{
#if defined (_BSD43) && !defined(_POSIX_SOURCE)
  int pid;
  union wait st1;
  
  pid = wait((void *)&st1);
  *stt = (unsigned)st1.w_retcode + 256 * (unsigned)st1.w_termsig;
  return pid;
#else
  int pid;
  int st1;
  
  pid = wait(&st1);
  *stt = (unsigned)WEXITSTATUS(st1) + 256 * (unsigned)WTERMSIG(st1);
  return pid;
#endif
}

Code(m_wait)
{
   int *stt = (int *)sp[0];
   
    sp[0] = lm_wait( stt );
}



