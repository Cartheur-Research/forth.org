// ficlwinDoc.cpp : implementation of the CFiclwinDoc class
//

#include "stdafx.h"
#include "ficlwin.h"

#include "ficlwinDoc.h"
#include "ficlwinView.h"
#include <stdlib.h>
#include <direct.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFiclwinDoc

IMPLEMENT_DYNCREATE(CFiclwinDoc, CDocument)

BEGIN_MESSAGE_MAP(CFiclwinDoc, CDocument)
	//{{AFX_MSG_MAP(CFiclwinDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFiclwinDoc construction/destruction

CFiclwinDoc::CFiclwinDoc()
{
	// TODO: add one-time construction code here

}

CFiclwinDoc::~CFiclwinDoc()
{
}

BOOL CFiclwinDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	((CEditView*)m_viewList.GetHead())->SetWindowText(NULL);
	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CFiclwinDoc serialization

void CFiclwinDoc::Serialize(CArchive& ar)
{
	// CEditView contains an edit control which handles all serialization
	((CEditView*)m_viewList.GetHead())->SerializeRaw(ar);
}

/////////////////////////////////////////////////////////////////////////////
// CFiclwinDoc diagnostics

#ifdef _DEBUG
void CFiclwinDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CFiclwinDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CFiclwinDoc commands

BOOL CFiclwinDoc::SaveModified() 
{
	// Overridden to do nothing... there's not really a doc to save
    // return CDocument::SaveModified();
    return TRUE;	
}

BOOL CFiclwinDoc::OnOpenDocument(LPCTSTR lpszPathName) 
{
    char drive[_MAX_DRIVE];
    char dir[_MAX_DIR];
    int iOldDrive = _getdrive();
    int iNewDrive;
    CString *pStr = new CString;


    _splitpath(lpszPathName, drive, dir, NULL, NULL);
    iNewDrive = drive[0] - 'A' + 1;
    if (iOldDrive != iNewDrive)
    {
        _chdrive(iNewDrive);
    }

    _chdir(dir);

    pStr->Format("load %s", lpszPathName);
	((CFiclwinView *)m_viewList.GetHead())->SendFiclMsg(pStr);
	
	return TRUE;
}
