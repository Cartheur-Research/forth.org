/*
|	FILE: UNTIL.C
|
|	This module contains copyrighted source code for part the 
|	UNTIL Language Materials. 
|
|	Written by:
|		Norman E. Smith, CDP
|		Copyright 1992, 1994
|		All Rights Reserved
|
|	Right to use, copy, and modify this code is granted
|	for personal non-commercial use, provided that this
|	copyright disclosure remains on ALL copies. Any other
|	use, reproduction, or distribution is covered in the
|	License Agreement with the Until Language Maeterials
|	documentation and in the file LICENSE.TXT.
*/

#include "compiler.h"

#include <stdio.h>

#ifdef ANSIC
#include <process.h>
#include <conio.h>
#endif

#include "until.h"
#include "functs.h"

/***********************+-----------+
|			| save_args |
|			+-----------+
*/
void save_args(int argc, char **argv)
{
	long success;
	int  i;
	char trash[128];
		/*
		| Initialization and such
		*/
	INPUT_SOURCE      = 0;
	fargc = argc;
	fargv = argv;
		/*
		| Check to see if there are args.
		*/
	for(i=(argc-1);i;i--){
		strcpy(trash,argv[i]);
		if(trash[0] == '-'){		/* Got cmd line args */
			switch(trash[1]){
			case 'f':		/* File to load      */
			case 'F':
				strcpy(arg_file,&trash[2]);
				success = do_autoload(arg_file,SOURCE);
				if(!success){
					printf("Could not open %s\n",arg_file);
					getchar(); /* wait for key press */
				}
				break;
			case 'w':		/* Word to run       */
			case 'W':
				strcpy(first_word,&trash[2]);
				break;
			default:
				printf("Invalid flag; Ignored\n");
			}
		}
	}
}
/***********************+------+
|			| main |
|			+------+
*/
void main(int argc, char **argv)
{
	save_args(argc,argv);
#ifdef BCC
	clrscr();
#endif
	startup();
/*
printf("***********\n");
Until(".s");
*/
}
/***********************+-------+
|			| Until |
|			+-------+
*/
void Until(char *word)
{
	long len;
		/*
		| Boot to application word
		*/
	len = strlen(word);
	if(len){
		QUIT   = FALSE;
		strcpy((pad + 1),word);
		*pad   = len;
		exec_word();
	}
}
