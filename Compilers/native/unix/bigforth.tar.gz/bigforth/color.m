\ automatic generated code
\ do not edit
windows also forth

window class set-color
public:
  early open
  early modal-open
  | rbutton ptr (rbutton-00)
  | rbutton ptr (rbutton-01)
  | rbutton ptr (rbutton-02)
  | rbutton ptr (rbutton-03)
  | button ptr (button-04)
  | button ptr (button-05)
how:
  : open       screen self new >o map o> ;
  : modal-open screen self new >o map stop o> ;
class;

window class show-color
public:
  early open
  early modal-open
  infotextfield ptr choise
  | button ptr (button-00)
  | button ptr (button-01)
how:
  : open       screen self new >o map o> ;
  : modal-open screen self new >o map stop o> ;
class;

set-color implements
  : init  super init ^ { ^^ | ( [dumpstart] )
          ^^ TN[ 0 color ]TN s" Rot" ^ rbutton new dup ^^ with bind (rbutton-00) endwith 
          ^^ TN[ 1 color ]TN s" Gr�n" ^ rbutton new dup ^^ with bind (rbutton-01) endwith 
          ^^ TN[ 2 color ]TN s" Blau" ^ rbutton new dup ^^ with bind (rbutton-02) endwith 
          ^^ TN[ 3 color ]TN s" Alpha" ^ rbutton new dup ^^ with bind (rbutton-03) endwith 
        4 ^ varbox new
          ^^ S[ show-color open color @ screen childs self show-color with s" RGBA" drop + 1 choise assign endwith ]S s" Ok" ^ button new dup ^^ with bind (button-04) endwith 
          ^^ S[ close ]S s" Cancel" ^ button new dup ^^ with bind (button-05) endwith 
        2 ^ vabox new panel
      2 ^ habox new
    ( [dumpend] ) } 1 0 ^ modal new 0 hskips 0 vskips s" Set Color" assign ;
class;

show-color implements
  : init  super init ^ { ^^ | ( [dumpstart] )
        s" " s" Wahl:" ^ infotextfield new dup ^^ with bind choise endwith 
          ^^ S[ close ]S s" OK" ^ button new dup ^^ with bind (button-00) endwith 
          ^^ S[ close ]S s" Cancel" ^ button new dup ^^ with bind (button-01) endwith 
        2 ^ hatbox new 1 hskips
      2 ^ habox new panel
    ( [dumpend] ) } 1 0 ^ modal new 0 hskips 0 vskips s" Your Choise" assign ;
class;

script? [IF]
  set-color modal-open
bye [TNEN]
