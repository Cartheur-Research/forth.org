
/*
 * This file is part of the portable Forth environment written in ANSI C.
 * Copyright (C) 1999  Stefan Wenk
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 * This file is version 0.9.22 of 07-January-99
/*
 * pfeform.cpp --- Form for C++Builder port
 */
#include <vcl\vcl.h>
#include <vcl/dstring.h>

#pragma hdrstop
#include "PFEForm.h"
#include "iointerf.h"                
#include "fcinterf.h"
#include "main.h"
#include "yours.h"
#include "term.h"
#include <shellapi.h>
#include <string.h>

#include <io.h>
#include <stdio.h>
#include <sysutils.hpp>

//---------------------------------------------------------------------------
#pragma resource "*.dfm"
TPFEMainForm *PFEMainForm;

//---------------------------------------------------------------------
// exported standard C++ interface function that calls into VCL

//---------------------------------------------------------------------------
__fastcall TPFEMainForm::TPFEMainForm(TComponent* Owner)
	: TForm(Owner)
{
}

//---------------------------------------------------------------------------
void __fastcall TPFEMainForm::FormCreate(TObject *Sender)
{
 reset_your_variables();
// SendMessage(PfeMainForm->ListBox1->Handle, LB_SETHORIZONTALEXTENT , 1000, 0);
// Create Horizontal Scrollbar
 if (ParamCount()!=0)
 {   // Get  Arguments from Commandline
   int i,index;
   index=0;
   for (i = 1; i < ParamCount()+1; i++)
    {
      strcpy(&argbuffer[index],ParamStr(i).c_str());
      argv[i]=&argbuffer[index];
      index+=ParamStr(i).Length()+1;
      LoadDictionary1->Enabled=true;
    }
   Param_Count_value=ParamCount()+1;
  }
 // start FORTH compilation after displaying the window !
 StartForthTimer->Enabled=true;
}
//---------------------------------------------------------------------------
void Bell(void)
{
  MessageBeep(0);
}
//---------------------------------------------------------------------------
void ClearListBox()
{
   if ( PFEMainForm!=NULL)
    PFEMainForm->ListBox1->Items->Clear();
}
//---------------------------------------------------------------------------
void
list_box_outs (const char *s)            /* type a string in a listbox*/
{
 char buffer[256];
 if ( strchr(s, '\t')  ||  strchr(s, '\b') )
   {
       int i;
       for (i = 0; i <= strlen(s) +1; i++)
         {
          if ( (s[i]=='\t') || (s[i]=='\b') )
             { buffer[i]=' '; }
           else
             { buffer[i]=s[i]; }
         }
    if ( PFEMainForm!=NULL)
     { PFEMainForm->ListBox1->Items->Add(buffer); }
     else
     { printf ("%s\n",buffer); }
   }
 else
   {
    if ( PFEMainForm!=NULL)
    { PFEMainForm->ListBox1->Items->Add(s); }
    else
    { printf("%s\n",s);}
   }
 if ( PFEMainForm!=NULL)
 { PFEMainForm->ListBox1->TopIndex=PFEMainForm->ListBox1->Items->Count - 5; }
}

int question_cr_dialog (void )            /* ask for continuing dumping */
{
   if (MessageBox(0,"More", "Continue dumping?", MB_YESNO)==IDYES)
     return(0);
    else
     return(1);
}

int question_quit_dialog (char * msg )            /* ask for quit */
{
   if (MessageBox(0, msg , "Quit ?" , MB_OKCANCEL)==IDOK)
     return(0);
    else
     return(1);
}

int getKey_via_dialog(void )            /* ask for Key */
{
/*
  PFEMainForm->EditMemo->Enabled=false;
  GetKey=new TGetKey(PFEMainForm);
  GetKey->Left=PFEMainForm->Left;  // Position modal Form Dialog over Line Editor
  GetKey->Top=PFEMainForm->Top+PFEMainForm->EditMemo->Top;
  int Key=GetKey->ShowModal();
  PFEMainForm->EditMemo->Enabled=true;
  delete GetKey;
  return( Key );
*/
   MSG  msg;
   msg.message=WM_PAINT;
   msg.hwnd=PFEMainForm->Handle;
   int Key;
   while ((msg.message!=WM_KEYDOWN)&&(msg.message!=WM_CHAR))
   {
     GetMessage(&msg,NULL,0,0);
     TranslateMessage(&msg);
     if (msg.message==WM_CHAR)
       {
         Key=(int)msg.wParam;
       }
       else
         if (msg.message==WM_KEYDOWN)
          {
             Key=(int)msg.wParam;
             switch (Key)
             {
             case VK_F1: { Key=EKEY_k1; } ; break ;
             case VK_F2: { Key=EKEY_k2; } ; break ;
             case VK_F3: { Key=EKEY_k3; } ; break ;
             case VK_F4: { Key=EKEY_k4; } ; break ;
             case VK_F5: { Key=EKEY_k5; } ; break ;
             case VK_F6: { Key=EKEY_k6; } ; break ;
             case VK_F7: { Key=EKEY_k7; } ; break ;
             case VK_F8: { Key=EKEY_k8; } ; break ;
             case VK_F9: { Key=EKEY_k9; } ; break ;
             case VK_F10: { Key=EKEY_k0; } ; break ;

             case VK_LEFT :{ Key=EKEY_kl; } ; break ; /* arrow key left */
             case VK_RIGHT:{ Key=EKEY_kr; } ; break ; /* arrow key right */
             case VK_UP   :{ Key=EKEY_ku; } ; break ; /* arrow key up */
             case VK_DOWN :{ Key=EKEY_kd; } ; break ; /* arrow key down */

             case VK_HOME :{ Key=EKEY_kh; } ; break ; /* home key */
             case VK_END  :{ Key=EKEY_kH; } ; break ; /* home down key */
             case VK_NEXT :{ Key=EKEY_kN; } ; break ; /* next page key */
             case VK_PRIOR :{ Key=EKEY_kP; } ; break ; /* previous page key */

             case VK_BACK :{ Key=EKEY_kb; } ; break ; /* backspace key */
             case VK_DELETE :{ Key=EKEY_kD; } ; break ; /* delete character key */
             // case VK_INSERT :{ Key=  EKEY_kM			/* exit insert mode key */
             case VK_INSERT :{ Key=EKEY_kI; } ; break ; /* insert character key */

             // case VK_DOWN :{ Key=  EKEY_kA			/* insert line key */
             // case VK_END :{ Key=  EKEY_kE;} ; break ; /* clear to end of line key */
             // case VK_DOWN :{ Key=  EKEY_kL			/* delete line key */
             // case VK_DOWN :{ Key=  EKEY_kC			/* clear screen key */
            }
          }
             else
                DispatchMessage(&msg);

   }
   return(Key);
}

int
WIN_edit_aCcept (char *p, int n)
             /* better input facility using Edit Object of C++Builder */
{
 if (PFEMainForm!=NULL)
 {
  strcpy(p,PFEMainForm->EditMemo->Lines->Strings[0].c_str());
  int ret_val =PFEMainForm->EditMemo->Lines->Strings[0].Length();
  PFEMainForm->EditMemo->Lines->Strings[0]="";
  return ret_val;
 }
 else
 { return aCcept (p,n);         /* better input facility using lined() */ }
}


//---------------------------------------------------------------------------
void __fastcall TPFEMainForm::StartForthTimerTimer(TObject *Sender)
{
  StartForthTimer->Enabled=false;
  Cursor=crHourGlass;
  forthmain(Param_Count_value,argv);
  Cursor=crDefault;
  if (Visible)
   {
    FocusControl(EditMemo);
    query_forth();
   }   
}
//---------------------------------------------------------------------------
void __fastcall TPFEMainForm::Save1Click(TObject *Sender)
{
       TSaveDialog * SaveDialog= new TSaveDialog(this);
       SaveDialog->DefaultExt="txt";
       SaveDialog->Filter="ASCII Tracefile|*.txt";
       SaveDialog->Options << ofOverwritePrompt << ofHideReadOnly << ofShowHelp;

       if (SaveDialog->Execute())
       {
         ListBox1->Items->SaveToFile(SaveDialog->FileName);
       }
       delete SaveDialog;
}
//---------------------------------------------------------------------------
void __fastcall TPFEMainForm::Exit1Click(TObject *Sender)
{
  Close();
}
//---------------------------------------------------------------------------
void __fastcall TPFEMainForm::Status1Click(TObject *Sender)
{
 EditMemo->Lines->Strings[0]="SHOW-STATUS";
 ListBox1->Items->Add(EditMemo->Lines->Strings[0]);
 query_forth();
}
//---------------------------------------------------------------------------
void __fastcall TPFEMainForm::LoadDictionary1Click(TObject *Sender)
{
  OpenDictionary->FileName="C:\\PFE\\SRC\\*.ifb";
  if (OpenDictionary->Execute())
  {
   char sbuffer[255];
   sprintf(sbuffer,"-d%s",OpenDictionary->FileName.c_str());
   argv[1]=sbuffer;
   get_win_forth_options (Param_Count_value,argv);
   EditMemo->Lines->Strings[0]="COLD";
   query_forth();
  }
}
//---------------------------------------------------------------------------
void __fastcall TPFEMainForm::Find1Click(TObject *Sender)
{
  FindDialog1->Execute();
}
//---------------------------------------------------------------------------
void __fastcall TPFEMainForm::FindDialog1Find(TObject *Sender)
{

  if (ListBox1->Items->Count!=-1)
  {
    int i;
    Cursor=crHourGlass;
    if (ListBox1->ItemIndex==-1)
      i=0;
    else
      i=ListBox1->ItemIndex+1;

    while ((i<ListBox1->Items->Count)&&((UpperCase(ListBox1->Items->Strings[i])).Pos(UpperCase(FindDialog1->FindText))==0))
    {
      i++;
    }
    if ((i<ListBox1->Items->Count)&&((UpperCase(ListBox1->Items->Strings[i])).Pos(UpperCase(FindDialog1->FindText))!=0))
      ListBox1->ItemIndex=i;
    else
      {
       FindDialog1->CloseDialog();
      }
    ListBox1->Repaint();
    Cursor=crDefault;
  }
}
//---------------------------------------------------------------------------

void __fastcall TPFEMainForm::License1Click(TObject *Sender)
{
 EditMemo->Lines->Strings[0]="LICENSE";
 ListBox1->Items->Add(EditMemo->Lines->Strings[0]);
 query_forth();
}
//---------------------------------------------------------------------------

void __fastcall TPFEMainForm::EditMemoKeyPress(TObject *Sender, char &Key)
{
 if (Key==VK_TAB)
  {
     char sbuffer[255];
     int SelLineNumber=EditMemo->Perform(EM_LINEFROMCHAR, -1, 0);
     sprintf(sbuffer,"%s\0",EditMemo->Lines->Strings[SelLineNumber].c_str());
     code_completion(sbuffer,EditMemo->Lines->Strings[SelLineNumber].Length());
     EditMemo->Lines->Strings[SelLineNumber]=AnsiString(sbuffer);
     Key=0;
  }
 if (Key==VK_RETURN)
  {
   int SelLineNumber =   EditMemo->Perform(EM_LINEFROMCHAR, -1, 0);
   ListBox1->Items->Add(EditMemo->Lines->Strings[SelLineNumber]);
   EditMemo->Lines->Insert(0,ListBox1->Items->Strings[ListBox1->Items->Count-1]);
   query_forth();
   Key=0;
  }
}
//---------------------------------------------------------------------------
void myShellexecute(char *fname)
{
    int re = (int)ShellExecute(Application->Handle, "open", fname, NULL,NULL, SW_NORMAL);
/*
    switch (re)
    {
       case 0  : ShowMessage("The operating system is out of memory or resources.");break;
       case ERROR_FILE_NOT_FOUND : ShowMessage("The specified file was not found.");break;
       case ERROR_PATH_NOT_FOUND  : ShowMessage("The specified path was not found.");break;
       case ERROR_BAD_FORMAT	: ShowMessage("The .EXE file is invalid (non-Win32 .EXE or error in .EXE image).");break;
       case SE_ERR_ASSOCINCOMPLETE : ShowMessage(" The filename association is incomplete or invalid.");break;
       case SE_ERR_DDEBUSY : ShowMessage("The DDE transaction could not be completed because other DDE transactions were being processed.");break;
       case SE_ERR_DDEFAIL : ShowMessage("The DDE transaction failed.");break;
       case SE_ERR_DDETIMEOUT : ShowMessage("The DDE transaction could not be completed because the request timed out.");break;
       case SE_ERR_NOASSOC : ShowMessage("There is no application associated with the given filename extension.");break;
       case SE_ERR_SHARE : ShowMessage("A sharing violation occurred.");break;
    }
*/    
}
//---------------------------------------------------------------------------
void __fastcall TPFEMainForm::ANSIFORTH1Click(TObject *Sender)
{
   myShellexecute("c:\\forth\\html\\dpansf.htm");
}
//---------------------------------------------------------------------------
void __fastcall TPFEMainForm::PFE1Click(TObject *Sender)
{
  myShellexecute("c:\\pfe\\doc\\pfe_toc.html");
}
//---------------------------------------------------------------------------
