// precompiler input to load windows constants

// required predefined values
#define WINVER 0x0400
#define _WIN32
#define _M_IX86 300
#define _STDCALL_SUPPORTED

// optional to make the dll smaller
//#define WIN32_LEAN_AND_MEAN
//#define NOMCX			// Modem Configuration Extensions
//#define NOKANJI		// Kanji support stuff
//#define NOIME

#include <windows.h>

