/*******************************************************************
** w o r d s . c
** Forth Inspired Command Language
** ANS Forth CORE word-set written in C
** Author: John Sadler
** Created: 19 July 1997
** 
*******************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include "ficl.h"
#include "math64.h"

static void colonParen(FICL_VM *pVM);
static void literalIm(FICL_VM *pVM);
static void interpWord(FICL_VM *pVM, STRINGINFO si);

static char doTag[]    = "do";
static char ifTag[]    = "if";
static char colonTag[] = "colon";
static char leaveTag[] = "leave";
static char beginTag[] = "begin";
static char whileTag[] = "while";

static FICL_WORD *pDoParen      = NULL;
static FICL_WORD *pLoopParen    = NULL;
static FICL_WORD *pBranchParen  = NULL;
static FICL_WORD *pPLoopParen   = NULL;
static FICL_WORD *pExit         = NULL;
static FICL_WORD *pLitParen     = NULL;
static FICL_WORD *pIfParen      = NULL;
static FICL_WORD *pComma        = NULL;
static FICL_WORD *pStringLit    = NULL;
static FICL_WORD *pType         = NULL;
static FICL_WORD *pInterpret    = NULL;

/*
** Push current dict location for later branch resolution.
** The location may be either a branch target or a patch address...
*/
static void markBranch(FICL_DICT *dp, FICL_VM *pVM, char *tag)
{
    stackPushPtr(pVM->pStack, dp->here);
    stackPushPtr(pVM->pStack, tag);
    return;
}

static void markControlTag(FICL_VM *pVM, char *tag)
{
    stackPushPtr(pVM->pStack, tag);
    return;
}

static void matchControlTag(FICL_VM *pVM, char *tag)
{
    char *cp = (char *)stackPopPtr(pVM->pStack);
    if ( strcmp(cp, tag) )
    {
        vmTextOut(pVM, "Warning -- unmatched control word: ", 0);
        vmTextOut(pVM, tag, 1);
#if 0
        vmThrow(pVM, VM_ERREXIT);
#endif
    }

    return;
}

/*
** Expect a branch target address on the param stack,
** compile a literal offset from the current dict location
** to the target address
*/
static void resolveBackBranch(FICL_DICT *dp, FICL_VM *pVM, char *tag)
{
    long offset;
    CELL *patchAddr;

    matchControlTag(pVM, tag);

    patchAddr = (CELL *)stackPopPtr(pVM->pStack);
    offset = patchAddr - dp->here;
    dictAppendCell(dp, LVALUEtoCELL(offset));

    return;
}


/*
** Expect a branch patch address on the param stack,
** compile a literal offset from the patch location
** to the current dict location
*/
static void resolveForwardBranch(FICL_DICT *dp, FICL_VM *pVM, char *tag)
{
    long offset;
    CELL *patchAddr;

    matchControlTag(pVM, tag);

    patchAddr = (CELL *)stackPopPtr(pVM->pStack);
    offset = dp->here - patchAddr;
    *patchAddr = LVALUEtoCELL(offset);

    return;
}

/*
** Match the tag to the top of the stack. If success,
** sopy "here" address into the cell whose address is next
** on the stack. Used by do..leave..loop.
*/
static void resolveAbsBranch(FICL_DICT *dp, FICL_VM *pVM, char *tag)
{
    CELL *patchAddr;
    char *cp;

    cp = stackPopPtr(pVM->pStack);
    if (strcmp(cp, tag))
    {
        vmTextOut(pVM, "Warning -- Unmatched control word: ", 0);
        vmTextOut(pVM, tag, 1);
#if 0
        vmThrow(pVM, VM_ERREXIT);
#endif
    }

    patchAddr = (CELL *)stackPopPtr(pVM->pStack);
    *patchAddr = LVALUEtoCELL(dp->here);

    return;
}


/**************************************************************************
                        i s N u m b e r
** Attempts to convert the NULL terminated string in the VM's pad to 
** a number using the VM's current base. If successful, pushes the number
** onto the param stack and returns TRUE. Otherwise, returns FALSE.
**************************************************************************/

static int isNumber(FICL_VM *pVM, STRINGINFO si)
{
    INT32 accum     = 0;
    char isNeg      = FALSE;
    unsigned base   = pVM->base;
    char *cp        = SI_PTR(si);
    FICL_COUNT count= SI_COUNT(si);
    unsigned ch;
    unsigned digit;

    if (*cp == '-')
    {
        cp++;
        count--;
        isNeg = TRUE;
    }
    else if ((cp[0] == '0') && (cp[1] == 'x'))
    {               /* detect 0xNNNN format for hex numbers */
        cp += 2;
        count -= 2;
        base = 16;
    }

    if (count == 0)
        return FALSE;

    while (count-- && ((ch = *cp++) != '\0'))
    {
        if (ch < '0')
            return FALSE;

        digit = ch - '0';

        if (digit > 9)
            digit = tolower(ch) - 'a' + 10;
        /* 
        ** Note: following test also catches chars between 9 and a
        ** because 'digit' is unsigned!
        */
        if (digit >= base)
            return FALSE;

        accum = accum * base + digit;
    }

    if (isNeg)
		accum = -accum;

    stackPushINT32(pVM->pStack, accum);

    return TRUE;
}


/**************************************************************************
                        a d d   &   f r i e n d s
** 
**************************************************************************/

static void add(FICL_VM *pVM)
{
    INT32 i = stackPopINT32(pVM->pStack);
    i += stackGetTop(pVM->pStack).i;
    stackSetTop(pVM->pStack, LVALUEtoCELL(i));
    return;
}

static void sub(FICL_VM *pVM)
{
    INT32 i = stackPopINT32(pVM->pStack);
    i = stackGetTop(pVM->pStack).i - i;
    stackSetTop(pVM->pStack, LVALUEtoCELL(i));
    return;
}

static void mul(FICL_VM *pVM)
{
    INT32 i = stackPopINT32(pVM->pStack);
    i *= stackGetTop(pVM->pStack).i;
    stackSetTop(pVM->pStack, LVALUEtoCELL(i));
    return;
}

static void negate(FICL_VM *pVM)
{
    INT32 i = -stackPopINT32(pVM->pStack);
    stackPushINT32(pVM->pStack, i);
    return;
}

static void ficlDiv(FICL_VM *pVM)
{
    INT32 i = stackPopINT32(pVM->pStack);
    i = stackGetTop(pVM->pStack).i / i;
    stackSetTop(pVM->pStack, LVALUEtoCELL(i));
    return;
}

/*
** slash-mod        CORE ( n1 n2 -- n3 n4 )
** Divide n1 by n2, giving the single-cell remainder n3 and the single-cell
** quotient n4. An ambiguous condition exists if n2 is zero. If n1 and n2
** differ in sign, the implementation-defined result returned will be the
** same as that returned by either the phrase
** >R S>D R> FM/MOD or the phrase >R S>D R> SM/REM . 
** NOTE: Ficl complies with the second phrase (symmetric division)
*/
static void slashMod(FICL_VM *pVM)
{
    INT64 n1;
    INT32 n2;
    INTQR qr;

    n2    = stackPopINT32(pVM->pStack);
    n1.lo = stackPopINT32(pVM->pStack);
    i64Extend(n1);

    qr = m64SymmetricDivI(n1, n2);
    stackPushINT32(pVM->pStack, qr.rem);
    stackPushINT32(pVM->pStack, qr.quot);
    return;
}

static void onePlus(FICL_VM *pVM)
{
    INT32 i = stackGetTop(pVM->pStack).i;
    i += 1;
    stackSetTop(pVM->pStack, LVALUEtoCELL(i));
    return;
}

static void oneMinus(FICL_VM *pVM)
{
    INT32 i = stackGetTop(pVM->pStack).i;
    i -= 1;
    stackSetTop(pVM->pStack, LVALUEtoCELL(i));
    return;
}

static void twoMul(FICL_VM *pVM)
{
    INT32 i = stackGetTop(pVM->pStack).i;
    i *= 2;
    stackSetTop(pVM->pStack, LVALUEtoCELL(i));
    return;
}

static void twoDiv(FICL_VM *pVM)
{
    INT32 i = stackGetTop(pVM->pStack).i;
    i >>= 1;
    stackSetTop(pVM->pStack, LVALUEtoCELL(i));
    return;
}

static void mulDiv(FICL_VM *pVM)
{     
    INT32 z = stackPopINT32(pVM->pStack);
    INT32 y = stackPopINT32(pVM->pStack);
    INT32 x = stackPopINT32(pVM->pStack);
    INT64 prod;

    prod = m64MulI(x,y);
    x    = m64SymmetricDivI(prod, z).quot;

    stackPushINT32(pVM->pStack, x);
    return;
}


static void mulDivRem(FICL_VM *pVM)
{
    INT32 z = stackPopINT32(pVM->pStack);
    INT32 y = stackPopINT32(pVM->pStack);
    INT32 x = stackPopINT32(pVM->pStack);
    INT64 prod;
    INTQR qr;

    prod = m64MulI(x,y);
    qr   = m64SymmetricDivI(prod, z);

    stackPushINT32(pVM->pStack, qr.rem);
    stackPushINT32(pVM->pStack, qr.quot);
    return;
}


/**************************************************************************
                        
** 
**************************************************************************/

static void bye(FICL_VM *pVM)
{
    vmThrow(pVM, VM_USEREXIT);
    return;
}


/**************************************************************************
                        c o l o n   d e f i n i t i o n s
** Code to begin compiling a colon definition
** This function sets the state to COMPILE, then creates a
** new word whose name is the next word in the input stream
** and whose code is colonParen.
**************************************************************************/

static void colon(FICL_VM *pVM)
{
    FICL_DICT *dp = ficlGetDict();
    STRINGINFO si;

    si = vmGetWord(pVM);
    if (SI_COUNT(si) == 0)
    {
        vmThrow(pVM, VM_RESTART);
    }

    pVM->state = COMPILE;
    markControlTag(pVM, colonTag);
    dictAppendWord2(dp, si, colonParen, FW_DEFAULT | FW_SMUDGE);
    return;
}


/**************************************************************************
                        c o l o n P a r e n
** This is the code that executes a colon definition. It assumes that the
** virtual machine is running a "next" loop (See the vm.c
** for its implementation of member function vmExecute()). The colon
** code simply copies the address of the first word in the list of words
** to interpret into IP after saving its old value. When we return to the
** "next" loop, the virtual machine will call the code for each word in 
** turn.
**
**************************************************************************/
       
static void colonParen(FICL_VM *pVM)
{
    IPTYPE tempIP = (IPTYPE) (pVM->runningWord->param);
    vmPushIP(pVM, tempIP);

    return;
}


/**************************************************************************
                        s e m i c o l o n C o I m
** 
** IMMEDIATE code for ";". This function sets the state to INTERPRET and
** terminates a word under compilation by appending code for "(;)" to
** the definition. TO DO: checks for leftover branch target tags on the
** return stack and complains if any are found.
**************************************************************************/

static void semicolonCoIm(FICL_VM *pVM)
{
    FICL_DICT *dp = ficlGetDict();

    assert(pExit);

    matchControlTag(pVM, colonTag);
    dictAppendCell(dp, LVALUEtoCELL(pExit));
    pVM->state = INTERPRET;
    dictUnsmudge(dp);
    return;
}


/**************************************************************************
                        e x i t
** 
** This is always the last word in any "colon" definition. It
** is compiled by ';'. This function simply pops the previous instruction
** pointer and returns to the "next" loop.
**************************************************************************/

static void exitCo(FICL_VM *pVM)
{
    vmPopIP(pVM);
    return;
}


/**************************************************************************
                        c o n s t a n t P a r e n
** This is the run-time code for "constant". It simply returns the 
** contents of its word's first data cell.
**
**************************************************************************/

void constantParen(FICL_VM *pVM)
{
    FICL_WORD *fw = pVM->runningWord;
    stackPush(pVM->pStack, fw->param[0]);
    return;
}

void twoConstParen(FICL_VM *pVM)
{
    FICL_WORD *fw = pVM->runningWord;
    stackPush(pVM->pStack, fw->param[0]); /* lo */
    stackPush(pVM->pStack, fw->param[1]); /* hi */
    return;
}


/**************************************************************************
                        c o n s t a n t
** IMMEDIATE
** Compiles a constant into the dictionary. Constants return their
** value when invoked. Expects a value on top of the parm stack.
**************************************************************************/

static void constant(FICL_VM *pVM)
{
    FICL_DICT *dp = ficlGetDict();
    STRINGINFO si = vmGetWord(pVM);

    if (SI_COUNT(si) == 0)
    {
        vmThrow(pVM, VM_RESTART);
    }

    dictAppendWord2(dp, si, constantParen, FW_DEFAULT);
    dictAppendCell(dp, stackPop(pVM->pStack));
    return;
}


/**************************************************************************
                        d i s p l a y C e l l
** Drop and print the contents of the cell at the top of the param
** stack
**************************************************************************/

static void displayCell(FICL_VM *pVM)
{
    CELL c = stackPop(pVM->pStack);
    ltoa((c).i, pVM->pad, pVM->base);
    strcat(pVM->pad, " ");
    vmTextOut(pVM, pVM->pad, 0);
    return;
}

static void uDot(FICL_VM *pVM)
{
    UNS32 u = stackPopUNS32(pVM->pStack);
    ultoa(u, pVM->pad, pVM->base);
    strcat(pVM->pad, " ");
    vmTextOut(pVM, pVM->pad, 0);
    return;
}


/**************************************************************************
                        d i s p l a y S t a c k
** Display the parameter stack (code for ".s")
**************************************************************************/

static void displayStack(FICL_VM *pVM)
{
    int d = stackDepth(pVM->pStack);
    int i;
    CELL *pCell;

    stackCheck(pVM->pStack, pVM, 0);

    if (d == 0)
        vmTextOut(pVM, "(Stack Empty)", 1);
    else
    {
        pCell = pVM->pStack->sp;
        for (i = 0; i < d; i++)
        {
            vmTextOut(pVM, ltoa((*--pCell).i, pVM->pad, pVM->base), 1);
        }
    }
}


/**************************************************************************
                        d u p   &   f r i e n d s
** 
**************************************************************************/

static void depth(FICL_VM *pVM)
{
    int i = stackDepth(pVM->pStack);
    stackPushINT32(pVM->pStack, i);
    return;
}


static void drop(FICL_VM *pVM)
{
    stackDrop(pVM->pStack, 1);
    return;
}


static void twoDrop(FICL_VM *pVM)
{
    stackDrop(pVM->pStack, 2);
    return;
}


static void dup(FICL_VM *pVM)
{
    stackPick(pVM->pStack, 0);
    return;
}


static void twoDup(FICL_VM *pVM)
{
    stackPick(pVM->pStack, 1);
    stackPick(pVM->pStack, 1);
    return;
}


static void over(FICL_VM *pVM)
{
    stackPick(pVM->pStack, 1);
    return;
}

static void twoOver(FICL_VM *pVM)
{
    stackPick(pVM->pStack, 3);
    stackPick(pVM->pStack, 3);
    return;
}


static void pick(FICL_VM *pVM)
{
    CELL c = stackPop(pVM->pStack);
    stackPick(pVM->pStack, c.i);
    return;
}


static void questionDup(FICL_VM *pVM)
{
    CELL c = stackGetTop(pVM->pStack);

    if (c.i != 0)
        stackPick(pVM->pStack, 0);

    return;
}


static void roll(FICL_VM *pVM)
{
    CELL c = stackPop(pVM->pStack);
    stackRoll(pVM->pStack, c.i);
    return;
}


static void rot(FICL_VM *pVM)
{
    stackRoll(pVM->pStack, 2);
    return;
}


static void swap(FICL_VM *pVM)
{
    stackRoll(pVM->pStack, 1);
    return;
}


static void twoSwap(FICL_VM *pVM)
{
    stackRoll(pVM->pStack, 3);
    stackRoll(pVM->pStack, 3);
    return;
}


/**************************************************************************
                        e m i t   &   f r i e n d s
** 
**************************************************************************/

static void emit(FICL_VM *pVM)
{
    int i = stackPopINT32(pVM->pStack);
    char *cp = pVM->pad;
    cp[0] = (char)i;
    cp[1] = '\0';
    vmTextOut(pVM, cp, 0);
    return;
}


static void cr(FICL_VM *pVM)
{
    vmTextOut(pVM, "", 1);
    return;
}


static void commentLine(FICL_VM *pVM)
{
    char *cp = vmGetInBuf(pVM);
    char ch;

    while (isprint(*cp++))
    {
        ;       /* belt and suspenders for pedantic compilers! */
    }

    ch = *cp;
    /*
    ** Cope with DOS or UNIX-style EOLs
    */
    if ((ch == '\r') || (ch == '\n'))
        cp++;

    if ( (ch != *cp) 
         && ((*cp == '\r') || (*cp == '\n')) )
        cp++;

    vmUpdateTib(pVM, cp);
    return;
}


/*
** paren CORE 
** Compilation: Perform the execution semantics given below.
** Execution: ( "ccc<paren>" -- )
** Parse ccc delimited by ) (right parenthesis). ( is an immediate word. 
** The number of characters in ccc may be zero to the number of characters
** in the parse area. 
** 
*/
static void commentHang(FICL_VM *pVM)
{
    char *cp = vmGetInBuf(pVM);

    while (*cp && (*cp  != ')'))
        cp++;

    if (*cp == ')')
        cp++;

    vmUpdateTib(pVM, cp);
    return;
}


/**************************************************************************
                        F E T C H   &   S T O R E
** 
**************************************************************************/

static void fetch(FICL_VM *pVM)
{
    CELL *pCell = (CELL *)stackPopPtr(pVM->pStack);
    stackPush(pVM->pStack, *pCell);
    return;
}

/*
** two-fetch    CORE ( a-addr -- x1 x2 )
** Fetch the cell pair x1 x2 stored at a-addr. x2 is stored at a-addr and
** x1 at the next consecutive cell. It is equivalent to the sequence
** DUP CELL+ @ SWAP @ . 
*/
static void twoFetch(FICL_VM *pVM)
{
    CELL *pCell = (CELL *)stackPopPtr(pVM->pStack);
    stackPush(pVM->pStack, *pCell++);
    stackPush(pVM->pStack, *pCell);
    swap(pVM);
    return;
}

/*
** store        CORE ( x a-addr -- )
** Store x at a-addr. 
*/
static void store(FICL_VM *pVM)
{
    CELL *pCell = (CELL *)stackPopPtr(pVM->pStack);
    *pCell = stackPop(pVM->pStack);
}

/*
** two-store    CORE ( x1 x2 a-addr -- )
** Store the cell pair x1 x2 at a-addr, with x2 at a-addr and x1 at the
** next consecutive cell. It is equivalent to the sequence
** SWAP OVER ! CELL+ ! . 
*/
static void twoStore(FICL_VM *pVM)
{
    CELL *pCell = (CELL *)stackPopPtr(pVM->pStack);
    *pCell++    = stackPop(pVM->pStack);
    *pCell      = stackPop(pVM->pStack);
}

static void plusStore(FICL_VM *pVM)
{
    CELL *pCell = (CELL *)stackPopPtr(pVM->pStack);
    pCell->i += stackPop(pVM->pStack).i;
}


static void wFetch(FICL_VM *pVM)
{
    UNS16 *pw = (UNS16 *)stackPopPtr(pVM->pStack);
    stackPushUNS32(pVM->pStack, (UNS32)*pw);
    return;
}

static void wStore(FICL_VM *pVM)
{
    UNS16 *pw = (UNS16 *)stackPopPtr(pVM->pStack);
    *pw = (UNS16)(stackPop(pVM->pStack).u);
}

static void cFetch(FICL_VM *pVM)
{
    UNS8 *pc = (UNS8 *)stackPopPtr(pVM->pStack);
    stackPushUNS32(pVM->pStack, (UNS32)*pc);
    return;
}

static void cStore(FICL_VM *pVM)
{
    UNS8 *pc = (UNS8 *)stackPopPtr(pVM->pStack);
    *pc = (UNS8)(stackPop(pVM->pStack).u);
}


/**************************************************************************
                        i f C o I m
** IMMEDIATE
** Compiles code for a conditional branch into the dictionary
** and pushes the branch patch address on the stack for later
** patching by ELSE or THEN/ENDIF. 
**************************************************************************/

static void ifCoIm(FICL_VM *pVM)
{
    FICL_DICT *dp = ficlGetDict();

    assert(pIfParen);

    dictAppendCell(dp, LVALUEtoCELL(pIfParen));
    markBranch(dp, pVM, ifTag);
    dictAppendUNS32(dp, 1);
    return;
}


/**************************************************************************
                        i f P a r e n
** Runtime code to do "if" or "until": pop a flag from the stack,
** fall through if true, branch if false. Probably ought to be 
** called (not?branch) since it does "branch if false".
**************************************************************************/

static void ifParen(FICL_VM *pVM)
{
    UNS32 flag = stackPopUNS32(pVM->pStack);

    if (flag) 
    {                           /* fall through */
        vmBranchRelative(pVM, 1);
    }
    else 
    {                           /* take branch (to else/endif/begin) */
        vmBranchRelative(pVM, (int)(*pVM->ip));
    }

    return;
}


/**************************************************************************
                        e l s e C o I m
** 
** IMMEDIATE -- compiles an "else"...
** 1) Compile a branch and a patch address; the address gets patched
**    by "endif" to point past the "else" code.
** 2) Pop the the "if" patch address
** 3) Patch the "if" branch to point to the current compile address.
** 4) Push the "else" patch address. ("endif" patches this to jump past 
**    the "else" code.
**************************************************************************/

static void elseCoIm(FICL_VM *pVM)
{
    CELL *patchAddr;
    int offset;
    FICL_DICT *dp = ficlGetDict();

    assert(pBranchParen);
                                            /* (1) compile branch runtime */
    dictAppendCell(dp, LVALUEtoCELL(pBranchParen));
    matchControlTag(pVM, ifTag);
    patchAddr = 
        (CELL *)stackPopPtr(pVM->pStack);   /* (2) pop "if" patch addr */
    markBranch(dp, pVM, ifTag);             /* (4) push "else" patch addr */
    dictAppendUNS32(dp, 1);                 /* (1) compile patch placeholder */
    offset = dp->here - patchAddr;
    *patchAddr = LVALUEtoCELL(offset);      /* (3) Patch "if" */

    return;
}


/**************************************************************************
                        b r a n c h P a r e n
** 
** Runtime for "(branch)" -- expects a literal offset in the next
** compilation address, and branches to that location.
**************************************************************************/

static void branchParen(FICL_VM *pVM)
{
    vmBranchRelative(pVM, *(int *)(pVM->ip));
    return;
}


/**************************************************************************
                        e n d i f C o I m
** 
**************************************************************************/

static void endifCoIm(FICL_VM *pVM)
{
    FICL_DICT *dp = ficlGetDict();
    resolveForwardBranch(dp, pVM, ifTag);
    return;
}


/**************************************************************************
                        i n t e r p r e t 
** This is the "user interface" of a Forth. It does the following:
**   while there are words in the VM's Text Input Buffer
**     Copy next word into the pad (vmGetWord)
**     Attempt to find the word in the dictionary (dictLookup)
**     If successful, execute the word.
**     Otherwise, attempt to convert the word to a number (isNumber)
**     If successful, push the number onto the parameter stack.
**     Otherwise, print an error message and exit loop...
**   End Loop
**************************************************************************/

static void interpret(FICL_VM *pVM)
{
    STRINGINFO si = vmGetWord(pVM);
    assert(pVM);

#if FICL_ROBUST
    stackCheck(pVM->pStack, pVM, 0);
    stackCheck(pVM->rStack, pVM, 0);
#endif

    vmBranchRelative(pVM, -1);
    /*
    // Get next word...if out of text, we're done.
    */
    if (si.count == 0)
    {
        vmThrow(pVM, VM_OUTOFTEXT);
    }

    interpWord(pVM, si);


    return;                 /* back to inner interpreter */
}

/**************************************************************************
** From the standard, section 3.4
** b) Search the dictionary name space (see 3.4.2). If a definition name
** matching the string is found: 
**  1.if interpreting, perform the interpretation semantics of the definition
**  (see 3.4.3.2), and continue at a); 
**  2.if compiling, perform the compilation semantics of the definition
**  (see 3.4.3.3), and continue at a). 
**
** c) If a definition name matching the string is not found, attempt to
** convert the string to a number (see 3.4.1.3). If successful: 
**  1.if interpreting, place the number on the data stack, and continue at a); 
**  2.if compiling, compile code that when executed will place the number on
**  the stack (see 6.1.1780 LITERAL), and continue at a); 
**
** d) If unsuccessful, an ambiguous condition exists (see 3.4.4). 
**************************************************************************/
static void interpWord(FICL_VM *pVM, STRINGINFO si)
{
    FICL_DICT *dp = ficlGetDict();
    FICL_WORD *tempFW = dictLookup(dp, SI_PTR(si), SI_COUNT(si));

#if FICL_ROBUST
    dictCheck(dp, pVM, 0);
#endif

    if (pVM->state == INTERPRET)
    {
        if (tempFW != NULL)
        {
            if (wordIsCompileOnly(tempFW))
            {
                vmTextOut(pVM, "Error: Compile only!", 1);
                vmThrow(pVM, VM_ERREXIT);
            }

            vmExecute(pVM, tempFW);
        }

        else if (!isNumber(pVM, si))
        {
            int i = SI_COUNT(si);
            sprintf(pVM->pad, "%.*s not found", i, SI_PTR(si));
            vmTextOut(pVM, pVM->pad, 1);
            vmThrow(pVM, VM_ERREXIT);
        }
    }

    else /* (pVM->state == COMPILE) */
    {
        if (tempFW != NULL)
        {
            if (wordIsImmediate(tempFW))
            {
                vmExecute(pVM, tempFW);
            }
            else
            {
                dictAppendCell(dp, LVALUEtoCELL(tempFW));
            }
        }
        else if (isNumber(pVM, si))
        {
            literalIm(pVM);
        }
        else
        {
            int i = SI_COUNT(si);
            sprintf(pVM->pad, "%.*s not found", i, SI_PTR(si));
            vmTextOut(pVM, pVM->pad, 1);
            vmThrow(pVM, VM_ERREXIT);
        }
    }

    return;
}


/**************************************************************************
                        l i t e r a l P a r e n
** 
** This is the runtime for (literal). It assumes that it is part of a colon
** definition, and that the next CELL contains a value to be pushed on the
** parameter stack at runtime. This code is compiled by "literal".
**
**************************************************************************/

static void literalParen(FICL_VM *pVM)
{
    stackPushINT32(pVM->pStack, *(INT32 *)(pVM->ip));
    vmBranchRelative(pVM, 1);
    return;
}


/**************************************************************************
                        l i t e r a l I m
** 
** IMMEDIATE code for "literal". This function gets a value from the stack 
** and compiles it into the dictionary preceded by the code for "(literal)".
** IMMEDIATE
**************************************************************************/

static void literalIm(FICL_VM *pVM)
{
    FICL_DICT *dp = ficlGetDict();
    assert(pLitParen);

    dictAppendCell(dp, LVALUEtoCELL(pLitParen));
    dictAppendCell(dp, stackPop(pVM->pStack));

    return;
}


/**************************************************************************
                        l i s t W o r d s
** 
**************************************************************************/
#define nCOLWIDTH 8
static void listWords(FICL_VM *pVM)
{
    FICL_DICT *dp = ficlGetDict();
    FICL_WORD *wp;
    int nChars = 0;
    int len;
    int i;
    int nWords = 0;
    char *cp;
    char *pPad = pVM->pad;

    for (i = 0; i < HASHSIZE; i++)
    {
        for (wp = dp->hashTbl[i]; wp != NULL; wp = wp->link, nWords++)
        {
            cp = wp->name;
            nChars += sprintf(pPad + nChars, "%s", cp);

            if (nChars > 70)
            {
                pPad[nChars] = '\0';
                nChars = 0;
                vmTextOut(pVM, pPad, 1);
            }
            else
            {
                len = nCOLWIDTH - nChars % nCOLWIDTH;
                while (len-- > 0)
                    pPad[nChars++] = ' ';
            }

            if (nChars > 70)
            {
                pPad[nChars] = '\0';
                nChars = 0;
                vmTextOut(pVM, pPad, 1);
            }
        }
    }

    sprintf(pVM->pad, "Dictionary: %d words, %ld cells used of %lu total", 
        nWords, dp->here - dp->dict, dp->size);
    vmTextOut(pVM, pVM->pad, 1);
    return;
}


/**************************************************************************
                        l o g i c   a n d   c o m p a r i s o n s
** 
**************************************************************************/

static void zeroEquals(FICL_VM *pVM)
{
    CELL c;
    c.i = FICL_BOOL(stackPopINT32(pVM->pStack) == 0);
    stackPush(pVM->pStack, c);
    return;
}

static void zeroLess(FICL_VM *pVM)
{
    CELL c;
    c.i = FICL_BOOL(stackPopINT32(pVM->pStack) < 0);
    stackPush(pVM->pStack, c);
    return;
}

static void zeroGreater(FICL_VM *pVM)
{
    CELL c;
    c.i = FICL_BOOL(stackPopINT32(pVM->pStack) > 0);
    stackPush(pVM->pStack, c);
    return;
}

static void isEqual(FICL_VM *pVM)
{
    CELL x = stackPop(pVM->pStack);
    CELL y = stackPop(pVM->pStack);
    stackPushINT32(pVM->pStack, FICL_BOOL(x.i == y.i));
    return;
}

static void isLess(FICL_VM *pVM)
{
    CELL y = stackPop(pVM->pStack);
    CELL x = stackPop(pVM->pStack);
    stackPushINT32(pVM->pStack, FICL_BOOL(x.i < y.i));
    return;
}

static void uIsLess(FICL_VM *pVM)
{
    UNS32 u2 = stackPopUNS32(pVM->pStack);
    UNS32 u1 = stackPopUNS32(pVM->pStack);
    stackPushINT32(pVM->pStack, FICL_BOOL(u1 < u2));
    return;
}

static void isGreater(FICL_VM *pVM)
{
    CELL y = stackPop(pVM->pStack);
    CELL x = stackPop(pVM->pStack);
    stackPushINT32(pVM->pStack, FICL_BOOL(x.i > y.i));
    return;
}

static void bitwiseAnd(FICL_VM *pVM)
{
    CELL x = stackPop(pVM->pStack);
    CELL y = stackPop(pVM->pStack);
    stackPushINT32(pVM->pStack, x.i & y.i);
    return;
}

static void bitwiseOr(FICL_VM *pVM)
{
    CELL x = stackPop(pVM->pStack);
    CELL y = stackPop(pVM->pStack);
    stackPushINT32(pVM->pStack, x.i | y.i);
    return;
}

static void bitwiseXor(FICL_VM *pVM)
{
    CELL x = stackPop(pVM->pStack);
    CELL y = stackPop(pVM->pStack);
    stackPushINT32(pVM->pStack, x.i ^ y.i);
    return;
}

static void bitwiseNot(FICL_VM *pVM)
{
    CELL x = stackPop(pVM->pStack);
    stackPushINT32(pVM->pStack, ~x.i);
    return;
}


/**************************************************************************
                               D o  /  L o o p
** do -- IMMEDIATE COMPILE ONLY
**    Compiles code to initialize a loop: compile (do), 
**    allot space to hold the "leave" address, push a branch
**    target address for the loop.
** (do) -- runtime for "do"
**    pops index and limit from the p stack and moves them
**    to the r stack, then skips to the loop body.
** loop -- IMMEDIATE COMPILE ONLY
** +loop
**    Compiles code for the test part of a loop:
**    compile (loop), resolve forward branch from "do", and
**    copy "here" address to the "leave" address allotted by "do"
** i,j,k -- COMPILE ONLY
**    Runtime: Push loop indices on param stack (i is innermost loop...)
**    Note: each loop has three values on the return stack:
**    ( R: leave limit index )
**    "leave" is the absolute address of the next cell after the loop
**    limit and index are the loop control variables.
** leave -- COMPILE ONLY
**    Runtime: pop the loop control variables, then pop the
**    "leave" address and jump (absolute) there.
**************************************************************************/

static void doCoIm(FICL_VM *pVM)
{
    FICL_DICT *dp = ficlGetDict();

    assert(pDoParen);

    dictAppendCell(dp, LVALUEtoCELL(pDoParen));
    /*
    ** Allot space for a pointer to the end
    ** of the loop - "leave" uses this...
    */
    markBranch(dp, pVM, leaveTag);
    dictAppendUNS32(dp, 0);
    /*
    ** Mark location of head of loop...
    */
    markBranch(dp, pVM, doTag);

    return;
}


static void doParen(FICL_VM *pVM)
{
    CELL index = stackPop(pVM->pStack);
    CELL limit = stackPop(pVM->pStack);

    /* copy "leave" target addr to stack */
    stackPushPtr(pVM->rStack, *(pVM->ip++));
    stackPush(pVM->rStack, limit);
    stackPush(pVM->rStack, index);

    return;
}

/*
** Runtime code to break out of a do..loop construct
** Drop the loop control variables; the branch address
** past "loop" is next on the return stack.
*/
static void leaveCo(FICL_VM *pVM)
{
    /* almost unloop */
    stackDrop(pVM->rStack, 2);
    /* exit */
    vmPopIP(pVM);
    return;
}


static void unloopCo(FICL_VM *pVM)
{
    stackDrop(pVM->rStack, 3);
    return;
}


static void loopCoIm(FICL_VM *pVM)
{
    FICL_DICT *dp = ficlGetDict();

    assert(pLoopParen);

    dictAppendCell(dp, LVALUEtoCELL(pLoopParen));
    resolveBackBranch(dp, pVM, doTag);
    resolveAbsBranch(dp, pVM, leaveTag);
    return;
}


static void plusLoopCoIm(FICL_VM *pVM)
{
    FICL_DICT *dp = ficlGetDict();

    assert(pPLoopParen);

    dictAppendCell(dp, LVALUEtoCELL(pPLoopParen));
    resolveBackBranch(dp, pVM, doTag);
    resolveAbsBranch(dp, pVM, leaveTag);
    return;
}


static void loopParen(FICL_VM *pVM)
{
    INT32 index = stackGetTop(pVM->rStack).i;
    INT32 limit = stackFetch(pVM->rStack, 1).i;

    index++;

    if (index >= limit) 
    {
        stackDrop(pVM->rStack, 3); /* nuke the loop indices & "leave" addr */
        vmBranchRelative(pVM, 1);  /* fall through the loop */
    }
    else 
    {                       /* update index, branch to loop head */
        stackSetTop(pVM->rStack, LVALUEtoCELL(index));
        vmBranchRelative(pVM, *(int *)(pVM->ip));
    }

    return;
}


static void plusLoopParen(FICL_VM *pVM)
{
    INT32 index = stackGetTop(pVM->rStack).i;
    INT32 limit = stackFetch(pVM->rStack, 1).i;
    INT32 increment = stackPop(pVM->pStack).i;
    int flag;

    index += increment;

    if (increment < 0)
        flag = (index < limit);
    else
        flag = (index >= limit);

    if (flag) 
    {
        stackDrop(pVM->rStack, 3); /* nuke the loop indices & "leave" addr */
        vmBranchRelative(pVM, 1);  /* fall through the loop */
    }
    else 
    {                       /* update index, branch to loop head */
        stackSetTop(pVM->rStack, LVALUEtoCELL(index));
        vmBranchRelative(pVM, *(int *)(pVM->ip));
    }

    return;
}


static void loopICo(FICL_VM *pVM)
{
    CELL index = stackGetTop(pVM->rStack);
    stackPush(pVM->pStack, index);

    return;
}


static void loopJCo(FICL_VM *pVM)
{
    CELL index = stackFetch(pVM->rStack, 3);
    stackPush(pVM->pStack, index);

    return;
}


static void loopKCo(FICL_VM *pVM)
{
    CELL index = stackFetch(pVM->rStack, 6);
    stackPush(pVM->pStack, index);

    return;
}


/**************************************************************************
                        r e t u r n   s t a c k
** 
**************************************************************************/

static void toRStack(FICL_VM *pVM)
{
    stackPush(pVM->rStack, stackPop(pVM->pStack));
    return;
}

static void fromRStack(FICL_VM *pVM)
{
    stackPush(pVM->pStack, stackPop(pVM->rStack));
    return;
}

static void fetchRStack(FICL_VM *pVM)
{
    stackPush(pVM->pStack, stackGetTop(pVM->rStack));
    return;
}


/**************************************************************************
                        v a r i a b l e
** 
**************************************************************************/

static void variableParen(FICL_VM *pVM)
{
    FICL_WORD *fw = pVM->runningWord;
    stackPushPtr(pVM->pStack, fw->param);
    return;
}


static void variable(FICL_VM *pVM)
{
    FICL_DICT *dp = ficlGetDict();
    STRINGINFO si = vmGetWord(pVM);

    if (SI_COUNT(si) == 0)
    {
        vmThrow(pVM, VM_RESTART);
    }

    dictAppendWord2(dp, si, variableParen, FW_DEFAULT);
    dictAllotCells(dp, 1);
    return;
}



/**************************************************************************
                        b a s e   &   f r i e n d s
** 
**************************************************************************/

static void base(FICL_VM *pVM)
{
    CELL *pBase = (CELL *)(&pVM->base);
    stackPush(pVM->pStack, LVALUEtoCELL(pBase));
    return;
}


static void decimal(FICL_VM *pVM)
{
    pVM->base = 10;
    return;
}


static void hex(FICL_VM *pVM)
{
    pVM->base = 16;
    return;
}


/**************************************************************************
                        a l l o t   &   f r i e n d s
** 
**************************************************************************/

static void allot(FICL_VM *pVM)
{
    FICL_DICT *dp = ficlGetDict();
    INT32 i = stackPopINT32(pVM->pStack);
#if FICL_ROBUST
    dictCheck(dp, pVM, i);
#endif
    dictAllot(dp, i);
    return;
}


static void here(FICL_VM *pVM)
{
    FICL_DICT *dp = ficlGetDict();
    stackPushPtr(pVM->pStack, dp->here);
    return;
}


static void comma(FICL_VM *pVM)
{
    FICL_DICT *dp = ficlGetDict();
    CELL c = stackPop(pVM->pStack);
    dictAppendCell(dp, c);
    return;
}


static void cComma(FICL_VM *pVM)
{
    FICL_DICT *dp = ficlGetDict();
    char c = (char)stackPopINT32(pVM->pStack);
    dictAppendChar(dp, c);
    return;
}


static void cells(FICL_VM *pVM)
{
    INT32 i = stackPopINT32(pVM->pStack);
    stackPushINT32(pVM->pStack, i * (INT32)sizeof (CELL));
    return;
}


static void cellPlus(FICL_VM *pVM)
{
    char *cp = stackPopPtr(pVM->pStack);
    stackPushPtr(pVM->pStack, cp + sizeof (CELL));
    return;
}


/**************************************************************************
                        t i c k
** tick         CORE ( "<spaces>name" -- xt )
** Skip leading space delimiters. Parse name delimited by a space. Find
** name and return xt, the execution token for name. An ambiguous condition
** exists if name is not found. 
**************************************************************************/
static void tick(FICL_VM *pVM)
{
    FICL_WORD *pFW = NULL;
    STRINGINFO si = vmGetWord(pVM);

    if (SI_COUNT(si) == 0)
    {
        vmThrow(pVM, VM_RESTART);
    }
    
    pFW = dictLookup(ficlGetDict(), SI_PTR(si), SI_COUNT(si));
    if (!pFW)
    {
        int i = SI_COUNT(si);
        sprintf(pVM->pad, "%.*s not found", i, SI_PTR(si));
        vmTextOut(pVM, pVM->pad, 1);
        vmThrow(pVM, VM_ERREXIT);
    }
    stackPushPtr(pVM->pStack, pFW);
    return;
}


static void bracketTickCoIm(FICL_VM *pVM)
{
    tick(pVM);
    literalIm(pVM);
    
    return;
}


/**************************************************************************
                        p o s t p o n e
** Lookup the next word in the input stream and compile code to 
** insert it into definitions created by the resulting word
** (defers compilation, even of immediate words)
**************************************************************************/

static void postponeCoIm(FICL_VM *pVM)
{
    FICL_DICT *dp  = ficlGetDict();
    FICL_WORD *pFW;
    assert(pComma);

    tick(pVM);
    pFW = stackGetTop(pVM->pStack).p;
    if (wordIsImmediate(pFW))
    {
        dictAppendCell(dp, stackPop(pVM->pStack));
    }
    else
    {
        literalIm(pVM);
        dictAppendCell(dp, LVALUEtoCELL(pComma));
    }
    
    return;
}



/**************************************************************************
                        e x e c u t e
** Pop an execution token (pointer to a word) off the stack and
** run it
**************************************************************************/

static void execute(FICL_VM *pVM)
{
    FICL_WORD *pFW = stackPopPtr(pVM->pStack);
    vmExecute(pVM, pFW);

    return;
}


/**************************************************************************
                        i m m e d i a t e
** Make the most recently compiled word IMMEDIATE -- it executes even
** in compile state (most often used for control compiling words
** such as IF, THEN, etc)
**************************************************************************/

static void immediate(FICL_VM *pVM)
{
    IGNORE(pVM);
    dictSetImmediate(ficlGetDict());

    return;
}


/**************************************************************************
                        d o t Q u o t e
** IMMEDIATE word that compiles a string literal for later display
** Compile stringLit, then copy the bytes of the string from the TIB
** to the dictionary. Backpatch the count byte and align the dictionary.
**
** stringlit: Fetch the count from the dictionary, then push the address
** and count on the stack. Finally, update ip to point to the first
** aligned address after the string text.
**************************************************************************/

static void stringLit(FICL_VM *pVM)
{
    FICL_STRING *sp = (FICL_STRING *)(pVM->ip);
    FICL_COUNT count = sp->count;
    char *cp = sp->text;
    stackPushPtr(pVM->pStack, cp);
    stackPushUNS32(pVM->pStack, count);
    cp += count + 1;
    cp = alignPtr(cp);
    pVM->ip = (IPTYPE)(void *)cp;
    return;
}

static void dotQuoteCoIm(FICL_VM *pVM)
{
    FICL_DICT *dp = ficlGetDict();
    dictAppendCell(dp, LVALUEtoCELL(pStringLit));
    dp->here = PTRtoCELL vmGetString(pVM, (FICL_STRING *)dp->here, '\"');
    dictAlign(dp);
    dictAppendCell(dp, LVALUEtoCELL(pType));
    return;
}


static void dotParen(FICL_VM *pVM)
{
    char *pSrc  = vmGetInBuf(pVM);
    char *pDest = pVM->pad;
    char ch;

    pSrc = skipSpace(pSrc);

    for (ch = *pSrc; (ch != '\0') && (ch != ')'); ch = *++pSrc)
        *pDest++ = ch;

    *pDest = '\0';
    if (ch == ')')
        pSrc++;

    vmTextOut(pVM, pVM->pad, 0);
    vmUpdateTib(pVM, pSrc);
        
    return;
}


/**************************************************************************
                        s t a t e
** Return the address of the VM's state member (must be sized the
* same as a CELL for this reason)
**************************************************************************/

static void state(FICL_VM *pVM)
{
    stackPushPtr(pVM->pStack, &pVM->state);
    return;
}


/**************************************************************************
                        c r e a t e . . . d o e s >
** Make a new word in the dictionary with the run-time effect of 
** a variable (push my address), but with extra space allotted
** for use by does> .
**************************************************************************/

static void createParen(FICL_VM *pVM)
{
    CELL *pCell = pVM->runningWord->param;
    stackPushPtr(pVM->pStack, pCell+1);
    return;
}


static void create(FICL_VM *pVM)
{
    FICL_DICT *dp = ficlGetDict();
    STRINGINFO si = vmGetWord(pVM);

    if (SI_COUNT(si) == 0)
    {
        vmThrow(pVM, VM_RESTART);
    }

    dictAppendWord2(dp, si, createParen, FW_DEFAULT);
    dictAllotCells(dp, 1);
    return;
}


static void doesParen(FICL_VM *pVM)
{
    CELL *pCell = pVM->runningWord->param;
    IPTYPE tempIP = (IPTYPE)((*pCell).p);
    stackPushPtr(pVM->pStack, pCell+1);
    vmPushIP(pVM, tempIP);
    return;
}


static void doesCo(FICL_VM *pVM)
{
    FICL_DICT *dp = ficlGetDict();
    dp->smudge->code = doesParen;
    dp->smudge->param[0] = LVALUEtoCELL(pVM->ip);
    vmPopIP(pVM);
    return;
}


/**************************************************************************
                        t o   b o d y
** to-body      CORE ( xt -- a-addr )
** a-addr is the data-field address corresponding to xt. An ambiguous
** condition exists if xt is not for a word defined via CREATE. 
**************************************************************************/
static void toBody(FICL_VM *pVM)
{
    FICL_WORD *pFW = stackPopPtr(pVM->pStack);
    stackPushPtr(pVM->pStack, pFW->param + 1);
    return;
}


/**************************************************************************
                        l b r a c k e t   e t c
** 
**************************************************************************/

static void lbracketCoIm(FICL_VM *pVM)
{
    pVM->state = INTERPRET;
    return;
}


static void rbracket(FICL_VM *pVM)
{
    pVM->state = COMPILE;
    return;
}


/**************************************************************************
                        p i c t u r e d   n u m e r i c   w o r d s
**
** less-number-sign CORE ( -- )
** Initialize the pictured numeric output conversion process. 
** (clear the pad)
**************************************************************************/
static void lessNumberSign(FICL_VM *pVM)
{
    FICL_STRING *sp = PTRtoSTRING pVM->pad;
    sp->count = 0;
    return;
}

/*
** number-sign      CORE ( ud1 -- ud2 )
** Divide ud1 by the number in BASE giving the quotient ud2 and the remainder
** n. (n is the least-significant digit of ud1.) Convert n to external form
** and add the resulting character to the beginning of the pictured numeric
** output  string. An ambiguous condition exists if # executes outside of a
** <# #> delimited number conversion. 
*/
static void numberSign(FICL_VM *pVM)
{
    FICL_STRING *sp = PTRtoSTRING pVM->pad;
    UNS64 u;
    UNS16 rem;
    
    u   = u64Pop(pVM->pStack);
    rem = m64UMod(&u, (UNS16)(pVM->base));
    sp->text[sp->count++] = digit_to_char(rem);
    u64Push(pVM->pStack, u);
    return;
}

/*
** number-sign-greater CORE ( xd -- c-addr u )
** Drop xd. Make the pictured numeric output string available as a character
** string. c-addr and u specify the resulting character string. A program
** may replace characters within the string. 
*/
static void numberSignGreater(FICL_VM *pVM)
{
    FICL_STRING *sp = PTRtoSTRING pVM->pad;
    sp->text[sp->count] = '\0';
    strrev(sp->text);
    stackDrop(pVM->pStack, 2);
    stackPushPtr(pVM->pStack, sp->text);
    stackPushUNS32(pVM->pStack, sp->count);
    return;
}

/*
** number-sign-s    CORE ( ud1 -- ud2 )
** Convert one digit of ud1 according to the rule for #. Continue conversion
** until the quotient is zero. ud2 is zero. An ambiguous condition exists if
** #S executes outside of a <# #> delimited number conversion. 
** TO DO: presently does not use ud1 hi cell - use it!
*/
static void numberSignS(FICL_VM *pVM)
{
    FICL_STRING *sp = PTRtoSTRING pVM->pad;
    UNS64 u;
    UNS16 rem;

    u = u64Pop(pVM->pStack);

    do 
    {
        rem = m64UMod(&u, (UNS16)(pVM->base));
        sp->text[sp->count++] = digit_to_char(rem);
    } 
    while (u.hi || u.lo);

    u64Push(pVM->pStack, u);
    return;
}

/*
** HOLD             CORE ( char -- )
** Add char to the beginning of the pictured numeric output string. An ambiguous
** condition exists if HOLD executes outside of a <# #> delimited number conversion.
*/
static void hold(FICL_VM *pVM)
{
    FICL_STRING *sp = PTRtoSTRING pVM->pad;
    int i = stackPopINT32(pVM->pStack);
    sp->text[sp->count++] = (char) i;
    return;
}

/*
** SIGN             CORE ( n -- )
** If n is negative, add a minus sign to the beginning of the pictured
** numeric output string. An ambiguous condition exists if SIGN
** executes outside of a <# #> delimited number conversion. 
*/
static void sign(FICL_VM *pVM)
{
    FICL_STRING *sp = PTRtoSTRING pVM->pad;
    int i = stackPopINT32(pVM->pStack);
    if (i < 0)
        sp->text[sp->count++] = '-';
    return;
}


/**************************************************************************
                        t o   N u m b e r
** to-number CORE ( ud1 c-addr1 u1 -- ud2 c-addr2 u2 )
** ud2 is the unsigned result of converting the characters within the
** string specified by c-addr1 u1 into digits, using the number in BASE,
** and adding each into ud1 after multiplying ud1 by the number in BASE.
** Conversion continues left-to-right until a character that is not
** convertible, including any + or -, is encountered or the string is
** entirely converted. c-addr2 is the location of the first unconverted
** character or the first character past the end of the string if the string
** was entirely converted. u2 is the number of unconverted characters in the
** string. An ambiguous condition exists if ud2 overflows during the
** conversion. 
** TO DO: presently does not use ud1 hi cell - use it!
**************************************************************************/
static void toNumber(FICL_VM *pVM)
{
    UNS32 count     = stackPopUNS32(pVM->pStack);
    char *cp        = (char *)stackPopPtr(pVM->pStack);
    UNS64 accum;
    UNS32 base      = pVM->base;
    UNS32 ch;
    UNS32 digit;

    accum = u64Pop(pVM->pStack);

    for (ch = *cp; count > 0; ch = *++cp, count--)
    {
        if (ch < '0')
            break;

        digit = ch - '0';

        if (digit > 9)
            digit = tolower(ch) - 'a' + 10;
        /* 
        ** Note: following test also catches chars between 9 and a
        ** because 'digit' is unsigned! 
        */
        if (digit >= base)
            break;

        accum = m64Mac(accum, base, digit);
    }

    u64Push(pVM->pStack, accum);
    stackPushPtr  (pVM->pStack, cp);
    stackPushUNS32(pVM->pStack, count);

    return;
}



/**************************************************************************
                        q u i t   &   a b o r t
** 
**************************************************************************/

static void quit(FICL_VM *pVM)
{
    vmThrow(pVM, VM_QUIT);
    return;
}


static void ficlAbort(FICL_VM *pVM)
{
    vmThrow(pVM, VM_ERREXIT);
    return;
}


/**************************************************************************
                        a c c e p t
** accept       CORE ( c-addr +n1 -- +n2 )
** Receive a string of at most +n1 characters. An ambiguous condition
** exists if +n1 is zero or greater than 32,767. Display graphic characters
** as they are received. A program that depends on the presence or absence
** of non-graphic characters in the string has an environmental dependency.
** The editing functions, if any, that the system performs in order to
** construct the string are implementation-defined. 
**
** (Although the standard text doesn't say so, I assume that the intent 
** of 'accept' is to store the string at the address specified on
** the stack.)
** Implementation: if there's more text in the TIB, use it. Otherwise
** throw out for more text. Copy characters up to the max count into the
** address given, and return the number of actual characters copied.
**************************************************************************/
static void accept(FICL_VM *pVM)
{
    UNS32 count, len;
    char *cp;
    char *pBuf = vmGetInBuf(pVM);

    len = strlen(pBuf);
    if (len == 0)
        vmThrow(pVM, VM_RESTART);
    /* OK - now we have something in the text buffer - use it */
    count = stackPopUNS32(pVM->pStack);
    cp    = stackPopPtr(pVM->pStack);

    strncpy(cp, vmGetInBuf(pVM), count);
    len = (count < len) ? count : len;
    pBuf += len;
    vmUpdateTib(pVM, pBuf);
    stackPushUNS32(pVM->pStack, len);

    return;
}


/**************************************************************************
                        a l i g n
** 6.1.0705 ALIGN       CORE ( -- )
** If the data-space pointer is not aligned, reserve enough space to
** align it. 
**************************************************************************/
static void align(FICL_VM *pVM)
{
    FICL_DICT *dp = ficlGetDict();
    IGNORE(pVM);
    dictAlign(dp);
    return;
}


/**************************************************************************
                        a l i g n e d
** 
**************************************************************************/
static void aligned(FICL_VM *pVM)
{
    void *addr = stackPopPtr(pVM->pStack);
    stackPushPtr(pVM->pStack, alignPtr(addr));
    return;
}


/**************************************************************************
                        b e g i n   &   f r i e n d s
** Indefinite loop control structures
** A.6.1.0760 BEGIN 
** Typical use: 
**      : X ... BEGIN ... test UNTIL ;
** or 
**      : X ... BEGIN ... test WHILE ... REPEAT ;
**************************************************************************/
static void beginCoIm(FICL_VM *pVM)
{
    FICL_DICT *dp = ficlGetDict();
    markBranch(dp, pVM, beginTag);
    return;
}

static void untilCoIm(FICL_VM *pVM)
{
    FICL_DICT *dp = ficlGetDict();

    assert(pIfParen);

    dictAppendCell(dp, LVALUEtoCELL(pIfParen));
    resolveBackBranch(dp, pVM, beginTag);
    return;
}

static void whileCoIm(FICL_VM *pVM)
{
    FICL_DICT *dp = ficlGetDict();

    assert(pIfParen);

    dictAppendCell(dp, LVALUEtoCELL(pIfParen));
    markBranch(dp, pVM, whileTag);
    twoSwap(pVM);
    dictAppendUNS32(dp, 1);
    return;
}

static void repeatCoIm(FICL_VM *pVM)
{
    FICL_DICT *dp = ficlGetDict();

    assert(pBranchParen);
    dictAppendCell(dp, LVALUEtoCELL(pBranchParen));

    /* expect "begin" branch marker */
    resolveBackBranch(dp, pVM, beginTag);
    /* expect "while" branch marker */
    resolveForwardBranch(dp, pVM, whileTag);
    return;
}


/**************************************************************************
                        c h a r   &   f r i e n d s
** 6.1.0895 CHAR    CORE ( "<spaces>name" -- char )
** Skip leading space delimiters. Parse name delimited by a space.
** Put the value of its first character onto the stack. 
**
** bracket-char     CORE 
** Interpretation: Interpretation semantics for this word are undefined.
** Compilation: ( "<spaces>name" -- )
** Skip leading space delimiters. Parse name delimited by a space.
** Append the run-time semantics given below to the current definition. 
** Run-time: ( -- char )
** Place char, the value of the first character of name, on the stack. 
**************************************************************************/
static void ficlChar(FICL_VM *pVM)
{
    STRINGINFO si = vmGetWord(pVM);
    if (SI_COUNT(si) == 0)
    {
        vmThrow(pVM, VM_RESTART);
    }

    stackPushUNS32(pVM->pStack, (UNS32)(si.cp[0]));

    return;
}

static void charCoIm(FICL_VM *pVM)
{
    ficlChar(pVM);
    literalIm(pVM);
    return;
}

/**************************************************************************
                        c h a r P l u s
** char-plus        CORE ( c-addr1 -- c-addr2 )
** Add the size in address units of a character to c-addr1, giving c-addr2. 
**************************************************************************/
static void charPlus(FICL_VM *pVM)
{
    char *cp = stackPopPtr(pVM->pStack);
    stackPushPtr(pVM->pStack, cp + 1);
    return;
}

/**************************************************************************
                        c h a r s
** chars        CORE ( n1 -- n2 )
** n2 is the size in address units of n1 characters. 
** For most processors, this function can be a no-op. To guarantee
** portability, we'll multiply by sizeof (char).
**************************************************************************/
#if defined (_M_IX86)
#pragma warning(disable: 4127)
#endif
static void ficlChars(FICL_VM *pVM)
{
    if (sizeof (char) > 1)
    {
        INT32 i = stackPopINT32(pVM->pStack);
        stackPushINT32(pVM->pStack, i * sizeof (char));
    }
    /* otherwise no-op! */
    return;
}
#if defined (_M_IX86)
#pragma warning(default: 4127)
#endif
 

/**************************************************************************
                        c o u n t
** COUNT    CORE ( c-addr1 -- c-addr2 u )
** Return the character string specification for the counted string stored
** at c-addr1. c-addr2 is the address of the first character after c-addr1.
** u is the contents of the character at c-addr1, which is the length in
** characters of the string at c-addr2. 
**************************************************************************/
static void count(FICL_VM *pVM)
{
    FICL_STRING *sp = stackPopPtr(pVM->pStack);
    stackPushPtr(pVM->pStack, sp->text);
    stackPushUNS32(pVM->pStack, sp->count);
    return;
}

/**************************************************************************
                        e n v i r o n m e n t ?
** environment-query CORE ( c-addr u -- false | i*x true )
** c-addr is the address of a character string and u is the string's
** character count. u may have a value in the range from zero to an
** implementation-defined maximum which shall not be less than 31. The
** character string should contain a keyword from 3.2.6 Environmental
** queries or the optional word sets to be checked for correspondence
** with an attribute of the present environment. If the system treats the
** attribute as unknown, the returned flag is false; otherwise, the flag
** is true and the i*x returned is of the type specified in the table for
** the attribute queried. 
**************************************************************************/
static void environmentQ(FICL_VM *pVM)
{
    FICL_DICT *envp = ficlGetEnv();
    FICL_COUNT  len = (FICL_COUNT)stackPopUNS32(pVM->pStack);
    char        *cp =  stackPopPtr(pVM->pStack);
    FICL_WORD  *pFW = dictLookup(envp, cp, len);

    if (pFW != NULL)
    {
        vmExecute(pVM, pFW);
        stackPushINT32(pVM->pStack, FICL_TRUE);
    }
    else
    {
        stackPushINT32(pVM->pStack, FICL_FALSE);
    }

    return;
}

/**************************************************************************
                        e v a l u a t e
** EVALUATE CORE ( i*x c-addr u -- j*x )
** Save the current input source specification. Store minus-one (-1) in
** SOURCE-ID if it is present. Make the string described by c-addr and u
** both the input source and input buffer, set >IN to zero, and interpret.
** When the parse area is empty, restore the prior input source
** specification. Other stack effects are due to the words EVALUATEd. 
**
** DEFICIENCY: this version does not handle errors or restarts.
**************************************************************************/
static void evaluate(FICL_VM *pVM)
{
    UNS32 count = stackPopUNS32(pVM->pStack);
    char *cp    = stackPopPtr(pVM->pStack);

    IGNORE(count);
    vmPushIP(pVM, &pInterpret);
    ficlExec(pVM, cp);
    vmPopIP(pVM);

    return;
}


/**************************************************************************
                        s t r i n g   q u o t e
** Intrpreting: get string delimited by a quote from the input stream,
** copy to a scratch area, and put its count and address on the stack.
** Compiling: compile code to push the address and count of a string
** literal, compile the string from the input stream, and align the dict
** pointer.
**************************************************************************/
static void stringQuoteIm(FICL_VM *pVM)
{
    FICL_DICT *dp = ficlGetDict();

    if (pVM->state == INTERPRET)
    {
        FICL_STRING *sp = (FICL_STRING *) dp->here;
        vmGetString(pVM, sp, '\"');
        stackPushPtr(pVM->pStack, sp->text);
        stackPushUNS32(pVM->pStack, sp->count);
    }
    else    /* COMPILE state */
    {
        dictAppendCell(dp, LVALUEtoCELL(pStringLit));
        dp->here = PTRtoCELL vmGetString(pVM, (FICL_STRING *)dp->here, '\"');
        dictAlign(dp);
    }

    return;
}

/**************************************************************************
                        t y p e
** Pop count and char address from stack and print the designated string.
**************************************************************************/
static void type(FICL_VM *pVM)
{
    FICL_COUNT count = (FICL_COUNT)stackPopUNS32(pVM->pStack);
    char *cp         = stackPopPtr(pVM->pStack);

    IGNORE(count);
    vmTextOut(pVM, cp, 0);
    return;
}

/**************************************************************************
                        w o r d
** word CORE ( char "<chars>ccc<char>" -- c-addr )
** Skip leading delimiters. Parse characters ccc delimited by char.
** An ambiguous condition exists if the length of the parsed string
** is greater than the implementation-defined length of a counted string. 
**************************************************************************/
static void parseWord(FICL_VM *pVM)
{
    char delim      = (char)stackPopINT32(pVM->pStack);
    char *pSrc      = vmGetInBuf(pVM);
    FICL_STRING *sp = (FICL_STRING *)ficlGetDict()->here;
    char *pDest     = sp->text;

    pSrc = skipSpace(pSrc);
    while (*pSrc == delim)
        pSrc++;

    while ((*pSrc != delim) && (*pSrc != '\0'))
        *pDest++ = *pSrc++;

    *pDest = '\0';

    if (*pSrc == delim)
        pSrc++;

    vmUpdateTib(pVM, pSrc);
    sp->count = (FICL_COUNT)(pDest - sp->text);
    stackPushPtr(pVM->pStack, sp);
    return;
}


/**************************************************************************
                        f i l l
** CORE ( c-addr u char -- )
** If u is greater than zero, store char in each of u consecutive
** characters of memory beginning at c-addr. 
**************************************************************************/
static void fill(FICL_VM *pVM)
{
    char ch  = (char)stackPopINT32(pVM->pStack);
    UNS32  u = stackPopUNS32(pVM->pStack);
    char *cp = (char *)stackPopPtr(pVM->pStack);

    while (u > 0)
    {
        *cp++ = ch;
        u--;
    }

    return;
}


/**************************************************************************
                        f i n d
** FIND CORE ( c-addr -- c-addr 0  |  xt 1  |  xt -1 )
** Find the definition named in the counted string at c-addr. If the
** definition is not found, return c-addr and zero. If the definition is
** found, return its execution token xt. If the definition is immediate,
** also return one (1), otherwise also return minus-one (-1). For a given
** string, the values returned by FIND while compiling may differ from
** those returned while not compiling. 
**************************************************************************/
static void find(FICL_VM *pVM)
{
    FICL_STRING *sp = stackPopPtr(pVM->pStack);
    FICL_WORD *pFW  = dictLookup(ficlGetDict(), sp->text, sp->count);

    if (pFW)
    {
        stackPushPtr(pVM->pStack, pFW);
        stackPushINT32(pVM->pStack, (wordIsImmediate(pFW) ? 1 : -1));
    }
    else
    {
        stackPushPtr(pVM->pStack, sp);
        stackPushUNS32(pVM->pStack, 0);
    }
    return;
}


/**************************************************************************
                        f m S l a s h M o d
** f-m-slash-mod CORE ( d1 n1 -- n2 n3 )
** Divide d1 by n1, giving the floored quotient n3 and the remainder n2.
** Input and output stack arguments are signed. An ambiguous condition
** exists if n1 is zero or if the quotient lies outside the range of a
** single-cell signed integer. 
**************************************************************************/
static void fmSlashMod(FICL_VM *pVM)
{
    INT64 d1;
    INT32 n1;
    INTQR qr;

    n1    = stackPopINT32(pVM->pStack);
    d1 = i64Pop(pVM->pStack);
    qr = m64FlooredDivI(d1, n1);
    stackPushINT32(pVM->pStack, qr.rem);
    stackPushINT32(pVM->pStack, qr.quot);
    return;
}


/**************************************************************************
                        s m S l a s h R e m
** s-m-slash-rem CORE ( d1 n1 -- n2 n3 )
** Divide d1 by n1, giving the symmetric quotient n3 and the remainder n2.
** Input and output stack arguments are signed. An ambiguous condition
** exists if n1 is zero or if the quotient lies outside the range of a
** single-cell signed integer. 
**************************************************************************/
static void smSlashRem(FICL_VM *pVM)
{
    INT64 d1;
    INT32 n1;
    INTQR qr;

    n1    = stackPopINT32(pVM->pStack);
    d1 = i64Pop(pVM->pStack);
    qr = m64SymmetricDivI(d1, n1);
    stackPushINT32(pVM->pStack, qr.rem);
    stackPushINT32(pVM->pStack, qr.quot);
    return;
}


static void ficlMod(FICL_VM *pVM)
{
    INT64 d1;
    INT32 n1;
    INTQR qr;

    n1    = stackPopINT32(pVM->pStack);
    d1.lo = stackPopINT32(pVM->pStack);
    i64Extend(d1);
    qr = m64SymmetricDivI(d1, n1);
    stackPushINT32(pVM->pStack, qr.rem);
    return;
}


/**************************************************************************
                        u m S l a s h M o d
** u-m-slash-mod CORE ( ud u1 -- u2 u3 )
** Divide ud by u1, giving the quotient u3 and the remainder u2.
** All values and arithmetic are unsigned. An ambiguous condition
** exists if u1 is zero or if the quotient lies outside the range of a
** single-cell unsigned integer. 
*************************************************************************/
static void umSlashMod(FICL_VM *pVM)
{
    UNS64 ud;
    UNS32 u1;
    UNSQR qr;

    u1    = stackPopUNS32(pVM->pStack);
    ud    = u64Pop(pVM->pStack);
    qr    = ficlLongDiv(ud, u1);
    stackPushUNS32(pVM->pStack, qr.rem);
    stackPushUNS32(pVM->pStack, qr.quot);
    return;
}


/**************************************************************************
                        l s h i f t
** l-shift CORE ( x1 u -- x2 )
** Perform a logical left shift of u bit-places on x1, giving x2.
** Put zeroes into the least significant bits vacated by the shift.
** An ambiguous condition exists if u is greater than or equal to the
** number of bits in a cell. 
**
** r-shift CORE ( x1 u -- x2 )
** Perform a logical right shift of u bit-places on x1, giving x2.
** Put zeroes into the most significant bits vacated by the shift. An
** ambiguous condition exists if u is greater than or equal to the
** number of bits in a cell. 
**************************************************************************/
static void lshift(FICL_VM *pVM)
{
    UNS32 nBits = stackPopUNS32(pVM->pStack);
    UNS32 x1    = stackPopUNS32(pVM->pStack);

    stackPushUNS32(pVM->pStack, x1 << nBits);
    return;
}


static void rshift(FICL_VM *pVM)
{
    UNS32 nBits = stackPopUNS32(pVM->pStack);
    UNS32 x1    = stackPopUNS32(pVM->pStack);

    stackPushUNS32(pVM->pStack, x1 >> nBits);
    return;
}


/**************************************************************************
                        m S t a r
** m-star CORE ( n1 n2 -- d )
** d is the signed product of n1 times n2. 
**************************************************************************/
static void mStar(FICL_VM *pVM)
{
    INT32 n2 = stackPopINT32(pVM->pStack);
    INT32 n1 = stackPopINT32(pVM->pStack);
    INT64 d;
    
    d = m64MulI(n1, n2);
    i64Push(pVM->pStack, d);
    return;
}


static void umStar(FICL_VM *pVM)
{
    UNS32 u2 = stackPopUNS32(pVM->pStack);
    UNS32 u1 = stackPopUNS32(pVM->pStack);
    UNS64 ud;
    
    ud = ficlLongMul(u1, u2);
    u64Push(pVM->pStack, ud);
    return;
}


/**************************************************************************
                        m a x   &   m i n
** 
**************************************************************************/
static void ficlMax(FICL_VM *pVM)
{
    INT32 n2 = stackPopINT32(pVM->pStack);
    INT32 n1 = stackPopINT32(pVM->pStack);

    stackPushINT32(pVM->pStack, (n1 > n2) ? n1 : n2);
    return;
}

static void ficlMin(FICL_VM *pVM)
{
    INT32 n2 = stackPopINT32(pVM->pStack);
    INT32 n1 = stackPopINT32(pVM->pStack);

    stackPushINT32(pVM->pStack, (n1 < n2) ? n1 : n2);
    return;
}


/**************************************************************************
                        m o v e
** CORE ( addr1 addr2 u -- )
** If u is greater than zero, copy the contents of u consecutive address
** units at addr1 to the u consecutive address units at addr2. After MOVE
** completes, the u consecutive address units at addr2 contain exactly
** what the u consecutive address units at addr1 contained before the move. 
**************************************************************************/
static void move(FICL_VM *pVM)
{
    UNS32 u     = stackPopUNS32(pVM->pStack);
    char *addr2 = stackPopPtr(pVM->pStack);
    char *addr1 = stackPopPtr(pVM->pStack);

    if (u == 0) 
        return;
    /*
    ** Do the copy carefully, so as to be
    ** correct even if the two ranges overlap
    */
    if (addr1 >= addr2)
    {
        for (; u > 0; u--)
            *addr2++ = *addr1++;
    }
    else
    {
        addr2 += u-1;
        addr1 += u-1;
        for (; u > 0; u--)
            *addr2-- = *addr1--;
    }

    return;
}


/**************************************************************************
                        r e c u r s e
** 
**************************************************************************/
static void recurseCoIm(FICL_VM *pVM)
{
    FICL_DICT *pDict = ficlGetDict();

    IGNORE(pVM);
    dictAppendCell(pDict, LVALUEtoCELL(pDict->smudge));
    return;
}


/**************************************************************************
                        s t o d
** s-to-d CORE ( n -- d )
** Convert the number n to the double-cell number d with the same
** numerical value. 
**************************************************************************/
static void sToD(FICL_VM *pVM)
{
    INT32 s = stackPopINT32(pVM->pStack);

    /* sign extend to 64 bits.. */
    stackPushINT32(pVM->pStack, s);
    stackPushINT32(pVM->pStack, (s < 0) ? -1 : 0);
    return;
}


/**************************************************************************
                        s o u r c e
** CORE ( -- c-addr u )
** c-addr is the address of, and u is the number of characters in, the
** input buffer. 
**************************************************************************/
static void source(FICL_VM *pVM)
{
    stackPushPtr(pVM->pStack, pVM->tib.cp);
    stackPushINT32(pVM->pStack, strlen(pVM->tib.cp));
    return;
}


/**************************************************************************
                        v e r s i o n
** 
**************************************************************************/
static void ficlVersion(FICL_VM *pVM)
{
    vmTextOut(pVM, "ficl Version " FICL_VER, 1);
    return;
}


/**************************************************************************
                        t o I n
** 
**************************************************************************/
static void toIn(FICL_VM *pVM)
{
    stackPushPtr(pVM->pStack, &pVM->tib.index);
    return;
}


#if 0
/**************************************************************************
                        
** 
**************************************************************************/
static void funcname(FICL_VM *pVM)
{
    IGNORE(pVM);
    return;
}


#endif
/**************************************************************************
                        f i c l C o m p i l e C o r e
** Builds the ANS CORE wordset, the environment-query namespace, and
** a few non-std or extension words into the dictionary.
**************************************************************************/

void ficlCompileCore(FICL_DICT *dp)
{
    assert (dp);

    pLitParen = 
    dictAppendWord(dp, "(literal)", literalParen,   FW_DEFAULT);
    pStringLit =
    dictAppendWord(dp, "(.\")",     stringLit,      FW_DEFAULT);
    pExit =
    dictAppendWord(dp, "exit",      exitCo,         FW_COMPILE);
    pIfParen =
    dictAppendWord(dp, "(if)",      ifParen,        FW_DEFAULT);
    pBranchParen =
    dictAppendWord(dp, "(branch)",  branchParen,    FW_DEFAULT);
    pDoParen =
    dictAppendWord(dp, "(do)",      doParen,        FW_DEFAULT);
    pLoopParen =
    dictAppendWord(dp, "(loop)",    loopParen,      FW_DEFAULT);
    pPLoopParen =
    dictAppendWord(dp, "(+loop)",   plusLoopParen,  FW_DEFAULT);

    dictAppendWord(dp, "words",     listWords,      FW_DEFAULT);
    dictAppendWord(dp, "bye",       bye,            FW_DEFAULT);

    dictAppendWord(dp, "environment?", environmentQ,FW_DEFAULT);
    dictAppendWord(dp, "immediate", immediate,      FW_DEFAULT);
    pInterpret =
    dictAppendWord(dp, "interpret", interpret,      FW_DEFAULT);
    dictAppendWord(dp, "literal",   literalIm,      FW_IMMEDIATE);
    dictAppendWord(dp, ":",         colon,          FW_DEFAULT);
    dictAppendWord(dp, ";",         semicolonCoIm,  FW_COMPIMMED);
    dictAppendWord(dp, "[",         lbracketCoIm,   FW_COMPIMMED);
    dictAppendWord(dp, "]",         rbracket,       FW_DEFAULT);
    dictAppendWord(dp, "quit",      quit,           FW_DEFAULT);
    dictAppendWord(dp, "abort",     ficlAbort,      FW_DEFAULT);

    dictAppendWord(dp, "base",      base,           FW_DEFAULT);
    dictAppendWord(dp, "decimal",   decimal,        FW_DEFAULT);
    dictAppendWord(dp, "hex",       hex,            FW_DEFAULT);

    
    dictAppendWord(dp, "if",        ifCoIm,         FW_COMPIMMED);
    dictAppendWord(dp, "else",      elseCoIm,       FW_COMPIMMED);
    dictAppendWord(dp, "then",      endifCoIm,      FW_COMPIMMED);
    dictAppendWord(dp, "endif",     endifCoIm,      FW_COMPIMMED);
    dictAppendWord(dp, "do",        doCoIm,         FW_COMPIMMED);
    dictAppendWord(dp, "loop",      loopCoIm,       FW_COMPIMMED);
    dictAppendWord(dp, "+loop",     plusLoopCoIm,   FW_COMPIMMED);
    dictAppendWord(dp, "leave",     leaveCo,        FW_COMPILE);
    dictAppendWord(dp, "unloop",    unloopCo,       FW_COMPILE);
    dictAppendWord(dp, "i",         loopICo,        FW_COMPILE);
    dictAppendWord(dp, "j",         loopJCo,        FW_COMPILE);
    dictAppendWord(dp, "k",         loopKCo,        FW_COMPILE);

    dictAppendWord(dp, "begin",     beginCoIm,      FW_COMPIMMED);
    dictAppendWord(dp, "until",     untilCoIm,      FW_COMPIMMED);
    dictAppendWord(dp, "while",     whileCoIm,      FW_COMPIMMED);
    dictAppendWord(dp, "repeat",    repeatCoIm,     FW_COMPIMMED);

    dictAppendWord(dp, "0=",        zeroEquals,     FW_DEFAULT);
    dictAppendWord(dp, "0<",        zeroLess,       FW_DEFAULT);
    dictAppendWord(dp, "0>",        zeroGreater,    FW_DEFAULT);
    dictAppendWord(dp, "=",         isEqual,        FW_DEFAULT);
    dictAppendWord(dp, "<",         isLess,         FW_DEFAULT);
    dictAppendWord(dp, "u<",        uIsLess,        FW_DEFAULT);
    dictAppendWord(dp, ">",         isGreater,      FW_DEFAULT);
    dictAppendWord(dp, "and",       bitwiseAnd,     FW_DEFAULT);
    dictAppendWord(dp, "or",        bitwiseOr,      FW_DEFAULT);
    dictAppendWord(dp, "xor",       bitwiseXor,     FW_DEFAULT);
    dictAppendWord(dp, "invert",    bitwiseNot,     FW_DEFAULT);

    dictAppendWord(dp, "+",         add,            FW_DEFAULT);
    dictAppendWord(dp, "-",         sub,            FW_DEFAULT);
    dictAppendWord(dp, "*",         mul,            FW_DEFAULT);
    dictAppendWord(dp, "/",         ficlDiv,        FW_DEFAULT);
    dictAppendWord(dp, "1+",        onePlus,        FW_DEFAULT);
    dictAppendWord(dp, "1-",        oneMinus,       FW_DEFAULT);
    dictAppendWord(dp, "2*",        twoMul,         FW_DEFAULT);
    dictAppendWord(dp, "2/",        twoDiv,         FW_DEFAULT);
    dictAppendWord(dp, "*/",        mulDiv,         FW_DEFAULT);
    dictAppendWord(dp, "m*",        mStar,          FW_DEFAULT);
    dictAppendWord(dp, "um*",       umStar,         FW_DEFAULT);
    dictAppendWord(dp, "*/mod",     mulDivRem,      FW_DEFAULT);
    dictAppendWord(dp, "/mod",      slashMod,       FW_DEFAULT);
    dictAppendWord(dp, "mod",       ficlMod,        FW_DEFAULT);
    dictAppendWord(dp, "fm/mod",    fmSlashMod,     FW_DEFAULT);
    dictAppendWord(dp, "sm/rem",    smSlashRem,     FW_DEFAULT);
    dictAppendWord(dp, "um/mod",    umSlashMod,     FW_DEFAULT);
    dictAppendWord(dp, "negate",    negate,         FW_DEFAULT);
    dictAppendWord(dp, "lshift",    lshift,         FW_DEFAULT);
    dictAppendWord(dp, "rshift",    rshift,         FW_DEFAULT);
    dictAppendWord(dp, "max",       ficlMax,        FW_DEFAULT);
    dictAppendWord(dp, "min",       ficlMin,        FW_DEFAULT);
    dictAppendWord(dp, "s>d",       sToD,           FW_DEFAULT);

    dictAppendWord(dp, "dup",       dup,            FW_DEFAULT);
    dictAppendWord(dp, "2dup",      twoDup,         FW_DEFAULT);
    dictAppendWord(dp, "?dup",      questionDup,    FW_DEFAULT);
    dictAppendWord(dp, "over",      over,           FW_DEFAULT);
    dictAppendWord(dp, "2over",     twoOver,        FW_DEFAULT);
    dictAppendWord(dp, "pick",      pick,           FW_DEFAULT);
    dictAppendWord(dp, "rot",       rot,            FW_DEFAULT);
    dictAppendWord(dp, "roll",      roll,           FW_DEFAULT);
    dictAppendWord(dp, "swap",      swap,           FW_DEFAULT);
    dictAppendWord(dp, "2swap",     twoSwap,        FW_DEFAULT);
    dictAppendWord(dp, "depth",     depth,          FW_DEFAULT);
    dictAppendWord(dp, "drop",      drop,           FW_DEFAULT);
    dictAppendWord(dp, "2drop",     twoDrop,        FW_DEFAULT);
    dictAppendWord(dp, "char",      ficlChar,       FW_DEFAULT);
    dictAppendWord(dp, "word",      parseWord,      FW_DEFAULT);
    dictAppendWord(dp, "find",      find,           FW_DEFAULT);
    dictAppendWord(dp, "[char]",    charCoIm,       FW_COMPIMMED);
    dictAppendWord(dp, "char+",     charPlus,       FW_DEFAULT);
    dictAppendWord(dp, "chars",     ficlChars,      FW_DEFAULT);
    dictAppendWord(dp, "emit",      emit,           FW_DEFAULT);
    dictAppendWord(dp, "fill",      fill,           FW_DEFAULT);
    dictAppendWord(dp, "move",      move,           FW_DEFAULT);
    pType =
    dictAppendWord(dp, "type",      type,           FW_DEFAULT);
    dictAppendWord(dp, "cr",        cr,             FW_DEFAULT);
    dictAppendWord(dp, "count",     count,          FW_DEFAULT);
    dictAppendWord(dp, "source",    source,         FW_DEFAULT);
    dictAppendWord(dp, "accept",    accept,         FW_DEFAULT);
    dictAppendWord(dp, ">in",       toIn,           FW_DEFAULT);
    dictAppendWord(dp, ".",         displayCell,    FW_DEFAULT);
    dictAppendWord(dp, "u.",        uDot,           FW_DEFAULT);
    dictAppendWord(dp, ".s",        displayStack,   FW_DEFAULT);
    dictAppendWord(dp, ".\"",       dotQuoteCoIm,   FW_COMPIMMED);
    dictAppendWord(dp, "s\"",       stringQuoteIm,  FW_IMMEDIATE);
    dictAppendWord(dp, ".(",        dotParen,       FW_DEFAULT);
    dictAppendWord(dp, "(",         commentHang,    FW_IMMEDIATE);
    dictAppendWord(dp, "\\",        commentLine,    FW_IMMEDIATE);

    dictAppendWord(dp, "<#",        lessNumberSign, FW_DEFAULT);
    dictAppendWord(dp, "#",         numberSign,     FW_DEFAULT);
    dictAppendWord(dp, "#>",        numberSignGreater,FW_DEFAULT);
    dictAppendWord(dp, "#s",        numberSignS,    FW_DEFAULT);
    dictAppendWord(dp, "sign",      sign,           FW_DEFAULT);
    dictAppendWord(dp, "hold",      hold,           FW_DEFAULT);
    dictAppendWord(dp, ">number",   toNumber,       FW_DEFAULT);
    
    dictAppendWord(dp, "variable",  variable,       FW_DEFAULT);
    dictAppendWord(dp, "(variable)",variableParen,  FW_DEFAULT);
    dictAppendWord(dp, "constant",  constant,       FW_DEFAULT);
    dictAppendWord(dp, "(constant)",constantParen,  FW_DEFAULT);
    dictAppendWord(dp, "allot",     allot,          FW_DEFAULT);
    dictAppendWord(dp, "align",     align,          FW_DEFAULT);
    dictAppendWord(dp, "aligned",   aligned,        FW_DEFAULT);
    dictAppendWord(dp, "create",    create,         FW_DEFAULT);
    dictAppendWord(dp, "does>",     doesCo,         FW_COMPILE);
    dictAppendWord(dp, ">body",     toBody,         FW_DEFAULT);
    dictAppendWord(dp, "here",      here,           FW_DEFAULT);
    pComma =
    dictAppendWord(dp, ",",         comma,          FW_DEFAULT);
    dictAppendWord(dp, "c,",        cComma,         FW_DEFAULT);
    dictAppendWord(dp, "cells",     cells,          FW_DEFAULT);
    dictAppendWord(dp, "cell+",     cellPlus,       FW_DEFAULT);
    dictAppendWord(dp, "\'",        tick,           FW_DEFAULT);
    dictAppendWord(dp, "evaluate",  evaluate,       FW_DEFAULT);
    dictAppendWord(dp, "execute",   execute,        FW_DEFAULT);
    dictAppendWord(dp, "postpone",  postponeCoIm,   FW_COMPIMMED);
    dictAppendWord(dp, "recurse",   recurseCoIm,    FW_COMPIMMED);
    dictAppendWord(dp, "[\']",      bracketTickCoIm,FW_COMPIMMED);
    dictAppendWord(dp, "state",     state,          FW_DEFAULT);

    dictAppendWord(dp, ">r",        toRStack,       FW_DEFAULT);
    dictAppendWord(dp, "r>",        fromRStack,     FW_DEFAULT);
    dictAppendWord(dp, "r@",        fetchRStack,    FW_DEFAULT);

    dictAppendWord(dp, "@",         fetch,          FW_DEFAULT);
    dictAppendWord(dp, "2@",        twoFetch,       FW_DEFAULT);
    dictAppendWord(dp, "!",         store,          FW_DEFAULT);
    dictAppendWord(dp, "2!",        twoStore,       FW_DEFAULT);
    dictAppendWord(dp, "+!",        plusStore,      FW_DEFAULT);
    dictAppendWord(dp, "w@",        wFetch,         FW_DEFAULT);
    dictAppendWord(dp, "w!",        wStore,         FW_DEFAULT);
    dictAppendWord(dp, "c@",        cFetch,         FW_DEFAULT);
    dictAppendWord(dp, "c!",        cStore,         FW_DEFAULT);

    /*
    ** Set system-specific values of the environment table 
    */
    ficlSetEnv("/counted-string", 255);
    ficlSetEnv("/hold",    nPAD);
    ficlSetEnv("/pad",     nPAD);
    ficlSetEnv("address-unit-bits", 8);
    ficlSetEnv("core",     FICL_TRUE);
    ficlSetEnv("core-ext", FICL_FALSE);
    ficlSetEnv("floored",  FICL_FALSE);
    ficlSetEnv("max-char", 0xff);
    ficlSetEnvD("max-d",   0x7fffffff, 0xffffffff );
    ficlSetEnv("max-n",    0x7fffffff);
    ficlSetEnv("max-u",    0xffffffff);
    ficlSetEnvD("max-ud",  0xffffffff, 0xffffffff);
    ficlSetEnv("return-stack-cells", FICL_DEFAULT_STACK);
    ficlSetEnv("stack-cells", FICL_DEFAULT_STACK);

    /* Internal Debug & test support - nonstandard words */
    dictAppendWord(dp, ".hash",     dictHashSummary,FW_DEFAULT);
    dictAppendWord(dp, ".ver",      ficlVersion,        FW_DEFAULT);
    return;
}

