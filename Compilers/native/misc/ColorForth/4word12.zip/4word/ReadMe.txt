                             4word Notes .11
Updated: Feb. 3, 2001

Terry Loveall,   loveall@qwest.net

--------------------------------------

This GPL software comes with absolutely no warranty. Use at your own risk. It is
an advanced brute force exploration of 1x programming and Color Forth concepts.
For beginning tutorials, and almost everything else, on Forth see:
    http://www.taygeta.com/forth.html

Use the source. Most kernel word defined are used. The only definitions not used
in the kernel or example source are some of the indexed A and R words. These 
were left in the kernel for completeness. This description tries to be complete,
but may not always be so. The source in this package is the definitive guide to
what is going on.

What follows is just some basic info to help you to perform basic operation on 
4word. To start 4word in a usable condition, enter the following from the DOS
command line:

C:\forthish\4word>'4word fload 4wboot.p '<Enter>
       (omit the ticks, but include the extra space, see below)

-------------------------
Case sensitivity:

The 4word dictionary is case sensitive. Most of the definitions are in lower
case. There are a few, such as doVAR and doLIT, that are mixed. Use 'words' to
determine the accepted case, or read the assembler source or .lst. if you do
not like these preferences, feel free to change them.

-------------------------
File name caveat:

4word file name I/O is _not_ case sensitive. DOS will open 4wboot.p or 4wBoot.p.

4word file I/O does not move name strings. It does place a zero at the end of
file name strings. Because of this, all use of file I/O requires an extra space
(or more) after the file name and before the following <Enter> key is pressed.

-------------------------
Command line file loading:

You can load Forth files from the DOS command line or the 4word command line. 
Enter:

'4word fload 4wBoot.p fload 4wDbg.p fload 4wCedit.p '<Enter> from DOS
  or
'fload 4wBoot.p fload 4wDbg.p fload 4wCedit.p '<Enter> in 4word

(omit the ticks but trailing space is required) and 4word will load its
extensions and then the text editor and then enter into the 4word command line
waiting user input. Either append the word 'de' to the above command line or
invoke it from the 4word command line to invoke the editor on itself.

-------------------------
DOS command line usage:

4word knows about the DOS command line. Entering the following from DOS:
'4word N 5 N 6 + u. bye'

will execute 4word, convert 5 as a number to the default hex number base,
convert 6 as a number, add them, display the sum 'B' and exit 4word.

The kernel defaults to hex and has a primitive defined 'N' that gets the next
word token and attempts to convert it as a number. If this fails then the
current abort procedure is followed, i.e from the DOS command line--exit to DOS,
from the 4word command line--abort. The number base specific tokens '$' and '&'
are defined in the source file 4wBoot.p.

-------------------------
Error handling:

Any errors detected before 4word gets to its own command line will exit back to
DOS. Once 4word starts 'accepting' input from its own command line, it will just
'abort', dump the address of and display the offending string and wait for 
further input. There is also a stack underflow test.

-------------------------
Command line input:

'accept' is an assembler routine that knows about backspace (08h),  ^L (0CH
forward space) and <Enter> (0DH). This enables you to recover the last line
entered, including the DOS command line, with a series of ^Ls.

-------------------------
Useful extensions:

4word has 'words' and 'dis' (my version of 'see') defined in 4wBoot.p. 
'words' will list the words in the dictionary in the following format:
  NFA  CFA NAME   <- explanation, not displayed)
 5619 2035 fill
<Enter> key terminates, any other key advances.

" ' dis dis" will do a simple Forth disassembly of itself. Again, <Enter> key 
terminates, any other key advances.

-------------------------
4word Editor help:

This is a true Color Forth ASCII text editor.

To load and compile the editor, enter the command line 'fload 4wCedit.p ' 
after having loaded 4wboot.p. 

To load other files for editing, enter the command line 'edld 4wDbg.p de'. 
This will load file 4wdbg.p and then invoke the editor. 

File size is limited to a maximum of 40960 bytes. It performs NO file size 
checks. If you are generating 40k+ Forth source files you need to re-think 
your problem.

Use ^Q to exit from edit mode. 

To save edited files, exit from edit mode and enter the command line 
'esave 4wDbgM.p '

There are only 13 control keys which are:

    Hex      defined    Key: function
-------------------------------------
  $   0c , ' sagn    , ( ^L: search again)
  $   0d , ' docr    , ( <Enter> insert CRLF pair)
  $  013 , ' srch    , ( ^S: get string and search)
  $  01b , ' esc     , ( ^Q: exit editor)
  $ 8400 , ' bof     , ( ^PgUp: goto file start)
  $ 7600 , ' eof     , ( ^PgDn: goto file end)
  $ 4900 , ' dopgup  , ( page up)
  $ 5100 , ' dopgdn  , ( page down)
  $ 4b00 , ' doleft  , ( left arrow)
  $ 4d00 , ' doright , ( right arrow)
  $ 4800 , ' doup    , ( up arrow)
  $ 5000 , ' dodown  , ( down arrow)
  $ 5300 , ' dodel   , ( Del key: delete char under cursor)

The Color Forth editor is invoked, after loading, with the command 'de'.
It has string search (forward only), which uses the ss buffer and 'accept'.
See the source for complete details.

Color keys are the following:
  $ 1f := ^_ := [ := Interpret )
  $ 1e := ^^ := ( := Comment )
  $ 1d := ^] := ] := Compile )
  $ 1c := ^\ := $ := Hex number )
  $ 1b := ^[ := : := Define name )
  $ 1a := ^Z := L := Literal )
  $ 19 := ^Y := V := Var )
  $ 18 := ^X := & := Decimal number )

A legend is displayed during the edit session to remind you.

The file 4wCedit.p is an operational example of Color Forth programming written
using color codes. The file 4wDeC.p is a Color Forth editor written using the
above colorless single ASCII character modes, i.e. ':', ']'.... These two files
are semantically equal. The 4wCedit.p file was created by replacing the single
character modes and following space of 4wDeC.p with the appropriate control
code. To 'neaten' up the source, a terminating ^_ was appended to the end of
various other colors to prevent 'color bleed' to the following line.

-------------------------

4word dbg help:

To load, enter the command line 'fload 4wdbg.p ' after having loaded 4wboot.p.

  $   0d , ' 0=    , ( cr exit)
  $ 4800 , ' gbk   , ( up prev)
  $ 5000 , ' nop   , ( down next)
  $ 4d00 , ' ent   , ( left unnest)
  $ 4b00 , ' back  , ( right nest)
  $   47 , ' prcd  , ( 'G' execute, note: must be upper case G)
  $ 5200 , ' insrn , ( ins)
  $ 5300 , ' newrd , ( del)

Example use: " ' dbg dbg" will disassemble itself. A stack display is present
on the current address displayed. Enter a 'G' to execute the word at the current
addres IF IT IS A CALL TO A FORTH WORD. It will ignore the 'G' otherwise. Use 
this with some discretion as it CAN be destructive.

-------------------------
Color Forth programming:

The files 4wBootO.p and 4wDeO.p are included for reference. These are the 
initial versions of colorless Color Forth. They have factoring applied, but
use all of the old compiler conditionals, e.g. begin, while, until, repeat,
for, aft and next. 4wDeO.p provides just a straigtforward ASCII text editor
with no color. They are supplied as a baseline reference for you to make
your own evaluation on the merits of 'conventional' Forth programming vice
extreme conditional programming. The file, 4wDeNC has the extreme conditionals,
but no color.

The full Color Forth capable extensions, 4wBoot.p, 4wDbg.p, 4wDeC.p and
4wCedit.p use only 'if', 'else', 'then', ';' and ';;' (tail recursion). 

All of the 'conventional' conditional structures are brutally coded in terms of
'if', 'then', ';' and ';;'. 'else' is sparingly used only where it actually
saves code. 

There is no 'smudge' bit, so a definition can call itself. The tail recursion
operator ';;' checks to see if 'here $ 6 -' contains a call and if it does,
converts it to a jmp. Must be interpreted.

   Hex Control ASCII   MODE
------------------------------
    1f    ^_    [    Interpret
    1e    ^^    (    Comment
    1d    ^]    ]    Compile
    1c    ^\    $    Hex number
    1b    ^[    :    Define name
    1a    ^Z    L    Literal
    19    ^Y    V    Var
    18    ^X    &    Decimal number

The following words MUST be in interpret mode to execute as expected, i.e. they
  must not be preceeded by anything execpt ' ', ^_ or '[':
  'if', 'else', 'then', '$ nnnn L', $", .", ;, and ;;.

There is no 'immediate'. The interpreter for 4word ONLY INTERPRETS. There is 
no 'compiler' mode, there is only single character (color) commands that:
  perform an operation on the top stack value, i.e. 'L' or ^Z which compiles a
    call to doLIT followed by the 32bit value TOS.

  perform an operation on the following string:
    ':' or ^[ defines a new dictionary entry.
    ']' or ^] looks the following string up in the dictionary and compiles a 
      call32 to the CFA. Execute 'abort' if not found.
    '(' skips all text until a succeeding ')' is found, i.e. comment.
    ^^ skips the following word, _color_ comment.

The null definition '[' or ^_ aids readability by indicating an 'explicit
switch' to 'interpret' mode. Not prefixing a word with a color code is
syntactically equal to prefixing it with a '[' or ^_. ALL conditionals  must be
interpreted, not compiled. See the various source for examples.

The interpreter has help from '$' and '&' for numeric input. These MUST be in
interpreter mode, e.g. '[ $ 100 L ]'. Preceeding a numeric string such as '1234'
with ']' will only generate an 'abort' on the string '1234'. The sequence '] $'
will cause the  containing code to look for a hex numeric string when said code
_executes_.

-------------------------
Rebuilding 4word.com

To rebuild 4word.asm use the supplied g.bat file. Enter 'g' from the DOS
command line for usage.

To re-assemble 4word enter the command line:
 'g 4word l'
followed by
 'mc'
which extracts 4word.com from 4word.exe. View the source for g.bat and mc.bat
for further details.

If you add/remove new names or change name lengths to 4word.asm, you have to
manually adjust a couple of values in 4word.asm and mkcom.txt. For compactness,
the dictionary for the asm kernel is embedded at the beginning of the binary.

The value of the length of the dictionary must be calculated from the values
in 4word.lst. 

Look for the end address of the dictionary entry for the word 'bye' at about
line# 230. You will have to figure it from the address of the string for 'bye'.
In the current version it is at address 06D0h and is four bytes long for an end
address of 06D4h.

Then look for the starting address to the dictionary entry for the word 'go'.
This is located at about line# 2319. Look for the line containing the
'DD _CODE,_LINK' for 'go'. This is the start address which is currently 01B8h.

Calculate the difference and plug that value into line# 81 in 4word.asm where
DICLEN is set. The current value is 0520H.

If you add code to the startup at ORG 0100H or add system vars, then you have
to change the value of 'NAMEE' in line# 91 in 4word.asm. Again, you have to get
the correct value from 4word.lst after you make your changes and re-assemble.

Next, you have to re-assemble, again, with the command line:
 'g 4word l'
Search for the string 'codeln' in 4word.lst. It will be somewhere around
line# 2374 and has a current value of 0FFDH. This value needs to be placed
in the file mkcom.txt for the CX value and for the m length value
Mkcom.txt currently looks like this:

n4word.com
rcx f3c                     <- change this value
m 600 lf3c 100              <- change the value after the 'l'
w
q

Run the mc.bat line to convert/extract 4word.com from 4word.exe. Exe2bin does
not work on 4word.exe. Mc.bat deletes 4word.exe, so you have re-assemble if
4word.com gets messed up.

At that time you will have a new 4word.com kernel.

If this is too complex and you come up with a fix, feel free to send it to me.

-----------
Change Log:

Acutally used the 'kp?' def in 4wCedit.p and 4wDeC.p. 2/3/01

Added file 4wordMan.txt, a rudimentary manual. 2/3/01

Removed dup defs hex and decimal in 4wBoot.p. 2/3/01

Removed set/restore color output in 4wCedit.p and 4wDeC.p 2/3/01

Updated this file 'Color Forth programming:'. 2/2/01

Added GPL to copyright comment in *.p files. 2/2/01

Removed dup def >cu from 4wDbg.p. 2/2/01

Moved ctap color output in 4wCedit.p and 4wDeC.p to 4wBoot.p. 2/2/01

Updated 4word.com generated. 2/2/01

Updated file lengths in mkcom.txt 2/2/01

Updated 4word.lst generated. 2/2/01

Moved CR/LF processing from ctap in 4wBoot.p to cemit in 4word.asm. 2/2/01

Added zero xy to function cls in 4word.asm. 2/2/01

Factored 2drop in 4word.asm 2/2/01

Added Change Log to this file. 2/2/01

Fixed typo in function 'ctap' in 4wDeC.p. 2/2/01

Neatened up color display in 4wCedit.p. 2/2/01

Updated 4word.com generated. 2/2/01

Updated file lengths in mkcom.txt 2/2/01

Updated 4word.lst generated. 2/2/01

Updated stack underflow test in 4word.asm. 2/2/01
-------------------------
