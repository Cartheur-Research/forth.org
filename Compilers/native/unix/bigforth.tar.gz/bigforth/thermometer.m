\ automatic generated code
\ do not edit
windows also forth

window class thermometer
public:
  early open
  early modal-open
  canvas ptr temp
  vscaler ptr pos
  | glue ptr (glue-00)
  | button ptr (button-01)
  | glue ptr (glue-02)
how:
  : open       screen self new >o map o> ;
  : modal-open screen self new >o map stop o> ;
class;

thermometer implements
  : init  super init ^ { ^^ | ( [dumpstart] )
        CV[ dpy self thermometer with pos get endwith >r - >r 4 r@ 2+ steps 1 r> 1+ home! path 0 r@ to 2 0 to 0 r> negate to fill ]CV $20 $1 *hfil $C8 $1 *vfil ^ canvas new dup ^^ with bind temp endwith 
        ^^ &99 SC[ temp draw ]SC ^ vscaler new dup ^^ with bind pos endwith 
          $10 $1 *hfil $10 $1 *vfill ^ glue new dup ^^ with bind (glue-00) endwith 
          ^^ S[ close ]S s"  OK " ^ button new dup ^^ with bind (button-01) endwith 
          $10 $1 *hfil $10 $1 *vfill ^ glue new dup ^^ with bind (glue-02) endwith 
        3 ^ vabox new
      3 ^ habox new 1 hskips
    ( [dumpend] ) } 1 0 ^ modal new 0 hskips 0 vskips s" Temperature" assign ;
class;

script? [IF]  thermometer modal-open bye  [THEN]
