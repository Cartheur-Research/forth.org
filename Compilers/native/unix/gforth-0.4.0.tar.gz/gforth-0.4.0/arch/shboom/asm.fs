\ asm.fs

\ this is only a "fake" assebmler for the shboom

include asm/basic.fs

