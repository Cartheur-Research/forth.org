/*     system.c             Misc Unix system calls
 *                          fork(), pipe() and wait(), access to errno
*/

#include <stdio.h>
#include <errno.h>
#include <sys/wait.h>

Code(get_errno)
{
     sp -= 1;
     sp[0] = errno;
}

Code(pipe_call)         /* ( -- rd wr flag ) */
{
     int pfd[2];
     int retval = pipe( pfd );
   
     sp -= 3;
     sp[0] = retval;
     sp[1] = pfd[1];     /* the write end of pipe */
     sp[2] = pfd[0];     /* read end of pipe */
   
}

Code(fork_call)
{
     int retval = fork();
     sp -= 1;
     sp[0] = retval;
}

Code(wait_call)             /* ( -- child status ) */
{
        int status;
        int child = wait( &status );
   
        sp -= 2;
        sp[0] = status;
        sp[1] = child;
}

