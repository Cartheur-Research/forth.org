/*
 * This file is part of the portable Forth environment written in ANSI C.
 * Copyright (C) 1994  Dirk Uwe Zoller
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 * This file is version 0.9.9 of 05-Nov-94
 * Check for the latest version of this package via anonymous ftp at
 *	roxi.rz.fht-mannheim.de:/pub/languages/forth/pfe-VERSION.tar.gz
 * or	sunsite.unc.edu:/pub/languages/forth/pfe-VERSION.tar.gz
 * or	ftp.cygnus.com:/pub/forth/pfe-VERSION.tar.gz
 *
 * Please direct any comments via internet to
 *	duz@roxi.rz.fht-mannheim.de.
 * Thank You.
 */
/*
 * yours.c ---	This file is the place to add any primitives you might wish.
 * (duz 24Feb94)

   rcsid: @(#)yours.c	1.3 17:39:15 11/17/94   EFC

 */

#include "forth.h"
#include "support.h"

extern char* getenv(char* name);

Code (user_added_primitive)
{
  outs ("\nThis is a sample primitive."
	" See src/yours.c for it's definition.\n");
}

Code (GetEnv)
{
  sp[1] = (Cell)getenv( (char *)sp [1] );
  if ( sp[1] )
     sp[0] = strlen( (char *)sp[1] );
  else
     sp[0] = 0;
}


#ifdef TCP

/* sopen.c	         tcp_open(), udp_open() and resolve_name()

	does all the dirty work in opening a socket on a (possibly) remote
	system.


	tcp_open()           For TCP connections

	three input parameters:
		hostname	-- the name (or inet addr) of the remote end
		                       of the socket
		port		-- the remote port socket number
	                           if >= 0, use port# of service
                                   if < 0,  bind a local reserved port
                                   if > 0,  this is the port# (host byte order)
				            of server
		service         -- the service to connect to, can be NULL
                                   if port > 0
		kind		-- = 0 for clients, = 1 for servers
		                     clients call connect()
				     servers call bind()

	returns:
		< 0		if an error
		fd ( > 0)	the file discriptor for a successful open



       udp_open()             For UDP connections

         host          name of other system to communicate with
	 port          if >= 0, use port# of service
                       if > 0,  this is the port# (host byte order) of server
         service       name of service being requested, can be NULL iff port > 0
	 dontconn      if == 0, call connect(), else don't


	returns:
		< 0		if an error
		fd ( > 0)	the file discriptor for a successful open




           This code is partly based upon code in:


           W. Richard Stevens, 1990; Unix Network Programming,
           Prentice-Hall, Englewood Cliffs, N.J., 772 pages


*/

static char rcsid[] = "@(#)sopen.c	1.6 17:17:29 2/15/93   EFC";

#include <stdio.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <errno.h>
#include <netdb.h>


#include "sopen.h"


#define CLIENT		0
#define SERVER		1

/* define SILENT to be either 0 or 1 */

#define SILENT          0

extern int errno, h_errno;


struct sockaddr_in sinhim = { AF_INET };

struct sockaddr_in       udp_srv_addr;
struct sockaddr_in       udp_cli_addr;


#ifdef NO_PROTO
int tcp_open(hostname,port,service,kind)
char *hostname, *service;
int port, kind;
#else
int tcp_open(char* hostname, int port,char* service, int kind)
#endif
{
	struct hostent *hp;
	struct servent *sp;
	int resvport;
	int fd = 0;

        bzero( (char *)&sinhim, sizeof(sinhim));
        sinhim.sin_family = AF_INET;

        if ( service != NULL )
        {
             if ( (sp = getservbyname( service, "tcp" )) == NULL )
             {
#if  (SILENT == 0)
                        perror( "tcp_open: unknown service");
#endif
                        return -1;
             }


             if ( port > 0 )
                    sinhim.sin_port = htons( port );  /* callers value */
             else
                    sinhim.sin_port = sp->s_port;     /* services value */

        }
        else
        {
             if ( port <= 0 )
             {
#if (SILENT == 0)
                   perror( "tcp_open: must specify either service or port" );
#endif
                   return -2;
             }
             sinhim.sin_port = htons( port );
        }


	if (hostname != NULL)
	{
		if ( resolve_name( hostname, &hp, SILENT ) )
			return -3;

	     bcopy ( hp->h_addr, &sinhim.sin_addr, sizeof (sinhim.sin_addr) );

             /* some systems need to do it this way, not sure what ones though */
     /*
	     bcopy (&(hp->h_addr), &sinhim.sin_addr,sizeof( sinhim.sin_addr) );
     */

	}



	if (port >= 0 )
	{
	    if ( (fd = socket( AF_INET, SOCK_STREAM, 0)) < 0)
	    {
#if (SILENT == 0)
		perror("tcp_open: socket");
#endif
		return -4;
	    }
         }
         else if ( port < 0 )
         {
              resvport = IPPORT_RESERVED - 1;
              if ( (fd = rresvport(&resvport)) < 0 )
              {
#if (SILENT == 0)
                  perror("tcp_open: can't get a reserved TCP port" );
#endif
                  return -7;
              }
         }



	if (kind == CLIENT)
	{
		if (connect(fd, &sinhim, sizeof(sinhim)) < 0)
		{
#if (SILENT == 0)
			perror("tcp_open: connect");
#endif
			return -5;
		}
	}
	else 	/* assume kind == SERVER */
	{
		if ( bind(fd, &sinhim, sizeof(sinhim) ) < 0)
		{
#if (SILENT == 0 )
			perror("tcp_open: bind");
#endif
			return -6;
		}


	}


	return fd;
}



#ifdef NO_PROTO
int udp_open(hostname, port, service, dontconn)
char *hostname;
int port;
char *service;
int dontconn;
#else
int udp_open(char *hostname, int port, char* service, int dontconn)
#endif
{
       int fd;
       unsigned long inaddr;
       struct servent *sp;
       struct hostent *hp;

        bzero( (char *)&udp_srv_addr, sizeof(udp_srv_addr));
        udp_srv_addr.sin_family = AF_INET;


        if ( service != NULL )
        {
             if ( (sp = getservbyname( service, "udp" )) == NULL )
             {
#if  (SILENT == 0)
                        perror( "udp_open: unknown service");
#endif
                        return -1;
             }


             if ( port > 0 )
                    udp_srv_addr.sin_port = htons( port );  /* callers value */
             else
                    udp_srv_addr.sin_port = sp->s_port;     /* services value */

        }
        else
        {
             if ( port <= 0 )
             {
#if (SILENT == 0)
                   perror( "udp_open: must specify either service or port" );
#endif
                   return -2;
             }
             udp_srv_addr.sin_port = htons( port );
        }


	if (hostname != NULL)
	{
		if ( resolve_name( hostname, &hp, SILENT ) )
			return -3;

	     bcopy ( hp->h_addr, &udp_srv_addr.sin_addr, sizeof (udp_srv_addr.sin_addr) );

             /* some systems need to do it this way, not sure what ones though */
     /*
	     bcopy (&(hp->h_addr), &udp_srv_addr.sin_addr,sizeof( udp_srv_addr.sin_addr) );
     */

	}



       if ( port < 0 )
       {
#if (SILENT == 0)
	 perror( "udp_open: reserved ports not implemented yet." );
#endif
	 return -7;
        }


        if ( (fd = socket(AF_INET, SOCK_DGRAM, 0)) < 0)
        {
#if (SILENT == 0)
                 perror("udp_open: can't create UDP socket" );
#endif
                 return -4;
        }


       if ( hostname != NULL )     /* presumably this means that this is a client */
       {
	 /* bind any local address */
	 bzero( (char *)&udp_cli_addr, sizeof(udp_cli_addr));
	 udp_cli_addr.sin_family = AF_INET;
	 udp_cli_addr.sin_addr.s_addr = htonl( INADDR_ANY );
	 udp_cli_addr.sin_port = htons( 0 );



       if ( bind( fd, (struct sockaddr *)&udp_cli_addr, sizeof(udp_cli_addr)) < 0)
       {
	          close( fd );
#if (SILENT == 0)
	          perror( "udp_open: bind error" );
#endif
		  return -6;
       }

       }
       else                /* this must be a server */
       {

	 /* bind server address */

       if ( bind( fd, (struct sockaddr *)&udp_srv_addr, sizeof(udp_srv_addr)) < 0)
       {
	          close( fd );
#if (SILENT == 0)
	          perror( "udp_open: bind error" );
#endif
		  return -8;
       }


       }


       /* This is usually used by most callers since the peer
          usually won't change.  By calling connect() the caller can use send()
          and recv(), otherwise sendto() and recvfrom() are necessary.
       */

       if ( dontconn == 0 )
       {
	   if ( connect(fd, &udp_srv_addr, sizeof( udp_srv_addr )) < 0 )
	   {
#if (SILENT == 0 )
	                perror( "udp_open: connect error" );
#endif
			return -5;
	    }

       }

       return( fd );


}




#ifdef NO_PROTO
int resolve_name(hname, ph, silent)
char* hname;
struct hostent **ph;
int silent;
#else
int resolve_name(char* hname, struct hostent **ph, int silent)
#endif
{
    long addr;

        if (isdigit(hname[0]))
        {
            addr = inet_addr(hname);
            *ph = gethostbyaddr(&addr, 4, AF_INET);
        }
        else
            *ph = gethostbyname(hname);

        if (*ph == (struct hostent *)NULL)
        {

	  if ( silent == 0 )
	    {
#ifdef BSD42
            fprintf(stderr,"host %s not found\n", hname);
#else
            switch (h_errno) {
                case HOST_NOT_FOUND: fprintf(stderr,"host %s not found\n", hname);
                                     break;
                case TRY_AGAIN: fprintf(stderr,"Try again later\n");
                                break;
                case NO_RECOVERY: fprintf(stderr,"No recovery possible\n");
                                  break;
                case NO_ADDRESS: fprintf(stderr,"No IP address\n");
                                 break;
                default: fprintf(stderr,"Unknown error: %d\n", h_errno);
                         break;
            }
#endif
	  }

            return 1;
        }

        (*ph)->h_addr[ (*ph)->h_length ] = NULL;

        return 0;
}

#undef CLIENT
#undef SERVER

#endif

/* filehdl.m4       Code for open, close, write, read  which access the
                    low level system I/O

	This file also implements interfaces to the following for TCP/IP
	I/O, if the token TCP_IP is defined


		LISTEN, ACCEPT (defined as SOCKET-ACCEPT to avoid
		a confict with Forth's ACCEPT) and my TCP/IP socket
		open routine SOPEN


                      (c) Copyright 1994, Everett F. Carter Jr.
                      Permission is granted by the author to use
		      this software for any application provided this
		      copyright notice is preserved.


*/

static char rcsid1[] = "@(#)filehdl.m4	1.4 14:18:37 9/30/94   EFC";




#include <stdio.h>
#include <ctype.h>
#include <errno.h>

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <fcntl.h>

char name[256];

/* Usage:	s" fname" int_mode open, returns fh on success -1 on failure */
Code (Open)
{
  char *fn = (char *)sp [2];    /* c-addr, name */
  uCell u = sp [1];             /* length of name */
  Cell fam = sp [0];            /* file access mode */
  int fid;

  if ( u > 0 )
    memcpy (name, fn, u);
  name[u] = '\0';

  fid = open( name, fam);
  sp += 2;
  sp[0] = (Cell)fid;
}

Code (Open_Create)
{

  char *fn = (char *)sp [3];    /* c-addr, name */
  uCell u = sp [2];             /* length of name */
  Cell flags = sp[1];
  Cell fam = sp [0];            /* file access mode */
  int fid;

  if ( u > 0 )
    memcpy (name, fn, u);
  name[u] = '\0';

  fid = open( name, flags | O_CREAT, fam);
  sp += 3;
  sp[0] = (Cell)fid;

}


Code(Close)
{
	sp[0] = (Cell)close( sp[0] );
}

Code(Write)
{
        char *c_addr = (char *)sp[2];
        uCell u = sp[1];
        Cell  fid = sp[0];

	sp += 2;
	sp[0] = (Cell)write( fid, c_addr, u );
}


Code(Read)
{
        char *c_addr = (char *)sp[2];
        uCell u = sp[1];
        Cell  fid = sp[0];

	sp += 2;
	sp[0] = (Cell)read( fid, c_addr, u );

}


#ifdef __SC__
typedef long off_t;
#endif

Code(Lseek)
{
        off_t offset;
        int   fh, whence;
        
	whence = sp[1];
        offset = (off_t) sp[2];         /* NOTE: ASSUMES off_t FITS IN ONE CELL!! */
	fh = sp[0];

	sp += 2;
	sp[0] = (off_t)lseek( fh, offset, whence );

}

#ifdef TCP

Code(Sopen)
{
  Cell kind = sp[0];
  Cell port = sp[1];
  char *fn = (char *)sp [3];    /* c-addr, name */
  uCell u = sp [2];             /* length of name */


  if ( u > 0 )
    memcpy (name, fn, u);
  name[u] = '\0';

  sp += 3;


	if ( u > 0 )
	sp[0] = (Cell)tcp_open( name, port, (char *)NULL, kind );
	else
	sp[0] = (Cell)tcp_open( (char *)NULL, port, (char *)NULL, kind );
}


Code(Listen)
{
	int backlog, fh;

	backlog = sp[1];
	fh   = sp[0];

	sp += 1;
	sp[0] = (Cell)listen( fh, backlog );
}

Code(Socket_Accept)
{
	int fh, alen;
	struct sockaddr *addr;

	alen = sp[1];
	addr  = (struct sockaddr *)sp[2];
	fh   = sp[0];

	sp += 2;
	sp[0] = (Cell)accept( fh, addr, &alen );

	/* S[-1] = alen; */
}


#endif


#ifdef USE_XDR

/* xdr.m4         Code to interface with XDR



                      (c) Copyright 1994, Everett F. Carter Jr.
                      Permission is granted by the author to use
                      this software for any application provided this
                      copyright notice is preserved.

*/

static char rcsid_xdr[] = "@(#)xdr.m4	1.2 15:28:32 9/29/94   EFC";

#include <fcntl.h>
#include <rpc/rpc.h>

#ifdef CRAY
#define char_type   signed char
#else
#define char_type   char
#endif

static XDR xdrs[2];

/* initialize the XDR buffer and associate it with the specified buffer */
Code(XDR_Buffer_Init)
{
	u_int size;
	char *addr;
	enum xdr_op op;
	int idx;

	op = sp[0];
	size = sp[1];
	addr  = (char *)sp[2];

	sp += 3;

	if ( op == XDR_ENCODE )
		idx = 0;
	else
		idx = 1;

	xdrmem_create( &xdrs[idx], addr, size, op );


}

Code(XDR_Rewind)      /* rewind XDR buffer for READERS ONLY */
{
	xdr_setpos( &xdrs[1], 0 );

}


/* Conversions between XDR and ThisForth native data types */

Code(XDR2L)      /* convert from XDR to LONG INT */
{
	long int i;

	xdr_long( &xdrs[1], &i );
	xdr_setpos( &xdrs[1], 0 );

	*--sp = (Cell)i;

}


Code(L2XDR)      /* convert from INT to XDR */
{
	long int i;

	i = sp[0];
	sp++;

	xdr_setpos( &xdrs[0], 0 );
	xdr_long( &xdrs[0], &i );

}


Code(XDR2UL)      /* convert from XDR to UNSIGNED LONG INT */
{
	unsigned long int i;

	xdr_u_long( &xdrs[1], &i );
	xdr_setpos( &xdrs[1], 0 );

	*--sp = (Cell)i;

}


Code(UL2XDR)      /* convert from UNSIGNED LONG INT to XDR */
{
	unsigned long int i;

	i = (unsigned long int)sp[0];
	sp++;

	xdr_setpos( &xdrs[0], 0 );
	xdr_u_long( &xdrs[0], &i );

}

Code(XDR2F)      /* convert from XDR to DOUBLE FLOAT */
{
	double x;

	xdr_double( &xdrs[1], &x );
	xdr_setpos( &xdrs[1], 0 );

	*--fp = x;

}

Code(F2XDR)      /* convert from DOUBLE FLOAT to XDR */
{
	double x;

	x = fp[0];
	fp++;

	xdr_setpos( &xdrs[0], 0 );
	xdr_double( &xdrs[0], &x );

}

Code(XDR2STR)      /* convert from XDR to Forth string */
{                         
	char *spp;
	u_int sizep, maxsize;

	sizep = maxsize = sp[0] + sizeof( u_int );
	spp  = (char *)sp[1];

	xdr_bytes( &xdrs[1], &spp, &sizep, maxsize );
	xdr_setpos( &xdrs[1], 0 );

	sp[0] = sizep - sizeof( u_int );
}


Code(STR2XDR)      /* convert from Forth string to XDR */
{
	char *spp;
	u_int sizep, maxsize;

	sizep = maxsize = sp[0] + sizeof( u_int );
	spp  = (char *)sp[1];

	xdr_setpos( &xdrs[0], 0 );
	xdr_bytes( &xdrs[0], &spp, &sizep, maxsize );

	sp++;
	sp[0] = sizep;

}


/* conversions between XDR and non-ThisForth data types, converted to/from
   corresponding ThisForth data types */

Code(XDR2C)      /* convert from XDR to CHAR */
{
	char c;

	xdr_char( &xdrs[1], &c );
	xdr_setpos( &xdrs[1], 0 );

	*--sp = (Cell)c;

}

Code(C2XDR)      /* convert from CHAR to XDR */
{
	char c;

	c = (char)sp[0];
	sp++;

	xdr_setpos( &xdrs[0], 0 );
	xdr_char( &xdrs[0], &c );

}

Code(XDR2I)      /* convert from XDR to INT */
{
	int i;

	xdr_int( &xdrs[1], &i );
	xdr_setpos( &xdrs[1], 0 );

	*--sp = (Cell)i;

}

Code(I2XDR)      /* convert from INT to XDR */
{
	int i;

	i = (int)sp[0];
	sp++;

	xdr_setpos( &xdrs[0], 0 );
	xdr_int( &xdrs[0], &i );

}

Code(XDR2UI)      /* convert from XDR to UNSIGNED INT */
{
	unsigned int i;

	xdr_u_int( &xdrs[1], &i );
	xdr_setpos( &xdrs[1], 0 );

	*--sp = (Cell)i;

}

Code(UI2XDR)      /* convert from UNSIGNED INT to XDR */
{
	unsigned int i;

	i = (unsigned int)sp[0];
	sp++;

	xdr_setpos( &xdrs[0], 0 );
	xdr_u_int( &xdrs[0], &i );

}

Code(XDR2SI)      /* convert from XDR to SHORT INT */
{
	short int i;

	xdr_short( &xdrs[1], &i );
	xdr_setpos( &xdrs[1], 0 );

	*--sp = (Cell)i;

}

Code(SI2XDR)      /* convert from SHORT INT to XDR */
{
	short int i;

	i = (short int)sp[0];
	sp++;

	xdr_setpos( &xdrs[0], 0 );
	xdr_short( &xdrs[0], &i );

}

Code(XDR2SF)      /* convert from XDR to SINGLE FLOAT */
{
	float x;

	xdr_float( &xdrs[1], &x );
	xdr_setpos( &xdrs[1], 0 );

	*--fp = x;

}


Code(SF2XDR)      /* convert from SINGLE FLOAT to XDR */
{
	float x;

	x = fp[0];
	fp++;

	xdr_setpos( &xdrs[0], 0 );
	xdr_float( &xdrs[0], &x );

}


Code(XDR2CSTR)      /* convert from XDR to C string */
{                         
	char *spp;
	u_int maxsize;


	maxsize = sp[0] + sizeof( u_int );
        spp = name;

        /* note: presumes that name is big enough */
	xdr_string( &xdrs[1], &spp, maxsize + 1 );
	xdr_setpos( &xdrs[1], 0 );

	maxsize = strlen( name );


	/* convert NUL-terminated string to Forth string */
        memcpy ( (char *)sp[1], name, maxsize);

	sp[0] = maxsize;         /* return actual count */
}

Code(CSTR2XDR)      /* convert from C string to XDR */
{
        char *spp;
	u_int maxsize;
	maxsize = sp[0];

        spp = name;

	/* Make NUL-terminated string, presumes name is big enough */
        memcpy( name, (char *)sp[1], maxsize );
        name[ maxsize ] = '\0';

	xdr_setpos( &xdrs[0], 0 );
	xdr_string( &xdrs[0], &spp, maxsize + 1 );

	++sp;
	sp[0] = strlen( name ) + sizeof( u_int ) + 1;
}

#endif


LISTWORDS (your) =
{
  CO ("USER-ADDED-PRIMITIVE", user_added_primitive),
  CO ("GETENV", GetEnv),
  CO ("OPEN", Open),
  CO ("OPEN-CREATE", Open_Create),
  CO ("CLOSE", Close),
  CO ("WRITE", Write),
  CO ("READ", Read),
  CO ("LSEEK", Lseek),
#ifdef TCP
  CO ("SOPEN", Sopen),
  CO ("LISTEN", Listen),
  CO ("SOCKET-ACCEPT", Socket_Accept),
#endif
#ifdef USE_XDR
  CO ("XDR-BUFFER-INIT", XDR_Buffer_Init),
  CO ("XDR-REWIND", XDR_Rewind),
  CO ("XDR->L",    XDR2L),
  CO ("L->XDR",    L2XDR),
  CO ("XDR->UL",   XDR2UL),
  CO ("UL->XDR",   UL2XDR),
  CO ("XDR->F",    XDR2F),
  CO ("F->XDR",    F2XDR),
  CO ("XDR->STR",  XDR2STR),
  CO ("STR->XDR",  STR2XDR),
  CO ("XDR->C",    XDR2C),
  CO ("C->XDR",    C2XDR),
  CO ("XDR->I",    XDR2I),
  CO ("I->XDR",    I2XDR),
  CO ("XDR->UI",   XDR2UI),
  CO ("UI->XDR",   UI2XDR),
  CO ("XDR->SI",   XDR2SI),
  CO ("SI->XDR",   SI2XDR),
  CO ("XDR->SF",   XDR2SF),
  CO ("SF->XDR",   SF2XDR),
  CO ("XDR->CSTR", XDR2CSTR),
  CO ("CSTR->XDR", CSTR2XDR),
#endif
};
COUNTWORDS (your, "Your kernel extensions");
