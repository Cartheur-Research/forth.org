/*
|	FILE: OUTER.C
|
|	This module contains copyrighted source code for part the 
|	UNTIL Language Materials. 
|
|	Written by:
|		Norman E. Smith, CDP
|		Copyright 1992, 1994
|		All Rights Reserved
|
|	Right to use, copy, and modify this code is granted
|	for personal non-commercial use, provided that this
|	copyright disclosure remains on ALL copies. Any other
|	use, reproduction, or distribution is covered in the
|	License Agreement with the Until Language Maeterials
|	documentation and in the file LICENSE.TXT.
|
|	DATE		COMMENT
|	01/16/95	Made cleanup changes suggested by Akira Kida,
|			akida@isd.hin.konica.co.jp. [nes]
*/

#include "compiler.h"

#include <stdio.h>

#ifdef ANSIC
#include <process.h>
#include <conio.h>
#endif

#include "until.h"
#include "functs.h"

/***********************+---------+
|                       | startup |
|                       +---------+
*/
void startup()
{
	long len;
#ifdef REPORT_STARTUP_ERRS
	long success;
#endif
	cold();
		/*
		| These two file things must be done in reverse order
		| because the last autoloaded file is the first one
		| processed.
		*/
	len = strlen(autoload);
	if(len){
#ifdef REPORT_STARTUP_ERRS
		success = do_autoload(autoload,SOURCE);
		if(!success){
			printf("startup() Error-default application file not found: %s\n",autoload);
		}
#else
		do_autoload(autoload,SOURCE);
#endif
	}
	len = strlen(binload);
	if(len){
#ifdef REPORT_STARTUP_ERRS
		success = do_autoload(binload,BIN);
		if(!success){
			printf("startup() Error-default binary file not found: %s\n",binload);
		}
#else
		do_autoload(binload,BIN);
#endif
	}
		/*
		| Boot to application word
		*/
	len = strlen(boot_word);
	if(len){
		strcpy((pad + 1),boot_word);
		*pad   = len;
		exec_word();
	}else{
		outer();
	}
}
/***********************+-------+
|			| outer |
|			+-------+
|
|	This is the outer interpreter. It seems too simple.
|
*/
void outer()
{
	static started;
	int    found;

	started = TRUE;
/*
	QUIT = 0;
*/
	FOREVER{
	  if(QUIT){
		return;		        /* Initialization */
	  }else{
		warm();
	  }
	  do{
		pushsp(BLANK);
		word();			/* get next word from input stream */
		minus_find();		/* Look it up in the dictionary */
		found = popsp();
		if(found){		/* found the word */
			WA = (struct DictHeader*) popsp();
			(*WA->CFA)();
		}else{		        /* Word not found, so try to turn */
			drop();		/*   it into a number. */
			pushsp((long)pad);       /* Word leaves string at pad */
			number();	/* Convert it to int. */
		}
		if(show_stack){
			gdot_s();
		}
	  }while(!ABORT_FLAG);
		/*
		| If loading from a file, back up a level. This
		| should get us back to STDIN...
		*/
	  if(INPUT_SOURCE){
		close_include();
	  }
	  ABORT_FLAG = 0;
	}
}
/***********************+----------------+
|			| set_show_stack |
|			+----------------+
|	show_stack	( tf --- )
*/
void set_show_stack()
{
	show_stack = popsp();
}
