\ automatic generated code
\ do not edit
windows also forth

window class calc
public:
  early open
  early modal-open
  infonumberfield ptr a#
  infonumberfield ptr b#
  | button ptr (button-00)
  | button ptr (button-01)
  | button ptr (button-02)
  | button ptr (button-03)
  | button ptr (button-04)
  | button ptr (button-05)
  | button ptr (button-06)
  infonumberfield ptr r#
how:
  : open       screen self new >o map o> ;
  : modal-open screen self new >o map stop o> ;
class;

calc implements
  : init  super init ^ { ^^ | ( [dumpstart] )
        &12341234. ]N s" A:" ^ infonumberfield new dup ^^ with bind a# endwith 
        &1234. ]N s" B:" ^ infonumberfield new dup ^^ with bind b# endwith 
          ^^ S[ a# get b# get d+ r# assign ]S s" +" ^ button new dup ^^ with bind (button-00) endwith 
          ^^ S[ a# get b# get d- r# assign ]S s" -" ^ button new dup ^^ with bind (button-01) endwith 
          ^^ S[ a# get b# get d* r# assign ]S s" *" ^ button new dup ^^ with bind (button-02) endwith 
          ^^ S[ a# get b# get drop ud/mod r# assign drop ]S s" /" ^ button new dup ^^ with bind (button-03) endwith 
          ^^ S[ a# get 1. b# get drop 0 ?DO 2over d* LOOP 2swap 2drop r# assign ]S s" ^" ^ button new dup ^^ with bind (button-04) endwith 
          ^^ S[ r# get a# assign ]S s" >A" ^ button new dup ^^ with bind (button-05) endwith 
          ^^ S[ r# get b# assign ]S s" >B" ^ button new dup ^^ with bind (button-06) endwith 
        7 ^ hatbox new 1 hskips
        &12340000. ]N s" R:" ^ infonumberfield new dup ^^ with bind r# endwith 
      4 ^ vabox new panel
    ( [dumpend] ) } 1 0 ^ modal new 0 hskips 0 vskips s" Calculator" assign ;
class;

script? [IF]
  calc modal-open
bye [TNEN]
