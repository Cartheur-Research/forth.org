
/*
 * config.h --	manual changed file for C++Builder
 */

#ifndef __CONFIG_H
#define __CONFIG_H

#define HOST_SYSTEM "Win32 Borland C++Builder"
/* #define UNROLL_NEXT : dont use this optimization under CBUILDER, it is slower ! */
#define CBUILDER 1
#define DOS_FILENAMES 1
#define IBMPC_CHARSET 1
#define HAVE_SYS_TYPES_H 1
/* #define WC_WINDOWS 1 */
/* #define HAVE_SYS_IOCTL_H 1 */
#define HAVE_FCNTL_H 1
#define HAVE_SYS_STAT_H 1
/* #define HAVE_SYS_TIME_H 1 */
/* #define HAVE_SYS_UTIME_H 1*/
#define HAVE_PROCESS_H 1
#define HAVE_SYS_PROCESS_H 1
/* #define HAVE_UNISTD_H 1 */
#define HAVE_IO_H 1
#define HAVE_DOS_H 1
#define HAVE_MEMORY_H 1
/* #define HAVE_STRINGS_H 1 */
#define HAVE_GETOPT_H 1
/*#define HAVE_LIBC_H 1 */
#define HAVE_DOS_H 1
#define HAVE_LOCALE_H 1
#define HAVE_TERMIOS_H 1
#define HAVE_TERMIO_H 1
#define HAVE_SGTTY_H 1
/* #define HAVE_TERMCAP_H 1 */
#define HAVE_CONIO_H 1
#define eXit(X) exit(X)
/* #define HAVE_RANDOM 1 */ 
double acosh (double);
double asinh (double);
double atanh (double);
#define HAVE_MEMMOVE 1
#define HAVE_STRDUP 1
#define HAVE_REMOVE 1
#define HAVE_RENAME 1
#define HAVE_ACCESS 1
#define HAVE_STAT 1
#define HAVE_FSTAT 1
#define HAVE_FILENO 1
/* #define HAVE_TRUNCATE 1 */
/* #define HAVE_UMASK 1 */
 #define HAVE_PID 1
/* #define HAVE_UID 1 */

/* #define HAVE_GID 1 */
/* #define HAVE_SELECT 1 */
#define HAVE_RAISE 1
#define HAVE_OSPEED 1
#define CELL_TYPE int
#define HALF_CELL_TYPE short
#define HIGHBYTE_FIRST 0
#define CELLSIZE 4
#define SFLOATSIZE 4
#define DFLOATSIZE 8
#define CELL_ALIGN 4
#define SFLOAT_ALIGN 4
#define DFLOAT_ALIGN 4
#define KEEPS_SIGNALS 1
#endif
