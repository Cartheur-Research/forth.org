( Forth code obfuscator )

\ gfob - Forth code obfuscator for Gforth
\ Copyright 1999 Pierre Henri Michel., Abbat
\
\ This program is free software; you can redistribute it and/or modify
\ it under the terms of the GNU General Public License as published by
\ the Free Software Foundation; either version 2 of the License, or
\ (at your option) any later version.
\    
\ This program is distributed in the hope that it will be useful,  
\ but WITHOUT ANY WARRANTY; without even the implied warranty of
\ MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
\ GNU General Public License for more details.
\
\ You should have received a copy of the GNU General Public License 
\ along with this program; if not, write to the Free Software
\ Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

marker -obfuscator-

true constant saving
false constant debugging
0 value symtablestart1
0 value symtablestart2
0 value symtablestart3
variable xpos
variable in-def ( used to prevent executing creators within colon-defs )
variable linewidth
100 linewidth !
variable nobreak ( prevents breaking lines )

: uplinewidth
  200 linewidth ! ;

: downlinewidth
  linewidth @ 33 - 100 max linewidth ! ;

: .err ( addr len )
  stderr write-file drop ;

: .errln ( addr len )
  stderr write-line drop ;

: .dbg ( addr len )
  debugging if
    .err
  else
    2drop
  then ;

: .dbglf ( addr len )
  debugging if
    .errln
  else
    2drop
  then ;

: (.word) ( addr len )
  xpos @ linewidth @ > nobreak @ 0= and if
    cr xpos off
  then
  dup 1+ xpos +!
  nobreak @ if
    -1 nobreak +!
  then
  type ;

: .word ( addr len )
  (.word) space ;

: in-symbol-table ( addr len - addr len 0 | xt -1 )
  2dup sfind if
    dup
    in-def @ if 
      dup symtablestart3 u>= swap symtablestart1 symtablestart2 within or 
    else
      symtablestart1 u>=
    then if
      nip nip -1
    else
      drop 0
    then
  else
    0
  then ;

: ob-word ( addr len )
  2dup .dbg
  in-symbol-table if
    execute
    s"  executed" .dbglf
  else
    .word
    s"  passed through" .dbglf
  then ;

variable symcount

: newsymbol ( - addr len )
  base @ 42 base !
  symcount @ 0 <# #s [char] ~ hold #>
  1 symcount +!
  rot base ! ;

: ,$ ( addr count )
( count should be less than 256 )
  dup c,
  bounds do i c@ c, loop
  align ;

: (new-obfuscated-word) ( -<word>- - addr len )
( Creates a word with the name of a cleartext word, which, when executed,
  outputs the word's obfuscated symbol. Returns the obfuscated symbol. 
  If the previously defined word with the same name is immediate,
  it does not obfuscate. )
  header dovar: cfa, ( create without reveal )
  last @ name>string 2dup forth-wordlist search-wordlist
  dup if nip then ( discard the address )
  0> if
    ( the word was immediate, so this one is public )
  else 
    2drop newsymbol
  then
  2dup ,$
  does> count 2dup .dbg s"  created" .dbglf .word ;

: new-obfuscated-word ( -<word>- - addr len )
  (new-obfuscated-word) reveal ;

false value finished

: obfuscate-line
  begin
    name dup while
    ob-word
  repeat 2drop ;

0 value eolchar ( set to 10 or 13, whichever is encountered first )

: eol ( c - ? )
  eolchar if
    eolchar =
  else
    dup 10 = over 13 = or tuck and to eolchar
  then ;

: getline
( Gets a line with no editing and no echo. Used in filters. )
  0 tib /line bounds do
    key dup eol if
      drop 0 i c! leave
    else
      dup 4 = over 0< or if 
        true to finished 
        drop 0 i c! leave
      then
      eolchar 0= over eolchar + 23 <> or if ( ignore lf if cr is eolchar )
        i c! 1+
      then
    then
  loop
  #tib ! 0 >in ! ;

: version ( - addr len )
  s" 0.1.0" ;

: .copr
  s" Gfob " .err version .err s"  � 1999 Pierre Abbat" .errln
  s" Source code obfuscator for Gforth" .errln
  s" Distributed under the GNU GPL" .errln ;

: obfuscate
  saving if
    init8 chainperform
  then
  false to finished
  .copr
  begin
    getline obfuscate-line
  finished until 
  saving if bye then ;

: creator
( Defines a word as a defining word, so that the next word after any
  occurrence of it will be entered into the symbol table. )
  create
  does> body> >name name>string .word ( output the creator's own name )
  1 nobreak +! ( don't break the line at this point )
  new-obfuscated-word .word ;

: code-creator
( Defines a word as a defining word, so that the next word after any
  occurrence of it will be entered into the symbol table, but not
  revealed until a code-revealer is executed. )
  create
  does> body> >name name>string .word ( output the creator's own name )
  1 nobreak +! ( don't break the line at this point )
  (new-obfuscated-word) .word 
  in-def on s" in-def on" .dbg ;

: stringer
( Defines a word as a string word, such as s" . Anything after it
  until the next " is passed through. )
  create
  does> body> >name name>string .word ( output the stringer's own name )
  1 nobreak +! ( don't break the line at this point )
  34 parse (.word) 34 emit space 1 xpos +! ;

: revealer
( Defines a word as a word which reveals the last word defined. )
  create
  does> body> >name name>string .word ( output the revealer's own name )
  reveal in-def off s" in-def off" .dbg ;

: public-error
( Must be defined here, as public is defined after abort" is redefined. )
\ comment for public:
\ Defines a word as public. The next time it is created, the creator will
\ define it to give its own name, not an obfuscation.
  true abort" Public word used before being defined" ;

here to symtablestart1

: (
  BEGIN
    >in @ 41 parse nip >in @ rot - =
    finished 0= and
  WHILE
    getline
  REPEAT ; immediate

: .( 
  postpone ( ;

: \
  postpone \ ;

stringer s"
stringer c"
stringer abort"
stringer ."

\ : end
\   true to finished ;

here to symtablestart2

: public
  create immediate
  does> public-error ;

creator create
creator variable
creator 2variable
creator value
creator 2value
creator constant
creator 2constant
code-creator :

here to symtablestart3

revealer ;

saving [if]
' obfuscate is 'cold
savesystem gfob
bye
[then]
