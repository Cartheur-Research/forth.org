// wincon.c
// Andrew McKewan, August 1996

#include <windows.h>
#include <commctrl.h>
#include <stdio.h>

//////////////////////////////////////////////////////////////////////
// Each entry in the list has a link field, name and value.

typedef struct _Entry
{
	struct _Entry *link;
	char *name;
	int value;
} Entry ;

// Add entry to table
#define CONSTANT(x)  {0, #x, (int)x},

// Table of names from generated wincon.i file
Entry entry[] = {
#include "wincon.i"
	{NULL,0}
};

//////////////////////////////////////////////////////////////////////
// Create a hash table of the names for quick lookup.

#define HASHSIZE 2003
Entry *hashTable[HASHSIZE];

unsigned int hash(char *name)
{
	unsigned int h = 0;
	char c;
	while (c = *name++)
		h += c;
	return h % HASHSIZE;
}

void BuildHash()
{
	int i;
	for (i = 0; entry[i].name; i++)
	{
		Entry **bucket = &hashTable[hash(entry[i].name)];
		entry[i].link = *bucket;
		*bucket = &entry[i];
	}
}

void CountHash()	// display results of hashing
{
	int sizes[21];
	int i, n, maxi=0;
	Entry *ep;

	for (i = 0; i < 21; i++)
		sizes[i] = 0;

	for (i = 0; i < HASHSIZE; i++)
	{
		n = 0;
		for (ep = hashTable[i]; ep; ep = ep->link)
			n += 1;
		if (n > 20)
		{	if (n > maxi) maxi = n;	
			n = 20;
		}
		sizes[n] += 1;
	}
		
	for (i = 0; i < 21; i++)
		printf("%2d: %4d\n", i, sizes[i]);
	printf("Max = %d\n", maxi);
}

// Find an entry in the hash table. Return NULL if not found.
Entry *FindHash(char *name)
{
	Entry *ep = hashTable[hash(name)];
	while (ep && strcmp(name, ep->name))
		ep = ep->link;
	return ep;
}

//////////////////////////////////////////////////////////////////////
// Exported function to find a constant. Return TRUE if found,
// and store the value in *value

__declspec(dllexport)
BOOL APIENTRY FindWin32Constant(char *addr, int len, int *value)
{
	char name[256];
	Entry *ep;

	if (len <= 0 || len > 255)
		return FALSE;

	memcpy(name, addr, len);
	name[len] = 0;

	ep = FindHash(name);
	if (!ep) return FALSE;
	*value = ep->value;
	return TRUE;
}

//////////////////////////////////////////////////////////////////////
// Enumeration the constants. The function takes a string and a callback
// procedure. If a constant is found containing the passed-in string,
// call the callback with the full name and value. Return the number
// of constants found

typedef int (WINAPI *ENUMPROC)(char*, int, int);

__declspec(dllexport)
int APIENTRY EnumWin32Constants(char *addr, int len, ENUMPROC callback)
{
	int i, n = 0;
	int all = 0;
	char pattern[256];

	if (len < 0 || len > 255) return 0;
	if (len == 0)
		all = 1;	// show all of then!!
	else
	{
		memcpy(pattern, addr, len);
		pattern[len] = 0;
	}

	for (i = 0; i < HASHSIZE; i++)
	{
		Entry *entry = hashTable[i];
		while (entry)
		{
			if (all || strstr(entry->name, pattern))
			{
				// exit if callback returnes zero
				if (!callback(entry->name, strlen(entry->name), entry->value))
					return n;
				++n;
			}
			entry = entry->link;
		}
	}
	return n;
}

//////////////////////////////////////////////////////////////////////
// DLL main entry point. Initializes the hash table.

BOOL APIENTRY DllMain(HANDLE hModule, DWORD reason, LPVOID lpReserved)
{
    switch (reason)
	{
    case DLL_PROCESS_ATTACH:
		BuildHash();
//		CountHash();
		break;
    case DLL_THREAD_ATTACH:
    case DLL_THREAD_DETACH:
    case DLL_PROCESS_DETACH:
		break;
    }
    return TRUE;
}
