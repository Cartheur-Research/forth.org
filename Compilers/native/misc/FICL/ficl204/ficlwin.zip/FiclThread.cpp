// FiclThread.cpp : implementation file
//

#include "stdafx.h"
#include "ficlwin.h"
#include "ficl.h"
#include "FiclThread.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

static const  UINT UpdateStackMsg = RegisterWindowMessage("ficlstack");
static const  UINT FiclByeMsg =     RegisterWindowMessage("ficlbye");

static const MAX_DEPTH = 10;

// This bool gets set when the user exits with the "bye" command.
// It inhibits stack view updates.
static bool  isQuittingTime = FALSE;

/////////////////////////////////////////////////////////////////////////////
// CFiclThread

IMPLEMENT_DYNCREATE(CFiclThread, CWinThread)

CFiclThread::CFiclThread()
{
    m_pVM = ficlNewVM();
}

CFiclThread::CFiclThread(HWND hWnd)
{
    m_pVM = ficlNewVM();
    m_pVM->pExtend = (void *)hWnd;  // Handle to host view's window
}

CFiclThread::~CFiclThread()
{
}

BOOL CFiclThread::InitInstance()
{
	// TODO:  perform and per-thread initialization here
	return TRUE;
}

int CFiclThread::ExitInstance()
{
	// TODO:  perform any per-thread cleanup here
	return CWinThread::ExitInstance();
}

BEGIN_MESSAGE_MAP(CFiclThread, CWinThread)
	//{{AFX_MSG_MAP(CFiclThread)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
        ON_THREAD_MESSAGE(WM_FICL_EXEC, OnFiclExec)
        ON_THREAD_MESSAGE(WM_FICL_STACK, OnStackReport)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFiclThread message handlers

BOOL CFiclThread::OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo) 
{
	// TODO: Add your specialized code here and/or call the base class
	
	return CWinThread::OnCmdMsg(nID, nCode, pExtra, pHandlerInfo);
}


void CFiclThread::OnFiclExec(WPARAM wParam, LPARAM lParam)
{
    int ret = 0;
    CString *pStr = (CString *)lParam;

    ASSERT(pStr);
    ASSERT(m_pVM);

    &wParam;

	try 
	{
		ret = ficlExec(m_pVM, (char *)(LPCTSTR) *pStr);
		ficlTextOut(m_pVM, NULL, 0);
	}
	catch (...)
	{
		ficlTextOut(m_pVM, "Error: exception", 1);
		vmReset(m_pVM);
	}
    
    delete pStr;

    if (ret == VM_USEREXIT)
    {
	    HWND hView = (HWND)m_pVM->pExtend;
        isQuittingTime = TRUE;
        PostMessage(hView, FiclByeMsg, (WPARAM)0, (LPARAM)0);
    }
    else    // stack report
    {
        OnStackReport(0, 0);
    }

    return;
}


void CFiclThread::OnStackReport(WPARAM wParam, LPARAM lParam)
{
    HWND hView = (HWND)m_pVM->pExtend;
    int depth  = stackDepth(m_pVM->pStack);
    WPARAM wp  = (m_pVM->base << 16) + depth;
    int lim    = (depth > MAX_DEPTH ? MAX_DEPTH : depth);
    CString *pStr = new CString("");

    ASSERT(hView);
    ASSERT(pStr);
    &wParam;
    &lParam;

    if (isQuittingTime)
        return;

    if (depth > 0)
    {
        CELL *pCell = m_pVM->pStack->sp;
        for (int i = 0; i < lim; i++)
        {
            *pStr += (LPCTSTR)ltoa((*--pCell).i, m_pVM->pad, m_pVM->base);
            *pStr += " ";
        }
    }

    // If you make this a SendMessage, it causes problems when the
    // view is destroyed from the file/exit menu - the view becomes
    // active, then gets destroyed, then the send happens to an
    // invalid hwnd...
    PostMessage(hView, UpdateStackMsg, wp, (LPARAM)pStr);
    return;
}

