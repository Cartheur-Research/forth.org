/*******************************************************************
** s o f t c o r e . c
** Forth Inspired Command Language - 
** Words from CORE set written in FICL
** Author: John Sadler (john_sadler@alum.mit.edu)
** Created: 27 December 1997
** Last update: Thu Sep 17 14:13:07 1998
*******************************************************************/
/*
** This file contains definitions that are compiled into the
** system dictionary by the first virtual machine to be created.
** Created automagically by ficl/softwords/softcore.pl 
*/


#include "ficl.h"

static char softWords[] = 
/*
** softcore.fr
** FICL soft extensions
** John Sadler (john_sadler@alum.mit.edu)
** September, 1998
** CORE 
*/
    ": abs   ( x -- x ) \n"
    "    dup 0< if negate endif ; \n"
    "decimal 32 constant bl \n"
    ": space   ( -- )     bl emit ; \n"
    ": spaces  ( n -- )   0 ?do space loop ; \n"
    ": abort\"  \n"
    "    postpone if  \n"
    "    postpone .\"  \n"
    "    postpone cr  \n"
    "    postpone abort  \n"
    "    postpone endif  \n"
    "; immediate  \n"
/*
** CORE EXT
*/
    "0  constant false  \n"
    "-1 constant true  \n"
    ": <>   = invert ;  \n"
    ": 0<>  0= invert ;  \n"
    ": compile,  , ;  \n"
    ": erase   ( addr u -- )    0 fill ;  \n"
    ": nip     ( y x -- x )     swap drop ;  \n"
    ": tuck    ( y x -- x y x)  swap over ;  \n"
/*
** LOCAL EXT word set
*/
#if FICL_WANT_LOCALS
    ": locals|  ( name...name | -- ) \n"
    "    begin \n"
    "        bl word   count \n"
    "        dup 0= abort\" where's the delimiter??\" \n"
    "        over c@ \n"
    "        [char] | - over 1- or \n"
    "    while \n"
    "        (local) \n"
    "    repeat 2drop   0 0 (local) \n"
    "; immediate \n"
    ": local  ( name -- )  bl word count (local) ;  immediate \n"
    ": end-locals  ( -- )  0 0 (local) ;  immediate \n"
#endif
/*
** TOOLS word set...
*/
    ": ?     ( addr -- )  @ . ; \n"
    ": dump  ( addr u -- ) \n"
    "    0 ?do \n"
    "        dup c@ . 1+ \n"
    "        i 7 and 7 = if cr endif \n"
    "    loop drop \n"
    "; \n"
/*
** SEARCH EXT words and ficl helpers
*/
    ": do-vocabulary   ( -- )  \n"
    "    does>  @ search> drop >search ; \n"
    ": vocabulary   ( name -- )  \n"
    "    wordlist create ,  do-vocabulary ;  \n"
    ": also   ( -- )  \n"
    "    search> dup >search >search ;  \n"
    ": forth   ( -- )  \n"
    "    search> drop  \n"
    "    forth-wordlist >search ;  \n"
    ": only   ( -- )  \n"
    "    -1 set-order ;  \n"
    ": order   ( -- )  \n"
    "    .\" Search: \"  \n"
    "    get-order  0 ?do x. loop cr  \n"
    "   .\" Compile: \" get-current x. cr  ;  \n"
    ": previous  ( --  )  search> drop ;  \n"
    ": ficl-set-current   ( wid -- old-wid )  \n"
    "    get-current swap set-current ;  \n"
/*
** Ficl USER variables
** See words.c for primitive def'n of USER
*/
#if FICL_WANT_USER
    "variable nUser  0 nUser !  \n"
    ": user  \n"
    "    nUser dup @ user 1 swap +! ;  \n"
#endif
/*
** ficl extras
*/
    ": empty   ( xn..x1 -- ) depth 0 ?do drop loop ; \n"
    ": cell-   ( addr -- addr )  [ 1 cells ] literal -  ; \n"
    ": -rot   ( a b c -- c a b )  2 -roll ; \n"
/*
** E N D   S O F T C O R E . F R
** ficl/softwords/oo.fr
** F I C L   O - O   E X T E N S I O N S
** john sadler aug 1998
*/
    ".( loading ficl O-O extensions ) cr \n"
    "vocabulary oop \n"
    "also oop definitions \n"
    "user current-class \n"
    "0 current-class ! \n"
/*
** L A T E   B I N D I N G
*/
    ": parse-method  \n"
    "    parse-word \n"
    "    postpone sliteral \n"
    "; compile-only \n"
    ": lookup-method  ( class c-addr u -- class xt ) \n"
    "    2dup \n"
    "    local u  \n"
    "    local c-addr  \n"
    "    end-locals \n"
    "    2 pick cell+ @        ( -- class c-addr u wid ) \n"
    "    search-wordlist     ( -- class 0 | xt 1 | xt -1 ) \n"
    "    0= if \n"
    "        .\" Method <\" c-addr u type .\" > not found\" cr abort  \n"
    "    endif \n"
    "; \n"
    ": exec-method  ( instance class c-addr u -- <method-signature> ) \n"
    "    lookup-method execute \n"
    "; \n"
    ": find-method-xt  \n"
    "    parse-word lookup-method \n"
    "; \n"
    ": -->   ( instance class -- ??? ) \n"
    "    state @ 0= if \n"
    "        find-method-xt execute  \n"
    "    else  \n"
    "        parse-method  postpone exec-method \n"
    "    endif \n"
    "; immediate \n"
/*
** E A R L Y   B I N D I N G
*/
    ": =>  \n"
    "    drop find-method-xt , drop \n"
    "; immediate compile-only \n"
/*
** I N S T A N C E   V A R I A B L E S
*/
    "wordlist  \n"
    "dup constant instance-vars \n"
    "dup >search ficl-set-current \n"
    ": do-instance-var \n"
    "    does>   ( instance class addr[offset] -- addr[field] ) \n"
    "        nip @ + \n"
    "; \n"
    ": addr-units:  ( offset size \"name\" -- offset' ) \n"
    "    create over , +  \n"
    "    do-instance-var \n"
    "; \n"
    ": chars:  \n"
    "   chars addr-units: ; \n"
    ": char:  \n"
    "   1 chars: ; \n"
    ": cells:  ( offset nCells \"name\" -- offset' ) \n"
    "    cells >r aligned r> addr-units: \n"
    "; \n"
    ": cell:   ( offset nCells \"name\" -- offset' ) \n"
    "    1 cells: ; \n"
    ": do-aggregate \n"
    "    does>   ( instance class pfa -- a-instance a-class ) \n"
    "    2@          ( inst class a-class a-offset ) \n"
    "    2swap drop  ( a-class a-offset inst ) \n"
    "    + swap        ( a-inst a-class ) \n"
    "; \n"
    ": obj:   ( offset class meta \"name\" -- offset' ) \n"
    "    locals| meta class offset | \n"
    "    create  offset , class ,  \n"
    "    class meta --> get-size  offset + \n"
    "    do-aggregate \n"
    "; \n"
    ": array:   ( offset n class meta \"name\" -- offset' ) \n"
    "    locals| meta class nobjs offset | \n"
    "    create offset , class , \n"
    "    class meta --> get-size  nobjs * offset +  \n"
    "    do-aggregate \n"
    "; \n"
    ": ref:   ( offset class meta \"name\" -- offset' ) \n"
    "    locals| meta class offset | \n"
    "    create offset , class , \n"
    "    offset cell+ \n"
    "    does>    ( inst class pfa -- ptr-inst ptr-class ) \n"
    "    2@       ( inst class ptr-class ptr-offset ) \n"
    "    2swap drop + @ swap \n"
    "; \n"
    ": end-class  ( old-wid addr[size] size -- ) \n"
    "    swap ! set-current  \n"
    "    search> drop  \n"
    "; \n"
    "set-current previous \n"
    ": do-do-instance  \n"
    "    s\" : .do-instance does> [ current-class @ ] literal ;\" evaluate  \n"
    "; \n"
/*
** M E T A C L A S S 
*/
    ": meta-class \n"
    "    wordlist \n"
    "    create  immediate \n"
    "    0       ,  \n"
    "    dup     ,  \n"
    "    3 cells ,  \n"
    "    ficl-set-current \n"
    "    does> dup \n"
    "; \n"
    "meta-class metaclass \n"
    "metaclass drop current-class ! \n"
    "do-do-instance \n"
    "instance-vars >search \n"
    "create .super  ( class metaclass -- parent-class ) \n"
    "    0 cells , do-instance-var  \n"
    "create .wid    ( class metaclass -- wid )  \n"
    "    1 cells , do-instance-var  \n"
    "create  .size  ( class metaclass -- size )  \n"
    "    2 cells , do-instance-var  \n"
    "previous \n"
    ": get-size    metaclass => .size  @ ; \n"
    ": get-wid     metaclass => .wid   @ ; \n"
    ": get-super   metaclass => .super @ ; \n"
    ": instance   ( class metaclass \"name\" -- instance class ) \n"
    "    locals| meta parent | \n"
    "    create \n"
    "    here parent --> .do-instance  \n"
    "    parent meta --> get-size  \n"
    "    allot  \n"
    "; \n"
    ": array   ( n class metaclass \"name\" -- n instance class )  \n"
    "    locals| meta parent nobj | \n"
    "    create  nobj \n"
    "    here parent --> .do-instance  \n"
    "    parent meta --> get-size \n"
    "    nobj *  allot  \n"
    "; \n"
    ": new  \n"
    "    metaclass => instance --> init \n"
    "; \n"
    ": new-array   ( n class metaclass \"name\" -- )  \n"
    "    --> array  \n"
    "    --> array-init \n"
    "; \n"
    ": ref   ( instance-addr class metaclass \"name\" -- ) \n"
    "    drop create , , \n"
    "    does> 2@  \n"
    "; \n"
    ": sub   ( class metaclass \"name\" -- old-wid addr[size] size ) \n"
    "    wordlist \n"
    "    locals| wid meta parent | \n"
    "    parent meta metaclass => get-wid \n"
    "    wid wid-set-super \n"
    "    create  immediate  \n"
    "    here current-class !  \n"
    "    parent ,  \n"
    "    wid    ,  \n"
    "    here parent meta --> get-size dup ,  ( addr[size] size ) \n"
    "    metaclass => .do-instance \n"
    "    wid ficl-set-current rot rot \n"
    "    do-do-instance \n"
    "    instance-vars >search  \n"
    "; \n"
    ": offset-of   ( class metaclass \"name\" -- offset ) \n"
    "    drop find-method-xt nip >body @ ; \n"
    ": id   ( class metaclass -- c-addr u ) \n"
    "    drop body> >name  ; \n"
    ": methods  \n"
    "    locals| meta class | \n"
    "    begin \n"
    "        class body> >name type .\"  methods:\" cr  \n"
    "        class meta --> get-wid >search words cr previous  \n"
    "        class meta metaclass => get-super \n"
    "        dup to class \n"
    "    0= until  cr \n"
    "; \n"
    ": pedigree  ( class meta -- ) \n"
    "    locals| meta class | \n"
    "    begin \n"
    "        class body> >name type space \n"
    "        class meta metaclass => get-super \n"
    "        dup to class \n"
    "    0= until  cr \n"
    "; \n"
    ": see  ( class meta -- )  \n"
    "    --> get-wid >search see previous ; \n"
    "set-current  \n"
    ": subclass   --> sub ; \n"
/*
** O B J E C T
*/
    ": root-class \n"
    "    wordlist \n"
    "    create  immediate \n"
    "    0       ,  \n"
    "    dup     ,  \n"
    "    0       ,  \n"
    "    ficl-set-current \n"
    "    does> [ metaclass drop ] literal \n"
    "; \n"
    "root-class object \n"
    "object drop current-class !  \n"
    "do-do-instance \n"
    ": init   ( instance class -- ) \n"
    "    over swap ( inst inst class )  \n"
    "    --> size 0 fill ; \n"
    ": array-init   ( nobj inst class -- ) \n"
    "    0 dup locals| &init &next class inst | \n"
    "    class s\" init\" lookup-method to &init \n"
    "          s\" next\" lookup-method to &next \n"
    "    drop \n"
    "    0 ?do  \n"
    "        inst class 2dup  \n"
    "        &init execute \n"
    "        &next execute  drop to inst \n"
    "    loop \n"
    "; \n"
    ": class  ( instance class -- class metaclass ) \n"
    "    nip [ metaclass nip ] literal  \n"
    "; \n"
    ": super     ( instance class -- instance parent-class ) \n"
    "    dup --> class --> get-super ; \n"
    ": pedigree  ( instance class -- ) \n"
    "    --> class --> pedigree ; \n"
    ": size      ( instance class -- sizeof-instance ) \n"
    "    --> class  --> get-size ; \n"
    ": methods   ( instance class -- ) \n"
    "    --> class --> methods ; \n"
    ": index   ( n instance class -- instance[n] class ) \n"
    "    locals| class inst | \n"
    "    inst class --> class \n"
    "    metaclass => get-size  *   ( n*size ) \n"
    "    inst +  class ; \n"
    ": next   ( instance[n] class -- instance[n+1] class ) \n"
    "    locals| class inst | \n"
    "    inst class --> class \n"
    "    metaclass => get-size  \n"
    "    inst + \n"
    "    class ; \n"
    ": prev   ( instance[n] class -- instance[n-1] class ) \n"
    "    locals| class inst | \n"
    "    inst class --> class \n"
    "    metaclass => get-size \n"
    "    inst swap - \n"
    "    class ; \n"
    "set-current \n"
/*
** ficl/softwords/classes.fr
** F I C L   2 . 0   C L A S S E S
*/
    ".( loading ficl utility classes ) cr \n"
    "object subclass c-ref \n"
    "    cell: .class \n"
    "    cell: .instance \n"
    "    : get   ( inst class -- refinst refclass ) \n"
    "        drop 2@ ; \n"
    "    : set   ( refinst refclass inst class -- ) \n"
    "        drop 2! ; \n"
    "end-class \n"
    "object subclass c-byte \n"
    "    char: .payload \n"
    "    : get  drop c@ ; \n"
    "    : set  drop c! ; \n"
    "end-class \n"
    "object subclass c-2byte \n"
    "    2 chars: .payload \n"
    "    : get  drop w@ ; \n"
    "    : set  drop w! ; \n"
    "end-class \n"
    "object subclass c-4byte \n"
    "    cell: .payload \n"
    "    : get  drop @ ; \n"
    "    : set  drop ! ; \n"
    "end-class \n"
/*
** C - C E L L P T R   C L A S S
*/
    "object subclass c-cellPtr \n"
    "    c-4byte obj: .addr \n"
    "    : get-ptr   ( inst class -- addr ) \n"
    "        --> .addr --> get  ; \n"
    "    : set-ptr   ( addr inst class -- ) \n"
    "        --> .addr --> set  ; \n"
    "    : get   ( inst class -- cell ) \n"
    "        --> get-ptr @ ; \n"
    "    : set   ( cell inst class -- ) \n"
    "        --> get-ptr !  ; \n"
    "    : inc-ptr   ( inst class -- ) \n"
    "        0 locals| ptr | \n"
    "        --> .addr  \n"
    "        2dup --> get  to ptr  \n"
    "        2dup --> size ptr swap +  \n"
    "        rot rot --> set \n"
    "    ; \n"
    "    : dec-ptr    ( inst class -- ) \n"
    "        0 locals| ptr | \n"
    "        --> .addr  \n"
    "        2dup --> get  to ptr  \n"
    "        2dup --> size ptr swap -  \n"
    "        rot rot --> set \n"
    "    ; \n"
    "end-class \n"
    "quit ";


void ficlCompileSoftCore(FICL_VM *pVM)
{
    int ret = ficlExec(pVM, softWords);
    if (ret == VM_ERREXIT)
        assert(FALSE);
    return;
}


