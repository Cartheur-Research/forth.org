#! /bin/sh

tail -c +257 <$1- >gf8086.com
cp $1- $1