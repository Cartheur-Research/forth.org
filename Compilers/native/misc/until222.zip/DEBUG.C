/*
|	FILE:	DEBUG,C
|
|	This module provides several C-level debugging functions
|	for programmer convenience,
|
|	DATE		CHANGE
|	01/16/95	Made cleanup changes suggested by Akira Kida,
|			akida@isd.hin.konica.co.jp. [nes]
*/
#include <stdio.h>

/***********************+-------+
|			| debug |
|			+-------+
*/
void debug(char *msg)
{	printf("%s\n",msg);	}
/***********************+--------+
|			| debugs |
|			+--------+
*/
void debugs(char *msg,char *value)
{	printf("%s: %s\n",msg,value);	}
/***********************+--------+
|			| debugi |
|			+--------+
*/
void debugi(char *msg,int value)
{	printf("%s: %d\n",msg,value);	}
/***********************+--------+
|			| debuga |
|			+--------+
*/
void debuga(char *msg,void *value)
{	printf("%s: %ld\n",msg,(unsigned long)value);	}

