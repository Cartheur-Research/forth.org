/*
 * This file is part of the portable Forth environment written in ANSI C.
 * Copyright (C) 1999  Stefan Wenk
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 * This file is version 0.9.22 of 07-January-99
/*
 * pfeform.cpp --- interface to main.c for C++Builder port
 */

#ifndef _main_h
#define _main_h

#ifdef __cplusplus
extern "C" {
#endif
int forthmain (int argc, char *argv[]);
void get_win_forth_options (int argc, char *argv[]);
void set_caps_options(unsigned lower_case_on,unsigned lower_case_fn);
#ifdef __cplusplus
 }
#endif

#endif
