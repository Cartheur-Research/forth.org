\ automatic generated code
\ do not edit
windows also forth

window class testwidgets1
public:
  early open
  early modal-open
  lbutton ptr tbut
  button ptr but1
  button ptr but2
  | glue ptr (glue-00)
  button ptr but3
  | topindex ptr (topindex-01)
  | topindex ptr (topindex-02)
  | topindex ptr (topindex-03)
  button ptr idx0a
  button ptr idx0b
  | glue ptr (glue-04)
  button ptr idx1a
  button ptr idx1b
  | glue ptr (glue-05)
  button ptr idx2a
  button ptr idx2b
  button ptr idx2c
  button ptr idx2d
  button ptr idx2e
  button ptr but4
  | canvas ptr (canvas-06)
  infotextfield ptr tex
  | hscaler ptr (hscaler-07)
  vscaler ptr vslid
  | rbutton ptr (rbutton-08)
  | rbutton ptr (rbutton-09)
  | rbutton ptr (rbutton-0A)
  | rbutton ptr (rbutton-0B)
  | rbutton ptr (rbutton-0C)
  | rbutton ptr (rbutton-0D)
  | rbutton ptr (rbutton-0E)
  | rbutton ptr (rbutton-0F)
  | tbutton ptr (tbutton-10)
  | tbutton ptr (tbutton-11)
  | tbutton ptr (tbutton-12)
  | tbutton ptr (tbutton-13)
  | tbutton ptr (tbutton-14)
  | tbutton ptr (tbutton-15)
  | tbutton ptr (tbutton-16)
  | tbutton ptr (tbutton-17)
  | vviewport ptr (vviewport-18)
  | viewport ptr (viewport-19)
how:
  : open       screen self new >o map o> ;
  : modal-open screen self new >o map stop o> ;
class;

testwidgets1 implements
  : init  super init ^ { ^^ | ( [dumpstart] )
        1 1 ^ viewport new dup ^^ with bind (viewport-19) endwith  DS[ 
                ^^ S[ tbut get tex assign ]S s" Testbutton" ^ lbutton new dup ^^ with bind tbut endwith 
                  ^^ S[ but1 get tex assign ]S s" Button 1" ^ button new dup ^^ with bind but1 endwith 
                  ^^ S[ but2 get tex assign ]S s" But 2" ^ button new dup ^^ with bind but2 endwith 
                  $1 $1 *hfilll $1 $1 *vfilll ^ glue new dup ^^ with bind (glue-00) endwith 
                  ^^ S[ but3 get tex assign ]S s" Button 3" ^ button new dup ^^ with bind but3 endwith 
                4 ^ hatbox new 1 hskips
                    0 -1 flipper s" Index 0" ^ topindex new dup ^^ with bind (topindex-01) endwith 
                    0 0 flipper s" Index 1" ^ topindex new dup ^^ with bind (topindex-02) endwith 
                    0 0 flipper s" Index 2" ^ topindex new dup ^^ with bind (topindex-03) endwith 
                  3 ^ hartbox new
                      ^^ S[ idx0a get tex assign ]S s" Index0" ^ button new dup ^^ with bind idx0a endwith 
                      ^^ S[ idx0b get tex assign ]S s" Klick mal" ^ button new dup ^^ with bind idx0b endwith 
                      $0 $1 *hfill $0 $1 *vfil ^ glue new dup ^^ with bind (glue-04) endwith 
                    3 ^ habox new panel dup ^^ with C[ (topindex-01) ]C endwith 
                      ^^ S[ idx1a get tex assign ]S s" Index 1" ^ button new dup ^^ with bind idx1a endwith 
                      ^^ S[ idx1b get tex assign ]S s" Kuck mal" ^ button new dup ^^ with bind idx1b endwith 
                      $0 $1 *hfilll $10 $1 *vfil ^ glue new dup ^^ with bind (glue-05) endwith 
                    3 ^ habox new flipbox  panel dup ^^ with C[ (topindex-02) ]C endwith 
                      ^^ S[ idx2a get tex assign ]S s" Kuck" ^ button new dup ^^ with bind idx2a endwith 
                      ^^ S[ idx2b get tex assign ]S s" mal" ^ button new dup ^^ with bind idx2b endwith 
                      ^^ S[ idx2c get tex assign ]S s" wer" ^ button new dup ^^ with bind idx2c endwith 
                      ^^ S[ idx2d get tex assign ]S s" da" ^ button new dup ^^ with bind idx2d endwith 
                      ^^ S[ idx2e get tex assign ]S s" spricht" ^ button new dup ^^ with bind idx2e endwith 
                    5 ^ habox new flipbox  panel dup ^^ with C[ (topindex-03) ]C endwith 
                  3 ^ habox new $10  noborderbox  2 borderbox
                2 ^ vabox new
                ^^ S[ but4 get tex assign ]S s" Button 4" ^ button new dup ^^ with bind but4 endwith 
                    CV[  ]CV $64 $1 *hfil $64 $1 *vfil ^ canvas new dup ^^ with bind (canvas-06) endwith 
                  1 ^ vabox new -2 borderbox
                1 ^ habox new
                s" " s" Text:" ^ infotextfield new dup ^^ with bind tex endwith 
                ^^ &1000 SC[  ]SC ^ hscaler new dup ^^ with bind (hscaler-07) endwith 
              7 ^ vabox new panel
              ^^ &10000 SC[ vslid get nip nip 0 <# #S #> tex assign ]SC ^ vscaler new dup ^^ with bind vslid endwith 
            2 ^ habox new vfixbox 
            1 1 ^ vviewport new dup ^^ with bind (vviewport-18) endwith  DS[ 
                  ^^ -1 T[  ][  ]T s" Toggle 0" ^ rbutton new dup ^^ with bind (rbutton-08) endwith 
                  ^^  0 T[  ][  ]T s" Toggle 1" ^ rbutton new dup ^^ with bind (rbutton-09) endwith 
                  ^^  0 T[  ][  ]T s" Toggle 2" ^ rbutton new dup ^^ with bind (rbutton-0A) endwith 
                  ^^  0 T[  ][  ]T s" Toggle 3" ^ rbutton new dup ^^ with bind (rbutton-0B) endwith 
                  ^^  0 T[  ][  ]T s" Toggle 4" ^ rbutton new dup ^^ with bind (rbutton-0C) endwith 
                  ^^  0 T[  ][  ]T s" Toggle 5" ^ rbutton new dup ^^ with bind (rbutton-0D) endwith 
                  ^^  0 T[  ][  ]T s" Toggle 6" ^ rbutton new dup ^^ with bind (rbutton-0E) endwith 
                  ^^  0 T[  ][  ]T s" Toggle 7" ^ rbutton new dup ^^ with bind (rbutton-0F) endwith 
                8 ^ varbox new
                  ^^  0 T[  ][  ]T s" Toggle 8" ^ tbutton new dup ^^ with bind (tbutton-10) endwith 
                  ^^  0 T[  ][  ]T s" Toggle 9" ^ tbutton new dup ^^ with bind (tbutton-11) endwith 
                  ^^  0 T[  ][  ]T s" Toggle A" ^ tbutton new dup ^^ with bind (tbutton-12) endwith 
                  ^^  0 T[  ][  ]T s" Toggle B" ^ tbutton new dup ^^ with bind (tbutton-13) endwith 
                  ^^  0 T[  ][  ]T s" Toggle C" ^ tbutton new dup ^^ with bind (tbutton-14) endwith 
                  ^^  0 T[  ][  ]T s" Toggle D" ^ tbutton new dup ^^ with bind (tbutton-15) endwith 
                  ^^  0 T[  ][  ]T s" Toggle E" ^ tbutton new dup ^^ with bind (tbutton-16) endwith 
                  ^^  0 T[  ][  ]T s" Toggle F" ^ tbutton new dup ^^ with bind (tbutton-17) endwith 
                8 ^ vabox new
              2 ^ hatbox new
            1 ^ habox new ]DS 
          2 ^ vabox new
        1 ^ habox new ]DS 
      1 ^ vabox new
    ( [dumpend] ) } 1 0 ^ modal new 0 hskips 0 vskips s" Test Widgets" assign ;
class;

script? [IF]
: main
  testwidgets1 open
  &1 0 ?DO  stop  LOOP ; main
bye [THEN]
